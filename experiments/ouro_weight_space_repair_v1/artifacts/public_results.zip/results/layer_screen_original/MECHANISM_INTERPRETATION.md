# Discovery layer-screen mechanism interpretation

Analyzed 8 selected training questions and 48 physical modules. These are exploratory representative-case results, not whole-discovery or held-out estimates.

## What the screen establishes

Exact no-op assertions passed in the completed runner. Branch damping acts after branch RMSNorm; it measures sensitivity to reducing a branch residual contribution. It does not identify a raw projection direction or establish a weight-equivalent repair.

Boundary controls modify loop-5 normalized feedback and therefore test downstream K6 behavior. Endpoint-only rescue and feedback rescue must be reported separately. Neither alone proves H3 or rules out H1.

## Bounded next-step decision

Machine-readable decision: `shared_invocation_confirmation_only`. H2 established: **false**.

The screening gate requires positive net K5 corrections without representative stable-correct/rescue regressions, improvement beyond the best tested boundary control, and positive all-loop transfer before permitting a bounded label-blind direction diagnostic. Margin ties use the pre-existing 0.001 descriptive epsilon. This is a resource-allocation rule, not a hypothesis test.

- Exploratory rank 1: layer 0 mlp; net K5 corrections +1; mean margin change 0.026738; decision `localization_only_requires_shared_invocation_check`.
- Exploratory rank 2: layer 10 attention; net K5 corrections +1; mean margin change 0.007818; decision `localization_only_requires_shared_invocation_check`.

## Claims still unsupported

The best of 48 modules can overfit eight selected cases. A high output norm, directional stability, or an isolated lesion rescue is not a shared harmful direction. Absent all-loop tests means transfer is unmeasured, not failed. A stop decision means the current screen does not justify direction search, not that H2 is mathematically impossible.

Any continuation requires a fixed, label-blind direction specification; norm-matched scalar and random directional controls; unselected train-transfer evaluation; and actual BF16 shared-weight realization. No validation or test results belong in this discovery report.

## Reporting checklist

- Contrast native aggregate depth results from the separate discovery report with these selected-case results.
- Report every screened module and the number of intervention conditions, including negative cases.
- State whether K6 feedback gains survive and whether early-loop behavior degrades under all-loop intervention.
- Preserve the failed cached-BF16 readiness gate; all accepted scores here use native whole-candidate forwards.
- If direction-specific evidence remains absent, report H1/H3-compatible sensitivity or unresolved mechanism rather than inventing an edit.
