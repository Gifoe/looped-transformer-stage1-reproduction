"""Verify the E0 dispatcher receipts and analyze the frozen development runs."""

import argparse
from collections import Counter
import csv
import math
from pathlib import Path
from statistics import fmean

from e0_analyze import analyze
from e0_external_dev import GROUPS, LEGACY_GROUPS
from e0_reuse import SEEDS, jobs, load_json, save_json
from stage0_data import digest, items


ANCHORS = ("native", "t1", "t2", "mixed")
PRIMARY = {name: ("acc" if name == "mmlu_val" else "correct" if name == "mmlu_pro_val" else "acc_norm")
           for name in GROUPS}
EXTERNAL_MACRO = "external/equal_task_macro"
COLD_MINIMUM_WARM_GAIN_FRACTION = 0.5


def check_job(path, stage, job_id, required):
    marker = stage / "stage1_e0/dispatcher_receipts" / path
    record = load_json(marker)
    expected = {source.relative_to(stage).as_posix(): digest(source) for source in required}
    if record["job_id"] != job_id or record["artifact_sha256"] != expected:
        raise ValueError(f"Dispatcher provenance changed for {job_id}")
    return digest(marker)


def load_panel(root, arm, weight):
    dest = root / "stage1_e0/e0_external_dev" / arm
    dev_file = dest / "DEVELOPMENT.json"
    dev = load_json(dev_file)
    root_files = [dest / f"{name}.jsonl" for name in GROUPS]
    legacy_files = [dest / "historical" / f"{name}.jsonl" for name in LEGACY_GROUPS]
    receipt = check_job(Path(f"external-dev/{arm}.json"), root, f"e0.external-dev.{arm}",
                        [dev_file, *root_files, *legacy_files])
    if dev["arm"] != arm or dev["checkpoint_sha256"] != weight:
        raise ValueError(f"Development arm or checkpoint changed: {arm}")
    endpoints = {f"external/{name}/{metric}": score for name, metrics in dev["metrics"].items()
                 for metric, score in metrics.items()}
    endpoints[EXTERNAL_MACRO] = fmean(dev["metrics"][group][key] for group, key in PRIMARY.items())
    endpoints.update({f"historical/{group}": metrics["value"]
                      for group, metrics in dev["historical"]["metrics"].items()})
    endpoints["historical/equal_cohort_macro"] = fmean(dev["historical"]["metrics"][group]["value"]
                                                       for group in LEGACY_GROUPS)
    pro = list(items(dest / "mmlu_pro_val.jsonl"))
    stops = Counter(row["stop"] for row in pro)
    if any(reason not in {"eos", "letter", "limit"} for reason in stops):
        raise ValueError("Unexpected MMLU-Pro stop reason")
    for reason in ("eos", "letter", "limit"):
        endpoints[f"external/mmlu_pro_val/stop_{reason}"] = stops[reason] / len(pro)
    return dev, endpoints, pro, stops, receipt


def paired_pro(native_rows, arm_rows):
    transitions = Counter()
    result = {"both_parseable": {"n": 0, "native_correct": 0, "arm_correct": 0}}
    for native, arm in zip(native_rows, arm_rows, strict=True):
        if (native["id"], native["gold"]) != (arm["id"], arm["gold"]):
            raise ValueError("MMLU-Pro development pair differs")
        before, after = (row["metrics"]["parseable"] for row in (native, arm))
        label = f"{'legal' if before else 'illegal'}_to_{'legal' if after else 'illegal'}"
        transitions[label] += 1
        if before and after:
            result["both_parseable"]["n"] += 1
            result["both_parseable"]["native_correct"] += native["metrics"]["correct"]
            result["both_parseable"]["arm_correct"] += arm["metrics"]["correct"]
    return dict(result, transitions=dict(transitions))


def fit_record(root, job, dest, stamps):
    name = job["job_id"]
    files = [dest / name / file for file in ("controller.pt", "TRAIN.json", "train_trace.jsonl", "E0_RUN_CONFIG.json")]
    stamps[name] = check_job(Path(f"train/{name}.json"), root, f"e0.train.{name}", files)
    fit = load_json(files[1])
    config = load_json(files[3])
    trace = list(items(files[2]))
    if (fit["updates"] != job["steps"] or fit["checkpoint_sha256"] != digest(files[0])
            or config["job"] != job or not trace or trace[-1]["step"] != job["steps"]):
        raise ValueError(f"E0 training is incomplete or misidentified: {name}")
    for row in trace:
        if not all(math.isfinite(value) for key in ("loss", "rank", "nll")
                   for block in row["objectives"].values() if (value := block[key]) is not None):
            raise ValueError(f"Nonfinite objective in {name}")
    return dict(fit, trace=trace, final_geometry=trace[-1])


def verify_norm_controls(roster, fits):
    search = {(row["init"], row["data"], row["objective"], row["steps"], row["seed"]): row["job_id"] for row in roster}
    for job in roster:
        if job["init"] != "norm_rand":
            continue
        warm = search["spec_warm", job["data"], job["objective"], job["steps"], job["seed"]]
        first = fits[job["job_id"]]["initial_geometry"]
        second = fits[warm]["initial_geometry"]
        if any(abs(first[key] - second[key]) >= 1e-5 for key in ("write_norm", "read_norm", "norm_product")):
            raise ValueError(f"Norm-matched control differs in scale: {job['job_id']}")


def objective_contrasts(values, fits):
    result = {}
    for init in ("cold", "spec_warm"):
        rows = []
        for data in ("arc", "arc_csqa"):
            for seed in SEEDS:
                rank = f"core.{init}.{data}.rank.840.{seed}"
                joint = f"core.{init}.{data}.nll_rank.840.{seed}"
                before, after = values[rank], values[joint]
                row = {"seed": seed, "data": data,
                       "external_macro_pp": 100 * (after[EXTERNAL_MACRO] - before[EXTERNAL_MACRO]),
                       "mmlu_pro_eos_pp": 100 * (after["external/mmlu_pro_val/stop_eos"] - before["external/mmlu_pro_val/stop_eos"]),
                       "mmlu_pro_parseable_pp": 100 * (after["external/mmlu_pro_val/parseable"] - before["external/mmlu_pro_val/parseable"])}
                cos_before = fits[rank]["final_geometry"].get("historical_mixed", {}).get("cos_op")
                cos_after = fits[joint]["final_geometry"].get("historical_mixed", {}).get("cos_op")
                if cos_before is not None and cos_after is not None:
                    row["cos_operator_mixed"] = cos_after - cos_before
                rows.append(row)
        fields = tuple(key for key in rows[0] if key not in {"seed", "data"})
        result[init] = {key: fmean(row[key] for row in rows) for key in fields if all(key in row for row in rows)}
        result[init]["paired_cells"] = rows
    return result


def verdict(stats, values, fits):
    effects = stats[EXTERNAL_MACRO]
    contrasts = effects["controlled"]
    gains = {}
    for step, seeds in ((840, SEEDS), (280, SEEDS[:1])):
        gains[str(step)] = []
        kind = "core" if step == 840 else "duration"
        for seed in seeds:
            cold, warm = [values[f"{kind}.{init}.arc.rank.{step}.{seed}"][EXTERNAL_MACRO] - values["native"][EXTERNAL_MACRO]
                          for init in ("cold", "spec_warm")]
            gains[str(step)].append({"seed": seed, "cold_gain_pp": cold * 100, "spectral_gain_pp": warm * 100,
                                     "cold_fraction_of_spectral_gain": cold / warm if warm > 0 else None})
    viable = all(row["cold_gain_pp"] > 0 and (
        row["spectral_gain_pp"] <= 0 or row["cold_fraction_of_spectral_gain"] >= COLD_MINIMUM_WARM_GAIN_FRACTION
    ) for row in gains["840"])
    return {"init_direction_effect_pp": 100 * fmean(contrasts[name]["warm_minus_norm_random"] for name in ("arc", "arc_csqa")),
            "init_scale_effect_pp": 100 * fmean(contrasts[name]["norm_random_minus_cold"] for name in ("arc", "arc_csqa")),
            "nll_hijack_effect_pp": 100 * effects["factorial"]["objective"]["effect"],
            "nll_minus_rank_by_initialization": objective_contrasts(values, fits),
            "data_effect_pp": 100 * effects["factorial"]["data"]["effect"],
            "cold_start_gains": gains, "cold_start_viable": viable,
            "cold_viability_rule": "Cold exceeds Native on both 840-step seeds and retains at least 50% of any positive matched spectral gain.",
            "recommended_d3_init_regimes": ["Cold_FixedWork", "D2Warm_FixedWork"],
            "d3_interpretation": "Cold receives the same planned coverage. The verdict records whether the observed gain supports a stable cold probe."}


def collect_ledger(paths, successful, target):
    rows = []
    fields = None
    for path in paths:
        with path.open(encoding="utf-8", newline="") as stream:
            ledger = csv.DictReader(stream, delimiter="\t")
            if fields is not None and fields != ledger.fieldnames:
                raise ValueError("GPU ledger schemas differ across hosts")
            fields = ledger.fieldnames
            rows.extend(row for row in ledger if row["job_id"] in successful)
    done = {}
    for row in rows:
        if row["exit_code"] != "0":
            continue
        name = row["job_id"]
        if name in done or row["sha256"] != successful[name]:
            raise ValueError(f"GPU ledger and completed receipt differ for {name}")
        done[name] = row["sha256"]
    if done != successful:
        raise ValueError(f"Missing GPU ledger completion entries: {sorted(set(successful) - set(done))}")
    partial = target.with_suffix(".partial")
    with partial.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(sorted(rows, key=lambda row: (row["timestamp_start"], row["gpu_id"], row["job_id"])))
    if target.exists() and digest(target) != digest(partial):
        raise ValueError("Previously committed E0 GPU ledger differs")
    partial.replace(target)


def main(root, ledgers=()):
    stage = root / "stage1_e0"
    config_file = stage / "E0_CONFIG.json"
    config = load_json(config_file)
    roster = jobs(config.get("enable_historical_bridge", False))
    trains, evals, endpoints, all_pro = {}, {}, {}, {}
    fit_marks, dev_marks = {}, {}
    dest = Path(config["output"])
    for job in roster:
        name = job["job_id"]
        trains[name] = fit_record(root, job, dest, fit_marks)
    verify_norm_controls(roster, trains)
    for name in (*ANCHORS, *trains):
        weight = trains[name]["checkpoint_sha256"] if name in trains else config["historical_weight_sha256"].get(name)
        dev, values, rows, stops, marker = load_panel(root, name, weight)
        evals[name] = {"development": dev, "mmlu_pro_stops": dict(stops), "endpoints": values}
        endpoints[name], all_pro[name], dev_marks[name] = values, rows, marker
    for name, rows in all_pro.items():
        evals[name]["mmlu_pro_paired_vs_native"] = paired_pro(all_pro["native"], rows)
    analysis = analyze({name: endpoints[name] for name in trains})
    decision = verdict(analysis, endpoints, trains)
    outputs = {
        "E0_RAW_RESULTS.json": {"roster": roster, "training": trains, "evaluation": evals,
                                "train_receipt_sha256": fit_marks, "development_receipt_sha256": dev_marks,
                                "configuration_sha256": digest(config_file)},
        "E0_ANOVA_TABLE.json": {"by_development_endpoint": analysis, "effect_unit": "proportion",
                               "replicates": "two matched training seeds; descriptive standard error"},
        "E0_VERDICT.json": decision,
    }
    for name, payload in outputs.items():
        path = stage / name
        if path.exists() and load_json(path) != payload:
            raise ValueError(f"An earlier E0 result differs at {path}")
        if not path.exists():
            save_json(path, payload)
    lines = ["# E0 development results", "", "| Arm | External macro | Historical macro | MMLU-Pro parseable | Final cos(op, T1) | Final cos(op, Mixed) |",
             "|---|---:|---:|---:|---:|---:|"]
    for name, values in endpoints.items():
        geometry = trains[name]["final_geometry"] if name in trains else {}
        cosines = [geometry.get(anchor, {}).get("cos_op") for anchor in ("historical_t1", "historical_mixed")]
        formatted = [f"{value:.4f}" if value is not None else "—" for value in cosines]
        lines.append(f"| {name} | {values[EXTERNAL_MACRO]:.2%} | {values['historical/equal_cohort_macro']:.2%} | "
                     f"{values['external/mmlu_pro_val/parseable']:.2%} | {formatted[0]} | {formatted[1]} |")
    lines += ["", "The primary macro averages SciQ, ARC-Easy, CosmosQA, MMLU and MMLU-Pro equally.",
              "The official MMLU auxiliary development items retained in the primary panel also occur in the historical comparison.",
              "", "Matched Rank-only spectral direction effect "
              f"{decision['init_direction_effect_pp']:+.2f} pp. "
              f"Initialization scale effect {decision['init_scale_effect_pp']:+.2f} pp.",
              "", f"Joint objective effect {decision['nll_hijack_effect_pp']:+.2f} pp. "
              f"ARC+CSQA data effect {decision['data_effect_pp']:+.2f} pp.",
              "", "Cold viability rule", "", decision["cold_viability_rule"]]
    report = stage / "E0_REPORT.md"
    content = "\n".join(lines) + "\n"
    if report.exists() and report.read_text(encoding="utf-8") != content:
        raise ValueError(f"An earlier E0 report differs at {report}")
    if not report.exists():
        report.write_text(content, encoding="utf-8")
    outputs_with_hashes = [*outputs, report.name]
    if ledgers:
        successful = {**{f"e0.train.{name}": value for name, value in fit_marks.items()},
                      **{f"e0.external-dev.{name}": value for name, value in dev_marks.items()}}
        ledger = stage / "GPU_LEDGER.tsv"
        collect_ledger(ledgers, successful, ledger)
        outputs_with_hashes.append(ledger.name)
    sha = {name: digest(stage / name) for name in outputs_with_hashes}
    save_json(stage / "E0_OUTPUT_SHA256.json", sha)
    print("E0_COMPLETE", sha, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--ledger", type=Path, action="append", required=True)
    args = parser.parse_args()
    main(args.root.resolve(), args.ledger)
