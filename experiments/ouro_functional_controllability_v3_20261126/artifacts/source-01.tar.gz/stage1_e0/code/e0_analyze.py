"""Score E0 from completed development receipts with a balanced seed-block factorial analysis."""

import argparse
from itertools import combinations
import json
import math
from pathlib import Path
import statistics

from e0_reuse import jobs, SEEDS, save_json


FACTORS = {
    "init": {"cold": -1, "spec_warm": 1},
    "data": {"arc": -1, "arc_csqa": 1},
    "objective": {"rank": -1, "nll_rank": 1},
}


def effects(values):
    roster = [job for job in jobs() if job["kind"] == "core"]
    intercept = statistics.mean(values.values())
    total_ss = sum((value - intercept) ** 2 for value in values.values())
    table = {}
    for degree in range(1, 4):
        for terms in combinations(FACTORS, degree):
            signs = {job["job_id"]: math.prod(FACTORS[key][job[key]] for key in terms) for job in roster}
            blocks = [statistics.mean(values[j["job_id"]] * signs[j["job_id"]]
                                      for j in roster if j["seed"] == seed) * 2 for seed in SEEDS]
            effect = statistics.mean(blocks)
            ss = len(values) * (effect / 2) ** 2
            table["/".join(terms)] = {"effect": effect, "seed_effects": blocks,
                                      "seed_sem": statistics.stdev(blocks) / math.sqrt(len(blocks)),
                                      "eta_squared": ss / total_ss if total_ss else 0.0}
    return table


def controlled_contrasts(values):
    lookup = {(j["init"], j["data"], j["objective"], j["steps"], j["seed"]): values[j["job_id"]]
              for j in jobs(True) if j["job_id"] in values}
    contrasts = {}
    for data in ("arc", "arc_csqa"):
        direction = []
        norm = []
        for seed in SEEDS:
            cold, warm, rand = [lookup[(init, data, "rank", 840, seed)]
                                for init in ("cold", "spec_warm", "norm_rand")]
            direction.append(warm - rand)
            norm.append(rand - cold)
        contrasts[data] = {"warm_minus_norm_random": statistics.mean(direction),
                           "norm_random_minus_cold": statistics.mean(norm)}
    contrasts["280_to_840_arc_rank"] = {
        init: lookup[(init, "arc", "rank", 840, SEEDS[0])] - lookup[(init, "arc", "rank", 280, SEEDS[0])]
        for init in ("cold", "spec_warm")}
    if any(key[0] == "historical_t1_axis" for key in lookup):
        differences = [lookup[("historical_t1_axis", "arc", "rank", 840, seed)]
                       - lookup[("spec_warm", "arc", "rank", 840, seed)] for seed in SEEDS]
        contrasts["historical_axis_bridge_arc_rank"] = {"historical_minus_spectral": statistics.mean(differences),
                                                       "seed_differences": differences}
    return contrasts


def analyze(receipts):
    wanted = {row["job_id"] for row in jobs()}
    with_bridge = {row["job_id"] for row in jobs(True)}
    if set(receipts) not in (wanted, with_bridge):
        raise ValueError("Expected the 24 E0 arms with either both historical-axis arms or neither")
    metrics = set(next(iter(receipts.values())))
    if not metrics or any(set(doc) != metrics for doc in receipts.values()):
        raise ValueError("Each arm must cover the same development endpoints")
    core_ids = {row["job_id"] for row in jobs() if row["kind"] == "core"}
    result = {}
    for metric in sorted(metrics):
        if "test" in metric.casefold():
            raise ValueError("Formal test scores are outside the E0 analysis")
        values = {key: value[metric] for key, value in receipts.items()}
        if any(not math.isfinite(value) or not 0 <= value <= 1 for value in values.values()):
            raise ValueError(f"Expected finite proportions for {metric}")
        result[metric] = {"factorial": effects({key: values[key] for key in core_ids}),
                          "controlled": controlled_contrasts(values)}
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--development-proportions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = analyze(json.loads(args.development_proportions.read_text(encoding="utf-8")))
    save_json(args.output, {"by_development_endpoint": result, "effect_unit": "proportion",
                            "eta_squared": "balanced contrast sum of squares / total sum of squares",
                            "replicates": "two blocked training seeds; no significance declaration"})
