"""Generate the E0 factorial roster and run one approved historical-reuse training arm."""

import argparse
from itertools import product
import json
from pathlib import Path
import random


SEEDS = (26112601, 26112602)
DEPTHS = (2, 3, 4)
RECIPE = {"effective_batch": 4, "learning_rate": .001, "weight_decay": .03, "clip": 1.,
          "depths": list(DEPTHS), "mixed_rank_coefficient": .25}
BASE_SHA = "58872a72616c736595b8b7662079c5b12c5a162ec16eae94f21c348dfa9885af"
HISTORICAL_T1_AXIS_SHA = "0bdb6a2e2e476671a95f98988e01064f9a988413c1b619cd2b76039b52712042"
T1_SHA = "91d4919308bf9060ce0c44e4046e4851e7e59f65b9692c77045535f96534efd2"
MIXED_SHA = "ec2e55a64564f608cfeb245da079015db4347a9391072cba7f2949db05185b87"
RANK8_SHA = "513a964b07f6a70d79fdbf2a36effa85fc757194cb89fc84993a2323da2abeb8"


def jobs(include_historical_bridge=False):
    core = [("core", init, data, loss, 840, seed)
            for init, data, loss, seed in product(
                ("cold", "spec_warm"), ("arc", "arc_csqa"), ("rank", "nll_rank"), SEEDS)]
    controls = [(kind, init, data, loss, 840, seed)
                for kind, init, data, loss in [
                    ("norm", "norm_rand", "arc", "rank"),
                    ("norm", "norm_rand", "arc_csqa", "rank"),
                    ("bridge", "cold", "mixed4", "nll_rank"),
                ] for seed in SEEDS]
    short = [("duration", init, "arc", "rank", 280, SEEDS[0]) for init in ("cold", "spec_warm")]
    historical = [("historical_init_bridge", "historical_t1_axis", "arc", "rank", 840, seed)
                  for seed in SEEDS] if include_historical_bridge else []
    return [dict(job_id=f"{kind}.{init}.{data}.{loss}.{steps}.{seed}", kind=kind,
                 init=init, data=data, objective=loss, steps=steps, seed=seed)
            for kind, init, data, loss, steps, seed in core + controls + short + historical]


def source_mix(job, bridge):
    if job["data"] == "arc":
        return {"arc_challenge": 4}
    if job["data"] == "arc_csqa":
        return {"arc_challenge": 2, "csqa": 2}
    if bridge is None or len(bridge) != 4 or len(set(bridge)) != 4:
        raise ValueError("The bridge must explicitly name four source domains in the approved config")
    return dict.fromkeys(bridge, 1)


def streams(pool, seed, namespace):
    order = list(range(len(pool)))
    if not order:
        raise ValueError(f"Empty source pool {namespace}")
    rng = random.Random(f"{seed}/{namespace}")
    while True:
        rng.shuffle(order)
        for index in order:
            yield pool[index]


def configure(net, kind, rank8, seed, historical_axis=None):
    import torch
    if kind == "cold":
        if torch.count_nonzero(net.out.weight):
            raise ValueError("Historical cold initialization must have zero effective write")
        return
    if historical_axis is None:
        payload = torch.load(rank8, map_location="cpu", weights_only=True)["state"]
        out_left, out_core = torch.linalg.qr(payload["out.weight"].double(), mode="reduced")
        in_right, in_core = torch.linalg.qr(payload["encode.weight"].double().T, mode="reduced")
        left, singular, right = torch.linalg.svd(out_core @ in_core.T, full_matrices=False)
        u = (out_left @ left[:, 0]) * singular[0].sqrt()
        w = (in_right @ right[0]) * singular[0].sqrt()
    else:
        payload = torch.load(historical_axis, map_location="cpu", weights_only=True)["state"]
        u = payload["out.weight"].double().squeeze(1)
        w = payload["encode.weight"].double().squeeze(0)
    target_norms = (u.norm(), w.norm())
    if kind == "norm_rand":
        generator = torch.Generator(device="cpu").manual_seed(seed)
        random_u = torch.randn(u.shape, dtype=u.dtype, generator=generator)
        random_w = torch.randn(w.shape, dtype=w.dtype, generator=generator)
        u = random_u * (u.norm() / random_u.norm())
        w = random_w * (w.norm() / random_w.norm())
    with torch.no_grad():
        net.out.weight.copy_(u[:, None])
        net.encode.weight.copy_(w[None, :])
    if kind == "norm_rand":
        observed = (net.out.weight.detach().double().norm(), net.encode.weight.detach().double().norm())
        if max(abs(float(a - b)) for a, b in zip(observed, target_norms, strict=True)) >= 1e-6:
            raise ValueError("Random initialization failed the separate factor norm tolerances")


def operator_geometry(net, anchors):
    axes = [p.detach().double().cpu().flatten() for p in (net.out.weight, net.encode.weight)]
    norms = [float(axis.norm()) for axis in axes]
    output = {"write_norm": norms[0], "read_norm": norms[1], "norm_product": norms[0] * norms[1]}
    for name, pair in anchors.items():
        cosines = [float(axis @ other) / float(axis.norm() * other.norm())
                   if float(axis.norm() * other.norm()) else None
                   for axis, other in zip(axes, pair, strict=True)]
        u, w = cosines
        output[name] = {"cos_u": u, "cos_w": w, "cos_op": u*w if u is not None and w is not None else None}
    return output


def score_rows(archive, model, tokenizer, controller, rows, depth, objective):
    from advantages import choice_batch, forward, token_batch
    from torch.nn.functional import cross_entropy
    from train_generative import normalized_nll, ranking

    rank, nll, work = None, None, 0
    if all("candidate" in row for row in rows):
        options = choice_batch(archive, tokenizer, rows)
        logits, _ = forward(model, options, depth, controller)
        likelihood = -cross_entropy(logits, options.packed[-1], reduction="none")
        rank, _ = ranking(likelihood, options.packed[1], options.metadata, list(range(len(rows))))
        work += options.packed[0].numel() * depth
    if objective == "rank":
        if rank is None:
            raise ValueError("Pure ranking requires candidate rows")
        return rank, rank, nll, work
    tokens = token_batch(archive, tokenizer, rows)
    logits, _ = forward(model, tokens, depth, controller)
    nll = normalized_nll(logits, tokens.packed, len(tokens.packed[0]))
    work += tokens.packed[0].numel() * depth
    loss = nll + RECIPE["mixed_rank_coefficient"] * rank if rank is not None else nll
    return loss, rank, nll, work


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path, data):
    temp = path.with_suffix(".partial")
    temp.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temp.replace(path)


def run(config_path, job_id):
    import torch
    import minimal
    from collect_identification import torch_save
    from task_data import load

    config = load_json(config_path)
    env = Path(config["approved_env_manifest"])
    if env.name != "ENV_MANIFEST.json" or env.resolve().parent.name != "stage0_env" or minimal.sha(env) != config["approved_env_sha256"]:
        raise ValueError("Approved Stage 0 manifest missing or changed")
    manifest = load_json(env)
    if manifest.get("status") != "PREFLIGHT_OK":
        raise ValueError("Await the formal Stage 0 preflight")
    selected = [row for row in jobs(config.get("enable_historical_bridge", False)) if row["job_id"] == job_id]
    if len(selected) != 1:
        raise ValueError(f"Unknown or disabled E0 job {job_id}")
    job = selected[0]
    mix = source_mix(job, config.get("mixed4"))
    paths = {name: Path(config["pools"][name]["path"]) for name in mix}
    for name, path in paths.items():
        if minimal.sha(path) != config["pools"][name]["sha256"]:
            raise ValueError(f"Pool changed: {name}")
    rank8 = Path(config["rank8"])
    if minimal.sha(rank8) != RANK8_SHA or minimal.sha(Path(config["model"]) / "model.safetensors") != BASE_SHA:
        raise ValueError("Historical weight digest differs")

    anchor_paths = {name: (Path(config[name]), expected) for name, expected in (("historical_t1", T1_SHA), ("historical_mixed", MIXED_SHA))}
    anchors = {}
    for name, (path, want) in anchor_paths.items():
        if minimal.sha(path) != want:
            raise ValueError(f"Historical axis match reference changed: {name}")
        state = torch.load(path, weights_only=True, map_location="cpu")["state"]
        anchors[name] = [state[key].double().flatten() for key in ("out.weight", "encode.weight")]
    initialization = job["init"]
    historical_axis = None
    if job["init"] in {"spec_warm", "norm_rand"}:
        initialization += "/rank8_spectral_top1"
    if job["init"] == "historical_t1_axis":
        historical_axis = Path(config["historical_axis"])
        if minimal.sha(historical_axis) != HISTORICAL_T1_AXIS_SHA:
            raise ValueError("Historical T1 initialization checkpoint changed")
    roster = {"job": job, "mix": mix, "recipe": RECIPE, "config_sha256": minimal.sha(config_path),
              "runner_sha256": minimal.sha(Path(__file__)), "initializer": initialization}
    inputs = {name: load(path) for name, path in paths.items()}
    iterator = {name: streams(rows, job["seed"], name) for name, rows in inputs.items()}
    dest = Path(config["output"]).resolve() / job_id
    allowed = env.resolve().parents[1] / "stage1_e0"
    if not dest.is_relative_to(allowed):
        raise ValueError("E0 output must stay within the approved new stage1_e0 directory")
    protected = {Path(config[key]).resolve() for key in ("archive", "previous", "model")}
    protected.update(path.resolve().parent for path in paths.values())
    if any(dest.is_relative_to(path) for path in protected):
        raise ValueError("E0 output overlaps a historical input directory")
    dest.mkdir(parents=True, exist_ok=True)
    contract = dest / "E0_RUN_CONFIG.json"
    if contract.exists() and load_json(contract) != roster:
        raise ValueError("E0 resumable training inputs differ")
    if not contract.exists():
        save_json(contract, roster)
    last_run = dest / "TRAIN.json"
    if last_run.exists():
        if minimal.sha(dest / "controller.pt") != load_json(last_run)["checkpoint_sha256"]:
            raise ValueError(f"Completed controller altered: {job_id}")
        return

    archive, model, tokenizer, context = minimal.runtime(
        Path(config["archive"]), Path(config["previous"]), Path(config["model"]))
    if context["model_sha256"] != BASE_SHA:
        raise ValueError("Base checkpoint changed during startup")
    torch.manual_seed(job["seed"])
    net = minimal.Minimal("linear", 1, .45).requires_grad_(True)
    configure(net, job["init"], rank8, job["seed"], historical_axis)
    initial = operator_geometry(net, anchors)
    net = net.to(next(model.parameters()).device)
    if sum(p.numel() for p in net.parameters()) != 4096 or any(p.requires_grad for p in model.parameters()):
        raise ValueError("Rank-1 fit requires exactly 4096 trainable controller parameters and a frozen base")
    optimizer = torch.optim.AdamW(net.parameters(), lr=RECIPE["learning_rate"], weight_decay=RECIPE["weight_decay"])
    checkpoint = dest / "resume.pt"
    done, trace, total_work = 0, [], 0
    if checkpoint.exists():
        state = torch.load(checkpoint, weights_only=True, map_location="cpu")
        if state["contract"] != minimal.sha(contract):
            raise ValueError("Checkpoint belongs to a different arm")
        net.load_state_dict(state["model"])
        optimizer.load_state_dict(state["optimizer"])
        done, trace, total_work = state["done"], state["trace"], state["work"]
    for name in mix:
        for _ in range(done * mix[name]):
            next(iterator[name])
    for step in range(done + 1, job["steps"] + 1):
        depth = DEPTHS[(step - 1) % len(DEPTHS)]
        optimizer.zero_grad(set_to_none=True)
        report = {}
        for name, n in mix.items():
            batch = [next(iterator[name]) for _ in range(n)]
            with torch.enable_grad():
                loss, rank, nll, work = score_rows(archive, model, tokenizer, net, batch, depth, job["objective"])
                (loss * n / RECIPE["effective_batch"]).backward()
            total_work += work
            report[name] = {"loss": float(loss.detach()), "rank": float(rank.detach()) if rank is not None else None,
                            "nll": float(nll.detach()) if nll is not None else None}
        magnitude = torch.nn.utils.clip_grad_norm_(net.parameters(), RECIPE["clip"])
        if not torch.isfinite(magnitude):
            raise FloatingPointError(f"Nonfinite gradient at update {step}")
        optimizer.step()
        if step % 70 == 0 or step == job["steps"]:
            trace.append({"step": step, "depth": depth, "gradient_norm": float(magnitude), "objectives": report,
                          **operator_geometry(net, anchors), "padded_token_loops": total_work})
            torch_save(checkpoint, {"contract": minimal.sha(contract), "done": step,
                                    "model": net.state_dict(), "optimizer": optimizer.state_dict(),
                                    "trace": trace, "work": total_work})
    final = dest / "controller.pt"
    minimal.save_net(final, net, dict(arm=job_id, contract_sha256=minimal.sha(contract)))
    (dest / "train_trace.jsonl").write_text("".join(json.dumps(item) + "\n" for item in trace), encoding="utf-8")
    save_json(last_run, {"updates": job["steps"], "padded_token_loops": total_work,
                         "initial_geometry": initial, "checkpoint_sha256": minimal.sha(final)})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    cli = parser.add_subparsers(dest="action", required=True)
    plan = cli.add_parser("plan", help="Print dry-run job IDs without importing GPU dependencies.")
    plan.add_argument("--historical-bridge", action="store_true", help="List two separately reported historical-axis arms.")
    execute = cli.add_parser("run", help="Execute one arm after formal preflight approval.")
    execute.add_argument("--config", type=Path, required=True)
    execute.add_argument("--job-id", required=True)
    args = parser.parse_args()
    if args.action == "plan":
        print(json.dumps({"recipe": RECIPE, "jobs": jobs(args.historical_bridge)}, indent=2))
    else:
        run(args.config, args.job_id)
