"""Build a two-phase E0 dispatcher manifest from approved Stage 0 inputs."""

import argparse
import json
from pathlib import Path

from e0_external_dev import GROUPS, LEGACY_GROUPS
from e0_reuse import jobs, load_json
from stage0_data import digest


DEVICES = {"0": {"host": "old", "local_index": 0},
           "1": {"host": "dual", "local_index": 0},
           "2": {"host": "dual", "local_index": 1}}
EVALUATION_TIME_SCALE = {"0": 1.6, "1": 1.0, "2": 1.0}
HISTORICAL_ANCHORS = ("native", "t1", "t2", "mixed")
CODE = "stage1_e0/code"
BRIDGE = "stage1_e0/E0_CONFIG.json"
WRAPPER = f"{CODE}/run_e0_job.sh"
ENV_MANIFEST = "stage0_env/ENV_MANIFEST.json"
RECEIPT_ROOT = "stage1_e0/dispatcher_receipts"


def local(root, path):
    name = Path(path).resolve().relative_to(root).as_posix()
    if not name or name == ".":
        raise ValueError("Expected a file or subdirectory in the new v3 study")
    return name


def definitions(config, phase, input_sha, weights=None):
    roster = jobs(config.get("enable_historical_bridge", False))
    names = [row["job_id"] for row in roster]
    if phase == "external-dev":
        names = [*names, *HISTORICAL_ANCHORS]
    blocks = []
    gpu_work = dict.fromkeys(DEVICES, 0.)
    for name in names:
        if phase == "train":
            fit = f"{config['fits_relative']}/{name}"
            artifacts = [f"{fit}/{artifact}" for artifact in
                         ("controller.pt", "TRAIN.json", "train_trace.jsonl", "E0_RUN_CONFIG.json")]
            extra = []
        else:
            eval_root = f"stage1_e0/e0_external_dev/{name}"
            artifacts = [f"{eval_root}/DEVELOPMENT.json", *(f"{eval_root}/{group}.jsonl" for group in GROUPS),
                         *(f"{eval_root}/historical/{group}.jsonl" for group in LEGACY_GROUPS)]
            weight = weights.get(name)
            extra = [weight["path"], weight["sha256"]] if weight else []
        blocks.append({"job_id": f"e0.{phase}.{name}",
                       "cmd": ["bash", WRAPPER, phase, BRIDGE, name, *extra],
                       "log_path": f"stage1_e0/logs/{phase}/{name}.log",
                       "done_marker": f"{RECEIPT_ROOT}/{phase}/{name}.json",
                       "input_sha256": dict(input_sha), "artifacts": artifacts})
        if phase == "external-dev":
            # A production fit needs both panels scored. Historical anchors reuse eight receipts.
            # The old card took roughly 1.6 times as long on matched E0 training workloads.
            work = .2 if name in HISTORICAL_ANCHORS else 1.
            gpu = min(DEVICES, key=lambda card: ((gpu_work[card] + work) * EVALUATION_TIME_SCALE[card], card))
            gpu_work[gpu] += work
            blocks[-1]["preferred_gpu"] = gpu
    return {"devices": DEVICES, "jobs": blocks}


def build(root, phase):
    config_path = root / BRIDGE
    config = load_json(config_path)
    approved = root / ENV_MANIFEST
    if (Path(config["approved_env_manifest"]).resolve() != approved
            or digest(approved) != config["approved_env_sha256"]
            or load_json(approved).get("status") != "PREFLIGHT_OK"):
        raise ValueError("Cannot dispatch E0 before the approved, hashed Stage 0 handoff")
    config["fits_relative"] = local(root, config["output"])
    if not config["fits_relative"].startswith("stage1_e0/"):
        raise ValueError("The E0 fit destination must be inside the new stage1_e0 tree")
    source_files = [BRIDGE, ENV_MANIFEST, WRAPPER, f"{CODE}/e0_reuse.py", f"{CODE}/stage0_data.py"]
    if phase == "external-dev":
        source_files.append(f"{CODE}/e0_external_dev.py")
    checks = {name: digest(root / name) for name in source_files}
    if phase == "train":
        return definitions(config, phase, checks)

    weights = {}
    for row in jobs(config.get("enable_historical_bridge", False)):
        name = row["job_id"]
        rel_fit = f"{config['fits_relative']}/{name}"
        fit = root / rel_fit
        marker = root / f"{RECEIPT_ROOT}/train/{name}.json"
        done = load_json(marker)
        train = load_json(fit / "TRAIN.json")
        own = digest(fit / "controller.pt")
        if (done["job_id"] != f"e0.train.{name}" or own != train["checkpoint_sha256"]
                or any(done["artifact_sha256"].get(f"{rel_fit}/{artifact}") != digest(fit / artifact)
                       for artifact in ("controller.pt", "TRAIN.json", "E0_RUN_CONFIG.json", "train_trace.jsonl"))):
            raise ValueError(f"Training artifacts do not match dispatcher receipt: {name}")
        weights[name] = {"path": str(fit / "controller.pt"), "sha256": own}
        checks[local(root, marker)] = digest(marker)
    for name, key in (("t1", "historical_t1"), ("t2", "historical_t2"), ("mixed", "historical_mixed")):
        path = Path(config[key]).resolve()
        weight = digest(path)
        if weight != config["historical_weight_sha256"][name]:
            raise ValueError(f"Frozen historical anchor changed: {name}")
        weights[name] = {"path": str(path), "sha256": weight}
    return definitions(config, phase, checks, weights)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--phase", choices=("train", "external-dev"), required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.root.resolve(), args.phase), indent=2))
