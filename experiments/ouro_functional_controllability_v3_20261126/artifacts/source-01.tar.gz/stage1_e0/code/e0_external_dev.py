"""Evaluate one frozen E0 controller on the v3 external development panel."""

import argparse
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import re
import sys
from types import SimpleNamespace

from e0_reuse import BASE_SHA, load_json, save_json
from stage0_data import digest, items, write_rows


GROUPS = ("sciq_val", "arc_easy_val", "cosmosqa_val", "mmlu_val", "mmlu_pro_val")
LEGACY_GROUPS = ("arc_challenge__candidate", "obqa__candidate", "csqa__candidate",
                 "arc_challenge__content", "csqa__content", "squad__span", "gsm8k__gsm_process", "mmlu__mmlu")


def options_and_gold(row):
    raw = row.get("candidate") or row
    source = raw.get("choices", raw.get("options"))
    labels = source.get("label") if isinstance(source, dict) else None
    options = source["text"] if isinstance(source, dict) else source
    if not options and all(key in raw for key in ("correct_answer", "distractor1", "distractor2", "distractor3")):
        # SciQ stores its answer in separate columns. Choose a reproducible non-gold-dependent order.
        options = sorted([raw["correct_answer"], *(raw[f"distractor{i}"] for i in range(1, 4))])
    if not options and all(f"answer{i}" in raw for i in range(4)):
        options = [raw[f"answer{i}"] for i in range(4)]
    if not isinstance(options, list) or len(options) < 2 or not all(isinstance(x, str) for x in options):
        raise ValueError(f"Missing visible options for {row['sample_id']}")
    gold = raw.get("answer_index", raw.get("answerKey", raw.get("label", raw.get("answer", raw.get("correct_answer", raw.get("correct_option"))))))
    if isinstance(gold, str) and labels is not None and gold in labels:
        index = labels.index(gold)
    elif isinstance(gold, str) and gold in options:
        index = options.index(gold)
    elif isinstance(gold, str) and len(gold) == 1 and "A" <= gold <= "J":
        index = ord(gold) - 65
    else:
        index = int(gold)
    if not 0 <= index < len(options):
        raise ValueError(f"Invalid development target for {row['sample_id']}")
    question = raw.get("question", raw.get("stem", raw.get("query")))
    if not isinstance(question, str) or not question.strip():
        raise ValueError(f"Missing development question for {row['sample_id']}")
    context = row.get("context", row.get("support"))
    if isinstance(context, str) and context.strip() and context not in question:
        question = context.strip() + "\n" + question
    return question, options, index


def candidate_rows(rows):
    selected = []
    for row in rows:
        question, options, index = options_and_gold(row)
        labels = [chr(65 + i) for i in range(len(options))]
        selected.append({"candidate": {"id": row["sample_id"], "question": question,
                                      "choices": {"label": labels, "text": options},
                                      "answerKey": labels[index]}})
    return selected


def letter_rows(rows):
    selected = []
    for row in rows:
        question, options, index = options_and_gold(row)
        if len(options) != 4:
            raise ValueError("MMLU development requires four choices")
        labels = list("ABCD")
        lines = "\n".join(f"{name}. {answer}" for name, answer in zip(labels, options, strict=True))
        topic = row["subject"].replace("_", " ")
        prompt = f"The following are multiple choice questions (with answers) about {topic}.\n\n{question}\n{lines}\nAnswer:"
        selected.append({"id": row["sample_id"], "task": f"mmlu_{row['subject']}", "benchmark": "mmlu",
                         "doc_id": len(selected), "target": index, "choices": labels,
                         "requests": [{"type": "loglikelihood", "args": [prompt, " " + label], "idx": option}
                                      for option, label in enumerate(labels)]})
    return selected


def pro_items(rows, tokenizer, historical):
    result = []
    for row in rows:
        question, options, index = options_and_gold(row)
        labels = [chr(65 + i) for i in range(len(options))]
        if len(options) > 10:
            raise ValueError("Historical MMLU-Pro parser supports at most 10 choices")
        lines = "\n".join(f"{name}. {answer}" for name, answer in zip(labels, options, strict=True))
        prompt = "Choose the correct option. Return its letter only.\n\nQuestion: " + question + "\n" + lines + "\nAnswer:"
        result.append(historical.Item(row["sample_id"], prompt, labels[index],
                                      tokenizer.encode(prompt, add_special_tokens=False), len(options)))
    return result


def registered_historical(config):
    files = config["legacy_dev"]
    for key in ("runner", "protocol"):
        if digest(Path(files[key])) != files[f"{key}_sha256"]:
            raise ValueError(f"Historical development {key} differs")
    spec = importlib.util.spec_from_file_location("ouro_legacy_dev", files["runner"])
    legacy = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(legacy)
    panel = legacy.register(SimpleNamespace(panel=Path(files["panel"]), mmlu=Path(files["mmlu"])))
    protocol = load_json(Path(files["protocol"]))
    cohorts = {f"{dataset}/{mode}": {"ids": [row.get("sample_id", row.get("id")) for row in rows],
                                      "primary": legacy.KEYS[mode]}
               for (dataset, mode), rows in panel.items()}
    if cohorts != protocol["cohorts"] or protocol["model_sha256"] != BASE_SHA or protocol["depth"] != 4:
        raise ValueError("Historical development cohort or scoring depth differs")
    payload = {f"{dataset}/{mode}": rows for (dataset, mode), rows in panel.items()}
    identity = sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()
    if files.get("registered_sha256") not in (None, identity):
        raise ValueError("Historical development inputs changed since registration")
    return legacy, panel, identity


def archived_historical(config, arm, checkpoint, name, ids, metric):
    if arm not in {"native", "t1", "t2", "mixed"}:
        return None
    frozen = Path(config["legacy_dev"]["protocol"])
    protocol = load_json(frozen)
    if arm not in protocol["checkpoint_sha256"] or protocol["checkpoint_sha256"][arm] != checkpoint:
        return None
    receipt = frozen.parent / f"{name}__{arm}.json"
    path = receipt.with_suffix(".jsonl")
    if not receipt.is_file():
        return None
    stamp = load_json(receipt)
    if stamp["protocol_sha256"] != digest(frozen) or stamp["sha256"] != digest(path):
        raise ValueError(f"Archived historical development receipt changed at {receipt}")
    rows = list(items(path))
    score = sum(row["metrics"][metric] for row in rows) / len(rows)
    if [row["id"] for row in rows] != ids or stamp["n"] != len(rows) or abs(stamp["value"] - score) > 1e-12:
        raise ValueError(f"Archived historical development cohort differs at {receipt}")
    return rows, {"reused_from": str(receipt), "archived_evaluation_cost": stamp["cost"]}


def prediction_checkpoint(path, identity, ids, produce):
    marker = path.with_suffix(".receipt.json")
    if marker.exists():
        record = load_json(marker)
        if (record["identity"] != identity or record["predictions"]["sha256"] != digest(path)
                or record["predictions"]["rows"] != len(ids)):
            raise ValueError(f"Development checkpoint changed: {path}")
        rows = list(items(path))
        if [row["id"] for row in rows] != ids:
            raise ValueError(f"Development checkpoint population changed: {path}")
        return rows, record["cost"], record["predictions"]
    rows, cost = produce()
    by_id = {row["id"]: row for row in rows}
    if len(rows) != len(ids) or set(ids) != set(by_id):
        raise ValueError(f"Scorer returned a different cohort: {path}")
    ordered = [by_id[identifier] for identifier in ids]
    temporary = path.with_suffix(".jsonl.partial")
    record = write_rows(temporary, ordered)
    temporary.replace(path)
    save_json(marker, {"identity": identity, "cost": cost, "predictions": record})
    return ordered, cost, record


def evaluate(args):
    config = load_json(args.config)
    preflight = Path(config["approved_env_manifest"])
    if preflight.name != "ENV_MANIFEST.json" or preflight.resolve().parent.name != "stage0_env" or digest(preflight) != config["approved_env_sha256"]:
        raise ValueError("Approved Stage 0 manifest missing or changed")
    approved = load_json(preflight)
    if approved.get("status") != "PREFLIGHT_OK":
        raise ValueError("Await Stage 0 preflight approval")
    sys.path[:0] = [config[key] for key in ("dev_stage2_code", "unified", "followup")]
    import torch
    import minimal
    from controller_io import controller
    import evaluate_generation as candidate
    from evaluate_benchmarks import candidate_row, mmlu_metrics
    import generation_followup_run as historical
    import seven_unified
    import stage2_score

    legacy, legacy_panel, legacy_identity = registered_historical(config)
    if legacy_identity != config["legacy_dev"]["registered_sha256"]:
        raise ValueError("Historical development inputs must be frozen before scoring")
    protocol = Path(config["mmlu_scoring_settings"])
    if digest(protocol) != config["mmlu_scoring_settings_sha256"]:
        raise ValueError("Historical MMLU scoring settings changed")
    params = load_json(protocol)
    source = Path(config["external_development"]).resolve()
    if source.name != "UNIFIED_EXT_DEV":
        raise ValueError("E0 external evaluation only reads UNIFIED_EXT_DEV")
    target = preflight.resolve().parents[1] / "stage1_e0" / "e0_external_dev" / args.arm
    base = Path(config["model"])
    if digest(base / "model.safetensors") != BASE_SHA:
        raise ValueError("Base checkpoint differs")
    weight = None if args.arm == "native" else args.weight
    if args.arm != "native" and (weight is None or args.weight_sha256 != digest(weight)):
        raise ValueError("Controller digest differs")
    archive, model, tok, hardware = minimal.runtime(Path(config["archive"]), Path(config["previous"]), base)
    device = next(model.parameters()).device
    net = controller(weight, device) if weight is not None else None
    encoder = stage2_score.HarnessEncoder(tok, params["max_length"])
    target.mkdir(parents=True, exist_ok=True)
    receipt = {"arm": args.arm, "checkpoint_sha256": args.weight_sha256, "development_sha256": {},
               "metrics": {}, "predictions": {}}
    checkpoint_identity = {"config_sha256": digest(args.config), "runner_sha256": digest(Path(__file__)),
                           "checkpoint_sha256": args.weight_sha256, "arm": args.arm}
    for name in GROUPS:
        filename = source / f"{name}.jsonl"
        frozen = approved["frozen_data"][f"UNIFIED_EXT_DEV/{name}.jsonl"]
        input_sha = digest(filename)
        if input_sha != frozen["sha256"] or input_sha != config["external_development_sha256"][name]:
            raise ValueError(f"External development input changed: {name}")
        rows = list(items(filename))
        ids = [row["sample_id"] for row in rows]
        if len(ids) != frozen["rows"] or len(set(ids)) != len(ids):
            raise ValueError(f"Unexpected cohort: {name}")
        @torch.inference_mode()
        def score_external():
            if name == "mmlu_val":
                scored, cost = seven_unified.shard_score(stage2_score, minimal, model, encoder, net,
                                                          letter_rows(rows), params, device)
                return [candidate_row(row, seven_unified.UNIFIED) for row in scored], cost
            if name == "mmlu_pro_val":
                if digest(Path(historical.__file__)) != config["mmlu_pro_decoder_sha256"]:
                    raise ValueError("Historical MMLU-Pro decoder changed")
                model.model.total_ut_steps = 4
                max_new, batch = historical.TASKS["mmlu_pro"]
                result = []
                for block in historical.batches(pro_items(rows, tok, historical), max_new, batch, 14500):
                    raw, _ = historical.greedy("mmlu_pro", model, tok, block, "feedback" if net else "native",
                                                net, 1., max_new, historical.cache_type(model))
                    result.extend(mmlu_metrics(raw, block, historical))
                return result, {}
            return candidate.candidates(archive, model, tok, net, candidate_rows(rows), 4, 12)

        metrics = {"mmlu_val": ["acc"], "mmlu_pro_val": ["correct", "parseable"]}.get(name, ["acc_norm"])
        ordered, _, output = prediction_checkpoint(target / f"{name}.jsonl",
                                                    dict(checkpoint_identity, cohort_sha256=input_sha),
                                                    ids, score_external)
        receipt["development_sha256"][name] = input_sha
        receipt["metrics"][name] = {key: sum(row["metrics"][key] for row in ordered) / len(ids) for key in metrics}
        receipt["predictions"][name] = output
        print("EXTERNAL_DEV", args.arm, name, len(ids), receipt["metrics"][name], flush=True)

    receipt["historical"] = {"registered_sha256": legacy_identity, "metrics": {}, "predictions": {}}
    for (dataset, mode), rows in legacy_panel.items():
        name = f"{dataset}__{mode}"
        ids = [row.get("sample_id", row.get("id")) for row in rows]
        @torch.inference_mode()
        def score_historical():
            reuse = archived_historical(config, args.arm, args.weight_sha256, name, ids, legacy.KEYS[mode])
            if reuse is not None:
                return reuse
            if mode == "mmlu":
                raw, cost = seven_unified.shard_score(stage2_score, minimal, model, encoder, net, rows, params, device)
                return [candidate_row(row, seven_unified.UNIFIED) for row in raw], cost
            if mode == "candidate":
                return legacy.candidates(archive, model, tok, net, rows, 4, 12)
            cap, batch = {"gsm_process": (192, 24), "content": (24, 48), "span": (24, 32)}[mode]
            return legacy.generate(archive, model, tok, net, rows, mode, 4, batch, cap)

        result, cost, output = prediction_checkpoint(target / "historical" / f"{name}.jsonl",
                                                     dict(checkpoint_identity, registered_sha256=legacy_identity),
                                                     ids, score_historical)
        record = legacy.structured(result, legacy.KEYS[mode])
        receipt["historical"]["metrics"][name] = dict(**record, cost=cost)
        receipt["historical"]["predictions"][name] = output
        print("HISTORICAL_DEV", args.arm, name, record["n"], record["value"], flush=True)
    save_json(target / "DEVELOPMENT.json", receipt)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--arm", required=True)
    parser.add_argument("--weight", type=Path)
    parser.add_argument("--weight-sha256")
    a = parser.parse_args()
    if re.fullmatch(r"[a-zA-Z0-9_.-]+", a.arm) is None or a.arm in {".", ".."}:
        parser.error("Expected a single arm identifier")
    evaluate(a)
