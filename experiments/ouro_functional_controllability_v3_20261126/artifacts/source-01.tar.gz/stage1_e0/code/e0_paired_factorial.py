import json
from hashlib import file_digest
from pathlib import Path
from itertools import product
import numpy as np

work=Path("stage1_e0")
seeds=(26112601,26112602)
inits=("cold","spec_warm")
pools=("arc","arc_csqa")
losses=("rank","nll_rank")
keys={"sciq_val":"acc_norm","arc_easy_val":"acc_norm","cosmosqa_val":"acc_norm",
      "mmlu_val":"acc","mmlu_pro_val":"correct"}

def sha(path):
    with path.open("rb") as data:
        return file_digest(data,"sha256").hexdigest()

def read(arm,task):
    folder=work/"e0_external_dev"/arm
    report=json.loads((folder/"DEVELOPMENT.json").read_text())
    path=folder/f"{task}.jsonl"
    digest=sha(path)
    if digest!=report["predictions"][task]["sha256"]:
        raise ValueError(f"Completed prediction file was modified: {path}")
    rows=[json.loads(line) for line in path.read_text().splitlines()]
    if report["predictions"][task]["rows"]!=len(rows):
        raise ValueError("Evaluation cohort has missing rows")
    return rows,digest

def bootstrap(array,seed):
    random=np.random.default_rng(seed)
    return np.concatenate([array[random.integers(len(array),size=(size,len(array)))].mean(axis=1)
                           for size in (500,)*20])

def record(array,seed):
    boot=bootstrap(array,seed)
    return {"mean_pp":100*float(array.mean()),"ci95_pp":(100*np.quantile(boot,[.025,.975])).tolist(),
            "n_items":len(array)},boot

contrasts={
 "NLL_minus_rank":[((i,p,"rank",s),(i,p,"nll_rank",s)) for i,p,s in product(inits,pools,seeds)],
 "ARC_CSQA_minus_ARC":[((i,"arc",loss,s),(i,"arc_csqa",loss,s)) for i,loss,s in product(inits,losses,seeds)],
 "spectral_minus_cold":[(("cold",p,loss,s),("spec_warm",p,loss,s)) for p,loss,s in product(pools,losses,seeds)],
}
main={}
raw_boot={}
source={}
pro_pairs={}
for t,task in enumerate(keys):
    core={}
    for i,p,l,s in product(inits,pools,losses,seeds):
        cell=f"core.{i}.{p}.{l}.840.{s}"
        core[i,p,l,s],source[f"{cell}/{task}"]=read(cell,task)
    identity=[(r["id"],r["gold"]) for r in next(iter(core.values()))]
    if any([(r["id"],r["gold"]) for r in rows]!=identity for rows in core.values()):
        raise ValueError(f"Training arms are not paired across the frozen {task} cohort")
    task_data={i:np.asarray([r["metrics"][keys[task]] for r in rows],dtype=float) for i,rows in core.items()}
    main[task]={}
    for effect,comparisons in contrasts.items():
        vector=np.stack([task_data[new]-task_data[old] for old,new in comparisons]).mean(axis=0)
        main[task][effect],boot=record(vector,261126809+t)
        raw_boot.setdefault(effect,[]).append(boot)
    if task=="mmlu_pro_val":
        pairs=contrasts["NLL_minus_rank"]
        for old,new in pairs:
            pairs_i=list(zip(core[old],core[new],strict=True))
            enabled={category:[(a,b) for a,b in pairs_i if (bool(a["metrics"]["parseable"]),bool(b["metrics"]["parseable"]))==states]
                     for category,states in {"both_legal":(True,True),"lost_legal":(True,False),
                                            "gained_legal":(False,True),"both_illegal":(False,False)}.items()}
            for label,entries in enabled.items():
                stats=pro_pairs.setdefault(label,{"n_cell_items":0,"rank_correct":0,"joint_correct":0})
                stats["n_cell_items"]+=len(entries)
                stats["rank_correct"]+=sum(int(a["metrics"]["correct"]) for a,b in entries)
                stats["joint_correct"]+=sum(int(b["metrics"]["correct"]) for a,b in entries)
        assert sum(p["n_cell_items"] for p in pro_pairs.values())==len(identity)*len(pairs)

overall={}
for effect, boot in raw_boot.items():
    vector=np.mean(np.stack(boot),axis=0)
    means={task:main[task][effect]["mean_pp"] for task in keys}
    no_pro=np.mean(np.stack([values for task,values in zip(keys,boot,strict=True) if task!="mmlu_pro_val"]),axis=0)
    overall[effect]={"equal_task_mean_pp":sum(means.values())/len(means),
                     "stratified_question_bootstrap_ci95_pp":(100*np.quantile(vector,[.025,.975])).tolist(),
                      "mmlu_pro_excluded_mean_pp":sum(v for k,v in means.items() if k!="mmlu_pro_val")/4,
                     "mmlu_pro_excluded_bootstrap_ci95_pp":(100*np.quantile(no_pro,[.025,.975])).tolist()}
pin=work/"E0_VERDICT.json"
official=json.loads(pin.read_text())
assert abs(official["nll_hijack_effect_pp"]-overall["NLL_minus_rank"]["equal_task_mean_pp"])<1e-10
assert abs(official["data_effect_pp"]-overall["ARC_CSQA_minus_ARC"]["equal_task_mean_pp"])<1e-10
for values in pro_pairs.values():
    values["joint_minus_rank_correct"]=values["joint_correct"]-values["rank_correct"]
result={"scope":"additional paired E0 external development diagnostics using the original 16 factorial arms",
        "test_accessed":False,"n_bootstrap":10000,"seed_conditioning":"Both fixed training seeds stay matched; uncertainty resamples shared questions within each task.",
        "e0_verdict_sha256":sha(pin),"task_effects":main,"macro_effects":overall,
        "mmlu_pro_objective_legal_transitions":pro_pairs,"prediction_sha256":source}
path=work/"E0_FACTORIAL_PAIRED_DIAGNOSTIC.json"
pending=path.with_suffix(".partial")
pending.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
pending.replace(path)
print("E0_FACTORIAL_PAIRED_DIAGNOSTIC",sha(path))
print(json.dumps({"nll":overall["NLL_minus_rank"],"parseable":pro_pairs,
                  "tasks":{k:v["NLL_minus_rank"] for k,v in main.items()}},ensure_ascii=False))
