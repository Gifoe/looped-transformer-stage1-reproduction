"""Bind E0 to the verified development inputs and the approved Stage 0 receipt."""

import argparse
from pathlib import Path

from e0_external_dev import GROUPS, options_and_gold, registered_historical
from e0_reuse import jobs, load_json, save_json
from stage0_data import digest, items


def run(root, approved):
    stage = root / "stage0_env"
    e0 = root / "stage1_e0"
    config = load_json(e0 / "code/e0_config.template.json")
    data = config["legacy_dev"]
    _, _, data["registered_sha256"] = registered_historical(config)
    config["mixed4"] = ["arc_challenge", "csqa", "squad", "gsm8k"]
    config["enable_historical_bridge"] = True
    config["mixed4_provenance"] = "Historical Advantage Mixed run: ARC-Challenge, CommonsenseQA, SQuAD and GSM8K."
    if approved:
        manifest = stage / "ENV_MANIFEST.json"
        stamp = load_json(manifest)
        if stamp["status"] != "PREFLIGHT_OK":
            raise ValueError("Stage 0 does not have an approved manifest")
        files = stamp["frozen_data"]
        source = stage
        config["approved_env_sha256"] = digest(manifest)
        target = e0 / "E0_CONFIG.json"
        config["status"] = "PREFLIGHT_BOUND"
    else:
        source = stage / "data_draft"
        stamp = load_json(source / "DATA_DRAFT_MANIFEST.json")
        if stamp["status"] != "DATA_DRAFT_ONLY":
            raise ValueError("Stage 0 draft did not complete")
        files = stamp["files"]
        target = e0 / "E0_CONFIG.data-ready.json"
        config["status"] = "DATA_READY_AWAITING_PREFLIGHT"
    for name in GROUPS:
        relative = f"UNIFIED_EXT_DEV/{name}.jsonl"
        pin = files[relative]
        path = source / relative
        if digest(path) != pin["sha256"]:
            raise ValueError(f"External development digest drifted for {name}")
        ids = set()
        for row in items(path):
            question, options, gold = options_and_gold(row)
            if name == "mmlu_val" and (len(options) != 4 or not row.get("subject")):
                raise ValueError(f"Invalid MMLU prompt schema {row['sample_id']}")
            if name == "mmlu_pro_val" and len(options) > 10:
                raise ValueError(f"Invalid MMLU-Pro prompt schema {row['sample_id']}")
            ids.add(row["sample_id"])
        if len(ids) != pin["rows"]:
            raise ValueError(f"Unexpected or repeated IDs in {name}")
        config["external_development_sha256"][name] = pin["sha256"]
        print(name, len(ids), pin["sha256"], flush=True)
    if target.exists() and load_json(target) != config:
        raise ValueError(f"An earlier E0 configuration already differs at {target}")
    if not target.exists():
        save_json(target, config)
    print(config["status"], target, digest(target), "arms", len(jobs(True)), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--approved", action="store_true")
    args = parser.parse_args()
    run(args.root.resolve(), args.approved)
