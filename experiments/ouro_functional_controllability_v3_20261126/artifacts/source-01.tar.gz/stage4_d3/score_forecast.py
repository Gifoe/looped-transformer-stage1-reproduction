"""Score the pre-registered source forecasts against the common external panel."""

import argparse
from datetime import datetime, timezone
from hashlib import file_digest,sha256
import itertools
import json
from pathlib import Path

import numpy as np
from scipy.stats import rankdata


PRIMARY = {"sciq_val":"acc_norm","arc_easy_val":"acc_norm","cosmosqa_val":"acc_norm",
           "mmlu_val":"acc","mmlu_pro_val":"correct"}
INITS=("Cold_FixedWork","D2Warm_FixedWork")


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream,"sha256").hexdigest()


def file_digest_payload(values):
    return sha256(json.dumps(values,ensure_ascii=False,separators=(",",":")).encode()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def center_corr(left,right):
    x=left-left.mean(axis=-1,keepdims=True)
    y=right-right.mean(axis=-1,keepdims=True)
    den=np.sqrt((x*x).sum(-1)*(y*y).sum(-1))
    return np.divide((x*y).sum(-1),den,out=np.full_like(den,np.nan,dtype=float),where=den>0)


def correlations(x,y):
    up,down=np.triu_indices(x.shape[-1],k=1)
    a=np.sign(x[...,up]-x[...,down])
    b=np.sign(y[...,up]-y[...,down])
    den=np.sqrt(np.abs(a).sum(-1)*np.abs(b).sum(-1))
    return dict(pearson=center_corr(x,y), spearman=center_corr(rankdata(x,axis=-1),rankdata(y,axis=-1)),
                kendall=np.divide((a*b).sum(-1),den,out=np.full_like(den,np.nan,dtype=float),where=den>0))


def prospective_metrics(x,y,names,seed):
    est=correlations(x,y)
    r=np.random.default_rng(seed)
    sample=r.integers(len(names),size=(10000,len(names)))
    intervals=correlations(x[sample],y[sample])
    out={}
    for statistic,point in est.items():
        valid=intervals[statistic][np.isfinite(intervals[statistic])]
        out[statistic]=dict(estimate=float(point) if np.isfinite(point) else None,
                           ci95=np.quantile(valid,[.025,.975]).tolist() if len(valid) else None,
                           valid_bootstrap_replicates=len(valid))
    predicted=sorted(range(len(names)),key=lambda i:(-x[i],names[i]))
    actual=sorted(range(len(names)),key=lambda i:(-y[i],names[i]))
    k=min(3,len(names))
    out["top3_matches"]=len(set(predicted[:k])&set(actual[:k]))
    out["top1_regret_pp"]=float(y[actual[0]]-y[predicted[0]])
    out["predicted_ranking"]=[names[i] for i in predicted]
    out["actual_ranking"]=[names[i] for i in actual]
    if len(names)==4:
        perm=np.asarray(list(itertools.permutations(y)))
        null=correlations(np.broadcast_to(x,perm.shape),perm)["spearman"]
        out["exact_spearman_permutation_p"]=(float(np.mean(np.abs(null)>=abs(est["spearman"])-1e-12))
                                               if np.isfinite(est["spearman"]) else None)
    return out


def required_scores(path, expected=None):
    receipt=read(path)
    recorded=receipt["predictions"]
    values={}
    identity={}
    for cohort,metric in PRIMARY.items():
        rows_path=path.with_name(f"{cohort}.jsonl")
        addressed=recorded[cohort]
        if sha(rows_path)!=addressed["sha256"]:
            raise ValueError(f"Malformed D3 raw prediction receipt at {rows_path}")
        with rows_path.open(encoding="utf-8") as stream:
            rows=[json.loads(line) for line in stream if line.strip()]
        marks=[(row["id"],row["gold"]) for row in rows]
        if not rows or len(rows)!=addressed["rows"] or len({i for i,_ in marks})!=len(rows):
            raise ValueError(f"Missing or repeated development questions at {rows_path}")
        if expected is not None and marks!=expected[cohort]:
            raise ValueError(f"D3 source-training panel changed at {rows_path}")
        accuracy=sum(row["metrics"][metric] for row in rows)/len(rows)
        if not np.isclose(accuracy,receipt["metrics"][cohort][metric],rtol=0,atol=1e-12):
            raise ValueError(f"Summary and raw accuracy differ at {rows_path}")
        values[cohort]=accuracy
        identity[cohort]=marks
    return values,identity


def audit(args):
    locked=read(args.forecast)
    pin=sha(args.forecast)
    if locked["status"]!="FROZEN_BEFORE_SOURCE_TRAINING" or args.forecast.with_suffix(".sha256").read_text().split()[0]!=pin:
        raise ValueError("Forecast was not pre-registered")
    lookup=read(args.outcomes)
    if set(lookup)!=set(locked["per_source"]):
        raise ValueError("All 14 predeclared sources are required")
    native,native_population=required_scores(args.native)
    fit={}
    for source,conditions in lookup.items():
        if set(conditions)!=set(INITS):
            raise ValueError("A source needs both matched initialization regimes")
        fit[source]={}
        for starting,arms in conditions.items():
            if len(arms)!=2:
                raise ValueError("Expected an independent seed pair")
            average=[]
            seeds=set()
            cohort=[]
            for info in arms:
                train=Path(info["train"])
                clip=read(train)
                report=Path(info["development"])
                started=Path(info["first_train_log"])
                first=json.loads(started.read_text())
                scored=read(report)
                if (clip["dataset"]!=source or clip["init"]!=starting or clip["updates"]!=840
                    or clip["forecast_sha256"]!=pin or scored["weight_sha256"]!=clip["checkpoint_sha256"]
                    or scored["panel_sha256"]!=locked["environment_manifest_sha256"]
                    or args.forecast.stat().st_mtime_ns>=started.stat().st_mtime_ns
                    or first["forecast_sha256"]!=pin or
                       datetime.fromisoformat(first["started_utc"])<=datetime.fromisoformat(locked["timestamp_utc"])):
                    raise ValueError(f"Training or evaluation receipt drift: {source}/{starting}")
                seeds.add(clip["seed"])
                observed,_=required_scores(report,native_population)
                delta={task:100*(value-native[task]) for task,value in observed.items()}
                average.append(delta)
                cohort.append(dict(train_sha256=sha(train),development_sha256=sha(report),delta_pp=delta))
            if len(seeds)!=2:
                raise ValueError("A source seed was reused")
            means={task:float(np.mean([x[task] for x in average])) for task in PRIMARY}
            fit[source][starting]=dict(macro_delta_pp=float(np.mean(list(means.values()))),
                cloze_ood_delta_pp=float(np.mean([means[key] for key in list(PRIMARY)[:3]])),
                dataset_delta_pp=means,seed_results=cohort)

    groups=dict(all=list(locked["per_source"]),**locked["partition_groups"])
    findings={}
    for group,names in groups.items():
        if not names:
            raise ValueError("A required prospective evaluation population is empty")
        findings[group]={}
        for starting in INITS:
            values=np.asarray([fit[source][starting]["macro_delta_pp"] for source in names])
            findings[group][starting]={}
            for metric in locked["rankings"]:
                forecast=np.asarray([locked["per_source"][source]["features"][metric] for source in names])
                findings[group][starting][metric]=prospective_metrics(forecast,values,names,261126410)
    output=dict(timestamp_utc=datetime.now(timezone.utc).isoformat(),forecast_sha256=pin,
                native_sha256=sha(args.native),subject_values=fit,group_results=findings,
                common_development_id_label_sha256={cohort:file_digest_payload(group)
                   for cohort,group in native_population.items()})
    args.out.parent.mkdir(parents=True,exist_ok=True)
    tmp=args.out.with_suffix(".partial")
    tmp.write_text(json.dumps(output,indent=2,ensure_ascii=False)+"\n")
    tmp.replace(args.out)
    print("D3_PROSPECTIVE_AUDIT",len(fit),sha(args.out),flush=True)


if __name__=="__main__":
    a=argparse.ArgumentParser(description=__doc__)
    for name in ("forecast","outcomes","native","out"):
        a.add_argument(f"--{name}",type=Path,required=True)
    audit(a.parse_args())

