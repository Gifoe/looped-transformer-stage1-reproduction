"""Evaluate a source-moment write at equal RMS dose on the locked no-label audit."""

import argparse
import json
from pathlib import Path

import torch
from torch import nn
from transformers import AutoModelForCausalLM, AutoTokenizer
import transformers

import d2_orient
from d2_orient import alternate_contexts, expected_terms_batch, same_lengths, split_corpus
from d2_worker import digest, load, save_json, save_pt


class EqualDose(nn.Module):
    def __init__(self, u, w, dose):
        super().__init__()
        self.register_buffer("u",u.float())
        self.register_buffer("w",w.float())
        self.dose=dose

    def inject(self,hidden,placements):
        h=hidden.float()
        sign=(h@self.w).sign()[...,None]
        scaled=sign*self.u*self.dose*h.norm(dim=-1,keepdim=True)
        return (h+scaled*placements[...,None]).to(hidden.dtype)


def prepare_source(shards, reference, destination):
    """Use the original full moments once, then transfer just their verified rank-one factors."""
    if len(shards)!=4:
        raise ValueError("Use exactly the four closed raw source feature folds")
    pooled=None
    count=0
    fingerprints={}
    for path in shards:
        lock=path.with_name("SOURCE_FEATURES.json")
        receipt=json.loads(lock.read_text())
        identity=digest(path)
        if identity!=receipt["resume_sha256"]:
            raise ValueError("Source operator partition changed")
        part=load(path)
        if part["processed"]!=receipt["n"]:
            raise ValueError("Source operator partition population changed")
        sums=part["sums"]["true_receiver"].double()
        pooled=sums if pooled is None else pooled+sums
        count+=part["processed"]
        fingerprints[str(path)]=identity
    if not count:
        raise ValueError("No signed operator moments")
    pooled /= count
    basis=load(reference)["U_FR_32"][:,:16].double()
    ratio=float((basis.mT@pooled).norm()/pooled.norm().clamp_min(1e-20))
    torch.set_num_threads(4)
    left,s,right=torch.linalg.svd(pooled,full_matrices=False)
    payload=dict(u=left[:,0].clone(),w=right[0].clone(),singular_values=s[:32].clone())
    destination.mkdir(parents=True,exist_ok=True)
    axis=destination/"SOURCE_AXIS.pt"
    lock=destination/"PREPARED_SOURCE.json"
    if axis.exists():
        existing=load(axis)
        if any(not torch.equal(payload[name],existing[name]) for name in payload):
            raise ValueError("Prepared factors differ from the certified raw source moments")
    else:
        save_pt(axis,payload)
    record=dict(shard_sha256=fingerprints,cohort=count,p3_ufr_subspace_ratio=ratio,
                axis_sha256=digest(axis),reference_sha256=digest(reference),dtype="float64")
    if lock.exists() and json.loads(lock.read_text())!=record:
        raise ValueError("Resumed compact source data has a different raw fingerprint")
    save_json(lock,record)
    return lock


def run(args):
    ref=args.reference.with_name("D2_SUBSPACE_LOCK.json")
    source_lock=json.loads(ref.read_text())
    if source_lock["controller_sha256"]!=digest(args.reference) or source_lock["audit_sha256"]!=digest(args.audit):
        raise ValueError("P4 must use the independent frozen text audit population")
    if digest(args.model/"model.safetensors")!=args.model_sha256:
        raise ValueError("Frozen base changed")
    args.out.mkdir(parents=True,exist_ok=True)
    prepared=args.prepared if args.prepared else prepare_source(args.shards,args.reference,args.out)
    record=json.loads(prepared.read_text())
    spec=args.out/"SOURCE_AXIS.pt"
    if (prepared.parent!=args.out or record["axis_sha256"]!=digest(spec) or
            record["reference_sha256"]!=digest(args.reference) or len(record["shard_sha256"])!=4):
        raise ValueError("The compact source axis and preserved raw identities must agree")
    anchor=load(spec)
    u,w=anchor["u"],anchor["w"]
    ratio=record["p3_ufr_subspace_ratio"]
    meta=dict(shard_sha256=record["shard_sha256"],cohort=record["cohort"],
              audit_sha256=digest(args.audit),controller_sha256=digest(args.reference),dose=.35,
              beta=.3,seed=26112644,normalization="equal receiver-relative RMS at each active token",
              prepared_source_sha256=digest(prepared),audit_microbatch=1,runner_sha256=digest(Path(__file__)),
              orientation_helper_sha256=digest(Path(d2_orient.__file__)))
    lock=args.out/"UNLABELED_FINITE_LOCK.json"
    if lock.exists() and json.loads(lock.read_text())!=meta:
        raise ValueError("P4 has already started under a different source or dose")
    save_json(lock,meta)
    transformers.utils.import_utils._torchvision_available=False
    tokenizer=AutoTokenizer.from_pretrained(args.model,trust_remote_code=True,local_files_only=True)
    model=AutoModelForCausalLM.from_pretrained(args.model,torch_dtype=torch.bfloat16,
               trust_remote_code=True,local_files_only=True,attn_implementation="sdpa").to("cuda").eval().requires_grad_(False)
    model.model.total_ut_steps=4
    torch.backends.cuda.matmul.allow_tf32=False
    scorer=EqualDose(u,w,.35).cuda()
    cohort=split_corpus(args.audit,tokenizer)
    if len(cohort)!=512:
        raise ValueError("P4 requires the complete 512-document audit sample")
    other=alternate_contexts(cohort,meta["seed"])
    values=[None]*len(cohort)
    waiting=[]
    protocol=digest(lock)
    for i,(key,_,_,_) in enumerate(cohort):
        receipt=args.out/f"row_{i:04d}.json"
        if receipt.is_file():
            row=json.loads(receipt.read_text())
            if row["id"]!=key or row["lock_sha256"]!=protocol:
                raise ValueError("Cached unlabelled audit row differs")
            values[i]=row
        else:
            waiting.append(i)
    done=len(cohort)-len(waiting)
    with torch.no_grad():
        for indexes,stems,foils,suffixes in same_lengths(cohort,other,waiting,meta["audit_microbatch"]):
            measured=expected_terms_batch(model,stems,foils,suffixes,scorer,True)
            for j,i in enumerate(indexes):
                net_pmi=float(measured["net_pmi"][j])
                true=-float(measured["delta_nll"][j])
                row=dict(id=cohort[i][0],net_pmi=net_pmi,delta_real=true,delta_shuffled=true-net_pmi,
                         kl=float(measured["kl"][j]),lock_sha256=protocol)
                save_json(args.out/f"row_{i:04d}.json",row)
                values[i]=row
            advanced=done+len(indexes)
            if advanced//32>done//32 or advanced==len(cohort):
                print("SOURCE_FINITE_PROGRESS",advanced,len(cohort),flush=True)
            done=advanced
    if done!=len(cohort):
        raise ValueError("P4 evaluation did not cover the full no-label audit")
    pmi=sum(row["net_pmi"] for row in values)/len(values)
    kl=sum(row["kl"] for row in values)/len(values)
    decomposition={key:dict(mean=sum(row[key] for row in values)/len(values),
                            count_negative=sum(row[key]<0 for row in values))
                   for key in ("delta_real","delta_shuffled")}
    save_json(args.out/"SOURCE_FINITE_AUDIT.json",dict(meta,
                external_unlabeled_count=len(values),pmi=pmi,kl=kl,p4=pmi-.3*kl,
                pmi_decomposition=decomposition,
                p3_ufr_subspace_ratio=ratio,axis_sha256=digest(spec),lock_sha256=digest(lock)))
    print("UNLABELED_FINITE_SOURCE_COMPLETE",len(values),pmi-.3*kl,flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("model","reference","audit","out"):
        parser.add_argument(f"--{name}",required=True,type=Path)
    parser.add_argument("--model-sha256",required=True)
    formation=parser.add_mutually_exclusive_group(required=True)
    formation.add_argument("--shards",type=Path,nargs="+")
    formation.add_argument("--prepared",type=Path)
    run(parser.parse_args())


if __name__=="__main__":
    main()

