"""Generate D3's complete source roster and separate frozen training dispatches."""
import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import statistics
import sys

from d2_worker import digest, save_json
from forecast_v3 import GENERATIVE, SOURCES


SEEDS=(261126411,261126412)
INITS=("Cold_FixedWork","D2Warm_FixedWork")
B_GROUPS={
    "Top_Signed_True":("signed_true",True),
    "Bottom_Signed_True":("signed_true",False),
    "Top_Signed_Proxy":("signed_proxy",True),
    "Top_Unsigned":("unsigned_matrix",True),
    "Top_Egap_Only":("error_gap",True),
    "Random_N":(None,True),
}
B_SOURCES=("qasc","obqa","boolq","scienceqa","arc_challenge")
SOURCE_SEED=26112641
SUBSET_SEED=26112642
RUNNER=Path(__file__).resolve()
BASE="58872a72616c736595b8b7662079c5b12c5a162ec16eae94f21c348dfa9885af"


def read(path):
    return json.loads(path.read_text())


def rows(path):
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def identity(root):
    env=root/"stage0_env"/"ENV_MANIFEST.json"
    e0=root/"stage1_e0"/"E0_VERDICT.json"
    conf=e0.with_name("E0_CONFIG.json")
    work=root/"stage4_d3"
    reference=root/"stage2_d2"/"D2_REF_OPERATOR.pt"
    ref_lock=reference.with_name("D2_SUBSPACE_LOCK.json")
    no_label=read(ref_lock)
    setup,config=read(env),read(conf)
    if (setup["status"]!="PREFLIGHT_OK" or config["approved_env_sha256"]!=digest(env)
            or no_label["controller_sha256"]!=digest(reference) or not read(e0)):
        raise ValueError("The closed Stage 0, E0, and no-label D2 inputs are required")
    historical=config["pools"]
    pool={}
    audit=env.parent/"UNLABELED_CORPUS"/"audit_unlabeled.jsonl"
    if digest(audit)!=no_label["audit_sha256"]:
        raise ValueError("Independent no-label audit differs from D2")
    for name in SOURCES:
        if name in historical:
            path=Path(historical[name]["path"])
            sha=historical[name]["sha256"]
        else:
            relative=f"PROSPECTIVE_TRAIN_DRAFT/{name}.jsonl"
            path=env.parent/relative
            sha=setup["frozen_data"][relative]["sha256"]
        if digest(path)!=sha:
            raise ValueError(f"Audited training source changed: {name}")
        n=len(rows(path))
        limit=4096 if n>12000 else 0
        if name in B_SOURCES and limit:
            raise ValueError("The exact fixed-size reversal requires a complete scored source")
        pool[name]=dict(path=path,sha=sha,n=n,limit=limit,mode="generation" if name in GENERATIVE else "candidate")
    return env,e0,conf,work,reference,ref_lock,config,audit,pool


def configure(args):
    root=args.root.resolve()
    env,e0,conf,work,reference,ref_lock,config,audit,pool=identity(root)
    hosts={"0":{"host":"old","local_index":0},"1":{"host":"dual","local_index":0},"2":{"host":"dual","local_index":1}}
    work.mkdir(parents=True,exist_ok=True)
    job_list=[]
    dependencies={env,e0,conf,reference,ref_lock,RUNNER}
    model=Path(config["model"])
    forecast=work/"FORECAST_LOCK_V3.json"
    witnesses=work/"FORECAST_INPUTS.json"

    def add(name,filename,flags,outputs,files,seconds):
        module=work/filename
        measured={str(path):digest(path) for path in set(files)|dependencies|{module}}
        job_list.append(dict(job_id=name,cmd=[sys.executable,"-u",str(module),*map(str,flags)],
                 done_marker=str(work/"receipts"/f"{name}.json"),artifacts=[str(path) for path in outputs],
                 log_path=str(work/"logs"/f"{name}.log"),estimated_seconds=seconds,
                 input_sha256={path:val for path,val in measured.items() if Path(path).resolve().is_relative_to(root)},
                 externally_verified_input_sha256={path:val for path,val in measured.items()
                                                  if not Path(path).resolve().is_relative_to(root)}))

    source_plan={}
    for src,info in pool.items():
        folds=[work/"sample_scores"/src/f"fold_{i}" for i in range(4)]
        finite=work/"finite_audit"/src
        source_plan[src]=dict(shards=[str(path/"COLLECT_RESUME.pt") for path in folds],
                              finite=str(finite/"SOURCE_FINITE_AUDIT.json"),n=info["n"],
                              n_used=info["limit"] or info["n"])
        if args.phase=="features":
            for slot,path in enumerate(folds):
                micro=1 if src in {"race","squad","gsm8k"} else 4
                add(f"d3.features.{src}.{slot}","collect_signed.py",
                    ["--source",info["path"],"--source-sha256",info["sha"],"--model",model,"--model-sha256",BASE,
                     "--archive",config["archive"],"--previous",config["previous"],"--reference",reference,"--out",path,
                     "--dataset",src,"--mode",info["mode"],"--batch",micro,"--limit",info["limit"],
                     "--folds",4,"--fold",slot,"--seed",SOURCE_SEED],
                    [path/"COLLECT_RESUME.pt",path/"SCORES.jsonl",path/"SOURCE_FEATURES.json",path/"COLLECT_LOCK.json"],
                    [info["path"],work/"d3_scores.py"],.12*(info["limit"] or info["n"])*(2 if micro==1 else 1))
        elif args.phase=="finite":
            shards=[Path(path) for path in source_plan[src]["shards"]]
            source_files=shards+[p.with_name("SOURCE_FEATURES.json") for p in shards]
            add(f"d3.finite.{src}","audit_source_finite.py",
                ["--model",model,"--model-sha256",BASE,"--reference",reference,"--audit",audit,"--out",finite,
                 "--shards",*shards],
                [finite/"SOURCE_FINITE_AUDIT.json",finite/"SOURCE_AXIS.pt",finite/"UNLABELED_FINITE_LOCK.json"],
                [*source_files,audit,root/"stage2_d2"/"d2_orient.py"],240)

    if witnesses.exists() and read(witnesses)!=source_plan:
        raise ValueError("The source access and feature sizes cannot change")
    if not witnesses.exists():
        save_json(witnesses,source_plan)
    if args.phase.startswith("train"):
        authority=read(forecast)
        if authority["status"]!="FROZEN_BEFORE_SOURCE_TRAINING" or forecast.with_suffix(".sha256").read_text().split()[0]!=digest(forecast):
            raise ValueError("D3 training cannot start before the authentic forecast freeze")
        if authority["e0_verdict_sha256"]!=digest(e0):
            raise ValueError("The frozen E0 verdict has changed")
        outcomes={}
        for src,info in pool.items():
            roster="A" if args.phase=="train_a" else "B"
            slots=INITS if roster=="A" or src in {"qasc","boolq"} else INITS[:1]
            if roster=="B" and src not in B_SOURCES:
                continue
            outcomes[src]={label:[] for label in slots}
            groups=("full_pool",) if roster=="A" else tuple(B_GROUPS)
            for name in groups:
                selection=work/"sample_subsets"/src/f"{name}.json"
                for init in slots:
                    for seed in SEEDS:
                        target=work/f"fits_{roster.lower()}"/src/name/init/str(seed)
                        flags=["--forecast",forecast,"--reference",reference,"--e0-config",conf,"--source",info["path"],
                               "--out",target,"--dataset",src,"--init",init,"--seed",seed]
                        inputs=[forecast,forecast.with_suffix(".sha256"),info["path"],work/"train_source.py",
                                root/"tools"/"score_shared_dev.py"]
                        if roster=="B":
                            flags += ["--subset",selection]
                            inputs.append(selection)
                        add(f"d3.train.{roster.lower()}.{src}.{name}.{init}.{seed}","run_source_arm.py",flags,
                            [target/"TRAIN.json",target/"controller.pt",target/"dev"/"DEVELOPMENT.json",
                             target/"train_source_started.json"],inputs,
                            500 if roster=="A" else 330)
                        outcomes[src][init].append(dict(train=str(target/"TRAIN.json"),
                          development=str(target/"dev"/"DEVELOPMENT.json"),first_train_log=str(target/"train_source_started.json"),
                          subset=name,seed=seed))
        outfile=work/f"OUTCOMES_{roster}.json"
        if outfile.exists() and read(outfile)!=outcomes:
            raise ValueError("The frozen source outcome roster cannot change")
        save_json(outfile,outcomes)

    if args.phase=="subsets":
        sets={}
        if forecast.with_suffix(".sha256").read_text().split()[0]!=digest(forecast):
            raise ValueError("The signed score subset must bind the preregistered forecast")
        for src in B_SOURCES:
            info=pool[src]
            sources=source_plan[src]
            raw=[]
            checks={}
            for fold in sources["shards"]:
                path=Path(fold).with_name("SCORES.jsonl")
                sha=digest(path)
                if read(path.with_name("SOURCE_FEATURES.json"))["score_sha256"]!=sha:
                    raise ValueError("The per-question signed scores changed")
                checks[str(path)]=sha
                raw.extend(rows(path))
            if len({x["id"] for x in raw})!=info["n"] or len(raw)!=info["n"]:
                raise ValueError(f"Incomplete full-pool D3-B scores: {src}")
            n=500 if src=="arc_challenge" else 512
            sets[src]={}
            for name,(field,descending) in B_GROUPS.items():
                order=(sorted(raw,key=lambda x:(-x[field] if descending else x[field],x["id"])) if field else
                       sorted(raw,key=lambda x:sha256(f"{SUBSET_SEED}:{src}:{x['id']}".encode()).hexdigest()))
                picked=order[:n]
                marker=work/"sample_subsets"/src/f"{name}.json"
                marker.parent.mkdir(parents=True,exist_ok=True)
                output=dict(source_sha256=info["sha"],forecast_sha256=digest(forecast),feature_scores_sha256=checks,
                            source=src,method=name,n=n,sample_ids=[item["id"] for item in picked],
                            average_signed_true=statistics.mean(item["signed_true"] for item in picked),
                            mean_signed_proxy=statistics.mean(item["signed_proxy"] for item in picked),
                            average_native_error=statistics.mean(item["error_gap"] for item in picked))
                if marker.exists() and read(marker)!=output:
                    raise ValueError("The causal reversal group cannot change")
                save_json(marker,output)
                sets[src][name]=output
            if set(sets[src]["Top_Signed_True"]["sample_ids"])&set(sets[src]["Bottom_Signed_True"]["sample_ids"]):
                raise ArithmeticError("Top and bottom cohorts must be mutually exclusive")
        print("D3B_SUBSETS",sum(len(x) for x in sets.values()),flush=True)
        return

    expected={"features":56,"finite":14,"train_a":56,"train_b":84}
    if len(job_list)!=expected[args.phase] or len({job["job_id"] for job in job_list})!=len(job_list):
        raise ValueError("Incomplete or duplicate D3 task roster")
    load={slot:0. for slot in hosts}
    multiplier={"0":1.55,"1":1.,"2":1.}
    for row in sorted(job_list,key=lambda x:-x["estimated_seconds"]):
        slot=min(hosts,key=lambda x:load[x]+row["estimated_seconds"]*multiplier[x])
        row["preferred_gpu"]=slot
        load[slot]+=row["estimated_seconds"]*multiplier[slot]
    manifest=dict(devices=hosts,jobs=job_list,phase=args.phase)
    path=args.out
    if path.exists() and read(path)!=manifest:
        raise ValueError("The dispatch cannot change once sealed")
    save_json(path,manifest)
    print("D3_PLAN",args.phase,len(job_list),digest(path),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,required=True)
    parser.add_argument("--out",type=Path,required=True)
    parser.add_argument("--phase",required=True,choices=("features","finite","train_a","train_b","subsets"))
    configure(parser.parse_args())

