"""Prepare exact rank-one finite-audit inputs on the feature host."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
from types import SimpleNamespace

import torch

from audit_source_finite import prepare_source
from d2_worker import digest, save_json
from plan_d3 import configure


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def run(root, out):
    work=root/"stage4_d3"
    verified=work/"D3_FEATURES_VERIFIED.json"
    if read(verified)["n_folds"]!=56:
        raise ValueError("Compact finite audits require the closed, exact raw feature roster")
    original=work/"D3_FINITE_RAW_REFERENCE_DISPATCH.json"
    configure(SimpleNamespace(phase="finite",root=root,out=original))
    raw=read(original)
    plan=deepcopy(raw)
    torch.set_num_threads(4)
    for job in plan["jobs"]:
        command=job["cmd"]
        slot=command.index("--shards")
        shards=[Path(name) for name in command[slot+1:]]
        destination=Path(command[command.index("--out")+1])
        reference=Path(command[command.index("--reference")+1])
        prepared=prepare_source(shards,reference,destination)
        axis=destination/"SOURCE_AXIS.pt"
        witnesses=set(shards)|{p.with_name("SOURCE_FEATURES.json") for p in shards}
        # All original physical and evaluation flags retain their bytes.
        remove={str(p) for p in witnesses}
        if not remove <= job["input_sha256"].keys():
            raise ValueError("The original raw finite-input pins are incomplete")
        updated={path:sha for path,sha in job["input_sha256"].items() if path not in remove}
        for path in (prepared,axis,verified,Path(__file__).resolve()):
            updated[str(path)]=digest(path)
        job["input_sha256"]=updated
        job["cmd"]=command[:slot]+["--prepared",str(prepared)]
    if len(plan["jobs"])!=14:
        raise ValueError("All 14 original finite audits are required")
    if out.exists() and read(out)!=plan:
        raise ValueError("The frozen compact finite dispatcher changed")
    save_json(out,plan)
    review=work/"D3_FINITE_TRANSPORT_AUDIT.json"
    value={
        "original_raw_dispatch_sha256":digest(original),"compact_dispatch_sha256":digest(out),
        "closed_feature_roster_sha256":digest(verified),
        "transform":"Unchanged sum, FP64 SVD, receiver projection ratio, and the four raw shard SHA values",
        "raw_data_remains_primary":True,"finite_audit_count":14,
        "scientific_protocol_changed":False,
    }
    if review.exists() and read(review)!=value:
        raise ValueError("The finite transport manifest has drifted")
    save_json(review,value)
    print("D3_COMPACT_FINITE_READY",len(plan["jobs"]),digest(out),digest(review),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,required=True)
    parser.add_argument("--out",type=Path,required=True)
    args=parser.parse_args()
    run(args.root.resolve(),args.out.resolve())
