"""Audit all matched D3-B subset arms on the frozen external development panel."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path

import numpy as np

from d2_worker import digest, save_json
from plan_d3 import B_GROUPS, B_SOURCES, INITS, SEEDS
from score_forecast import PRIMARY


CONTRASTS=(
    ("top_minus_bottom","Top_Signed_True","Bottom_Signed_True"),
    ("true_minus_proxy","Top_Signed_True","Top_Signed_Proxy"),
    ("signed_minus_unsigned","Top_Signed_True","Top_Unsigned"),
    ("signed_minus_difficulty","Top_Signed_True","Top_Egap_Only"),
    ("signed_minus_random","Top_Signed_True","Random_N"),
)


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def items(path):
    with path.open(encoding="utf-8") as f:
        yield from (json.loads(line) for line in f if line.strip())


def inspect(arm, source, init, authority, pin, panel, subsets):
    train=Path(arm["train"])
    dev=Path(arm["development"])
    start=Path(arm["first_train_log"])
    metadata=read(train)
    completed=read(dev)
    launch=read(start)
    group,seed=arm["subset"],arm["seed"]
    expected_subset=subsets[group]["sha256"]
    if (metadata["dataset"],metadata["init"],metadata["seed"],metadata["updates"])!=(source,init,seed,420):
        raise ValueError("Training subset and assigned updates differ")
    if (metadata["pool_size"]!=subsets[group]["n"] or metadata["subset_sha256"]!=expected_subset or
            metadata["checkpoint_sha256"]!=completed["weight_sha256"] or
            completed["panel_sha256"]!=authority["environment_manifest_sha256"] or
            metadata["forecast_sha256"]!=pin or launch["forecast_sha256"]!=pin or
            datetime.fromisoformat(launch["started_utc"])<=datetime.fromisoformat(authority["timestamp_utc"])):
        raise ValueError(f"An output departed from the locked D3-B protocol: {source}/{init}/{group}/{seed}")
    metrics={}
    fingerprints={}
    for name,key in PRIMARY.items():
        pred=dev.parent/f"{name}.jsonl"
        entry=completed["predictions"][name]
        if digest(pred)!=entry["sha256"]:
            raise ValueError("Stored per-question outcome checksum has changed")
        records=list(items(pred))
        ids=[p["id"] for p in records]
        expected=panel[name]
        if ids!=expected or entry["rows"]!=len(expected):
            raise ValueError("Different locked question order in a D3-B arm")
        metrics[name]=np.array([record["metrics"][key] for record in records],dtype=np.float64)
        fingerprints[name]=entry["sha256"]
    return metrics,dict(source=source,group=group,init=init,seed=seed,train_sha256=digest(train),dev_sha256=digest(dev),
                        scores={name:float(results.mean()) for name,results in metrics.items()},predictions=fingerprints)


def effect(left,right,draws):
    task={}
    reports={}
    for name in PRIMARY:
        x=np.stack([a[name] for a in left])
        y=np.stack([a[name] for a in right])
        diff=x-y
        paired=diff.mean(0)
        idx=draws[name]
        bs=100*paired[idx].mean(axis=1)
        reports[name]=dict(n_questions=len(paired),pp=float(100*paired.mean()),
                          ci95_pp=np.quantile(bs,[.025,.975]).tolist(),
                          rescue_per_seed=(diff==1).sum(1).tolist(),
                          degrade_per_seed=(diff==-1).sum(1).tolist())
        task[name]=bs
    overall=np.mean(list(task.values()),axis=0)
    return dict(mean_pp=float(np.mean([value["pp"] for value in reports.values()])),
                ci95_pp=np.quantile(overall,[.025,.975]).tolist(),per_task=reports),overall


def read_subsets(work, source, pin, authority):
    entries={}
    expected=500 if source=="arc_challenge" else 512
    source_sha=authority["per_source"][source]["identity"][0]
    for name in B_GROUPS:
        path=work/"sample_subsets"/source/f"{name}.json"
        record=read(path)
        ids=set(record["sample_ids"])
        if (len(ids)!=expected or len(record["sample_ids"])!=expected or record["n"]!=expected
                or record["forecast_sha256"]!=pin or record["source_sha256"]!=source_sha
                or record["source"]!=source or record["method"]!=name):
            raise ValueError(f"An equal-size source intervention changed: {source}/{name}")
        entries[name]={"sha256":digest(path),"n":expected,"ids":ids,
                       "mean_signed_true":record["average_signed_true"],
                       "mean_signed_proxy":record["mean_signed_proxy"]}
    if entries["Top_Signed_True"]["ids"] & entries["Bottom_Signed_True"]["ids"]:
        raise ValueError("The declared top and bottom source groups are required to be disjoint")
    return entries


def audit(args):
    work=args.out
    work.mkdir(parents=True,exist_ok=True)
    forecast=read(args.forecast)
    pin=digest(args.forecast)
    if args.forecast.with_suffix(".sha256").read_text().split()[0]!=pin:
        raise ValueError("Unsigned forecast")
    env=read(args.env)
    if digest(args.env)!=forecast["environment_manifest_sha256"] or env["status"]!="PREFLIGHT_OK":
        raise ValueError("Missing preflight compliance")
    dev={}
    for task in PRIMARY:
        relative=f"UNIFIED_EXT_DEV/{task}.jsonl"
        path=args.env.parent/relative
        if digest(path)!=env["frozen_data"][relative]["sha256"]:
            raise ValueError("The main external panel changed")
        dev[task]=[row["sample_id"] for row in items(path)]
    rng=np.random.default_rng(261126451)
    draws={k:rng.integers(len(values),size=(10000,len(values)),dtype=np.int32) for k,values in dev.items()}
    group=read(args.arms)
    if set(group)!=set(B_SOURCES):
        raise ValueError("Five full signed source populations are required")
    by_source={}
    subset_diagnostics={}
    styles={}
    for source, conditions in group.items():
        expected=INITS if source in ("boolq","qasc") else INITS[:1]
        if set(conditions)!=set(expected):
            raise ValueError("Required D3-B cold/warm controls differ")
        by_source[source]={}
        candidates=read_subsets(work,source,pin,forecast)
        subset_diagnostics[source]={
            "locked_subsets":{key:{k:v for k,v in entry.items() if k!="ids"}
                              for key,entry in candidates.items()},
            "matched_cohort_intersections":{
                name:len(candidates[first]["ids"] & candidates[second]["ids"])
                for name,first,second in CONTRASTS
            },
        }
        for start, entries in conditions.items():
            chosen={}
            arm_results=[]
            for entry in entries:
                key=entry["subset"],entry["seed"]
                if key in chosen:
                    raise ValueError("Duplicated D3-B arm")
                chosen[key],meta=inspect(entry,source,start,forecast,pin,dev,candidates)
                arm_results.append(meta)
            if set(chosen)!={(program,seed) for program in B_GROUPS for seed in SEEDS}:
                raise ValueError("Missing pre-registered subset comparison")
            comparisons={}
            for label,a,b in CONTRASTS:
                left=[chosen[a,seed] for seed in SEEDS]
                right=[chosen[b,seed] for seed in SEEDS]
                comparisons[label],resamples=effect(left,right,draws)
                styles.setdefault((start,label),[]).append((comparisons[label]["mean_pp"],resamples))
            by_source[source][start]=dict(contrasts=comparisons,all_arms=arm_results)
    average={}
    for (init,key),group in styles.items():
        value,repl=zip(*group,strict=True)
        joint=np.mean(repl,axis=0)
        average.setdefault(init,{})[key]=dict(mean_pp=float(np.mean(value)),ci95_pp=np.quantile(joint,[.025,.975]).tolist(),
                                             sources=len(group))
    result=dict(forecast_sha256=pin,scope="Within-source selection on common independent dev questions",
                bootstrap="10,000 paired question bootstrap draws, seeds averaged before sampling, fixed source roster",
                n_arms=sum(len(obj["all_arms"]) for src in by_source.values() for obj in src.values()),
                sources=by_source,pooled_equal_sources=average,subset_diagnostics=subset_diagnostics)
    out=work/"D3B_REVERSAL_RESULTS.json"
    save_json(out,result)
    summary=["# D3-B 同源反转实验","",
             "本实验检验源内样本选择的符号相容性与梯度定义差异。源级前瞻理论由 D3-A 单独检验。","",
             "| 初始化 | 配对对照 | 差值（百分点） | 95% CI | 来源数 |",
             "| --- | --- | ---: | --- | ---: |"]
    for init,comparisons in average.items():
        for title,item in comparisons.items():
            lo,hi=item["ci95_pp"]
            summary.append(f"| {init} | {title} | {item['mean_pp']:+.3f} | [{lo:+.3f}, {hi:+.3f}] | {item['sources']} |")
    report=work/"D3B_REPORT.md"
    temporary=report.with_suffix(".partial")
    temporary.write_text("\n".join(summary)+"\n",encoding="utf-8")
    temporary.replace(report)
    print("D3B_REVERSAL_CLOSED",result["n_arms"],digest(out),flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    for key in ("arms","forecast","env","out"):
        p.add_argument(f"--{key}",required=True,type=Path)
    audit(p.parse_args())

