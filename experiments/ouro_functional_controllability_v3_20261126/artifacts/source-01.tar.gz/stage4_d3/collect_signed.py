"""Collect signed and unsigned source witnesses using frozen causal receiver adjoints."""

import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import time

import torch
import torch.nn.functional as F

import minimal
from collect_identification import native, pack
from d2_worker import digest, load, save_json, save_pt
from d3_scores import context_scores, mismatch_pairs, projected_change


MOMENTS = ("true_receiver", "proxy_receiver", "true_full", "ordinary", "loop_contrast")


def read_jsonl(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def source_stem(row):
    if "candidate" in row:
        return row["candidate"]["question"]
    return row["prompt"]


def mismatched(row, partner):
    alternate=dict(row)
    if "candidate" in row:
        alternate["candidate"]=dict(row["candidate"],question=partner["candidate"]["question"])
    else:
        alternate["prompt"]=partner["prompt"]
    return alternate


def utility(model, state, batch):
    _, index, position, targets=batch.packed
    chosen=model.lm_head(state[index,position]).float()
    lp=-F.cross_entropy(chosen,targets,reduction="none")
    if batch.metadata is None:
        totals=lp.new_zeros(len(batch.ids)).index_add_(0,index,lp)
        counts=lp.new_zeros(len(batch.ids)).index_add_(0,index,torch.ones_like(lp))
        true_probability=lp.new_zeros(len(batch.ids)).index_add_(0,index,lp.exp())
        return totals/counts, 1-true_probability/counts, None
    sums=lp.new_zeros(len(batch.packed[0])).index_add_(0,index,lp)
    size=[len(row["characters"]) for row in batch.metadata]
    chars=sums.new_tensor([value for row in batch.metadata for value in row["characters"]])
    options=(16*sums/chars).split(size)
    values, gaps, winner=[], [], []
    for group, scores in zip(batch.metadata,options,strict=True):
        label=group["gold"]
        rivals=torch.cat((scores[:label],scores[label+1:]))
        values.append(scores[label]-rivals.logsumexp(0)+rivals.new_tensor(len(rivals)).log())
        gaps.append(1-scores.softmax(0)[label])
        winner.append(int(scores.argmax()))
    return torch.stack(values),torch.stack(gaps),winner


def tape(archive, model, tok, rows, depth, mode, direct_gradient):
    batch=pack(archive,tok,rows,mode)
    with torch.enable_grad():
        direct,loop,h=native(model,batch,depth,differentiate=True)
        score,error,winner=utility(model,loop,batch)
        grad_direct=None
        if direct_gradient:
            direct_values,_,_=utility(model,direct,batch)
            grad_direct,=torch.autograd.grad(direct_values.sum(),h,retain_graph=True)
        grad_loop,=torch.autograd.grad(score.sum(),h)
    return batch,h.detach(),grad_loop.detach(),grad_direct.detach() if grad_direct is not None else None,score.detach(),error.detach(),winner


def question_positions(batch, number):
    _, seq, pos, targets=batch.packed
    keep=batch.example[seq]==number
    indices=keep.nonzero().flatten()
    rows=seq[indices]
    maximum=pos.new_full((len(batch.packed[0]),),-1).scatter_reduce_(0,rows,pos[indices],reduce="amax")
    active=torch.arange(batch.packed[0].shape[1],device=pos.device)[None]<=maximum[:,None]
    return rows,pos[indices],targets[indices],active


def align(by_option, swapped_option, tokens, swapped_tokens):
    matched, shifted, seen= [], [], 0
    for first,second in zip(by_option.unique(sorted=True),swapped_option.unique(sorted=True),strict=True):
        a=(by_option==first).nonzero().flatten()
        b=(swapped_option==second).nonzero().flatten()
        n=min(len(a),len(b))
        if n == 0:
            continue
        equality=tokens[a[-n:]].eq(swapped_tokens[b[-n:]])
        conflicts=(~equality).nonzero().flatten()
        tail=n if not len(conflicts) else n-int(conflicts[-1])-1
        if tail:
            matched.append(a[-tail:])
            shifted.append(b[-tail:])
            seen+=tail
    empty=by_option.new_zeros((0,))
    return (torch.cat(matched),torch.cat(shifted),seen) if seen else (empty,empty,0)


def measure(rows, swaps, archive, model, tok, mode, depth, write, read, sums):
    real,h,g,gd,score,gap,winner=tape(archive,model,tok,rows,depth,mode,True)
    replacement,hp,gp,_,scorep,_,_=tape(archive,model,tok,swaps,depth,mode,False)
    output=[]
    for i,item in enumerate(rows):
        rr,rp,rt,full=question_positions(real,i)
        pr,pp,pt,alt=question_positions(replacement,i)
        p,q,n=align(rr,pr,rt,pt)
        g0,h0=g[rr,rp],h[rr,rp]
        g1,h1=gp[pr,pp],hp[pr,pp]
        w=gap[i]
        flags=context_scores(g0,h0,g1,h1,p,q,write,read,w)
        flags["signed_full"]=w*(projected_change(g[full],h[full],write,read)
                                 -projected_change(gp[alt],hp[alt],write,read))
        sums["true_receiver"].addmm_(g0.mT,h0,alpha=float(w)).addmm_(g1.mT,h1,alpha=-float(w))
        sums["proxy_receiver"].addmm_((g0[p]-g1[q]).mT,h0[p],alpha=float(w))
        sums["true_full"].addmm_(g[full].mT,h[full],alpha=float(w)).addmm_(gp[alt].mT,hp[alt],alpha=-float(w))
        sums["ordinary"].addmm_(g0.mT,h0)
        sums["loop_contrast"].addmm_((g0-gd[rr,rp]).mT,h0)
        result=dict(id=item["sample_id"], mismatch_id=swaps[i]["_mismatch_source_id"],
                    original_utility=float(score[i]), mismatch_utility=float(scorep[i]), 
                    receiver_tokens=len(rr), mismatch_tokens=len(pr), aligned_tokens=n,
                    native_winner=winner[i] if winner is not None else None,
                    option_count=len(item["candidate"]["choices"]["text"]) if "candidate" in item else None)
        result.update({name:float(value) for name,value in flags.items()})
        output.append(result)
    return output


def run(args):
    marker=json.loads(args.reference.with_name("D2_SUBSPACE_LOCK.json").read_text())
    if marker["controller_sha256"]!=digest(args.reference):
        raise ValueError("The unlabelled direction must be frozen prior to source identification")
    if digest(args.source)!=args.source_sha256:
        raise ValueError("Training source does not match its audited population")
    args.out.mkdir(parents=True,exist_ok=True)
    protocol=dict(reference_sha256=digest(args.reference),source_sha256=args.source_sha256, 
                  dataset=args.dataset, mode=args.mode, depth=4, fold=args.fold, folds=args.folds, seed=args.seed,
                  limit=args.limit, batch=args.batch, runner_sha256=digest(Path(__file__)))
    lock=args.out/"COLLECT_LOCK.json"
    if lock.exists() and json.loads(lock.read_text())!=protocol:
        raise ValueError("Training-source analysis protocol changed")
    save_json(lock,protocol)

    full=read_jsonl(args.source)
    index={row["sample_id"]:row for row in full}
    if len(index)!=len(full):
        raise ValueError("The input pool must have unambiguous IDs")
    order=sorted(index,key=lambda key:sha256(f"{args.seed}:{key}".encode()).hexdigest())
    if not 0 <= args.fold < args.folds or args.batch < 1 or args.limit < 0:
        raise ValueError("Invalid source population shard or update budget")
    eligible=order[:args.limit] if args.limit else order
    used=eligible[args.fold::args.folds]
    chosen=[index[key] for key in used]
    if not chosen:
        raise ValueError("Empty declared source shard")
    swaps=mismatch_pairs([dict(id=key,stem=source_stem(index[key])) for key in index],args.seed)
    foil=[dict(mismatched(row,index[swaps[row["sample_id"]]]),_mismatch_source_id=swaps[row["sample_id"]]) for row in chosen]
    # Candidate population stays complete. Reduce microbatch size only when the longest views warrant it.
    budget=args.batch
    torch.set_num_threads(4)
    archive,model,tok,pin=minimal.runtime(args.archive,args.previous,args.model)
    if pin["model_sha256"] != args.model_sha256:
        raise ValueError("The frozen Base payload changed")
    anchor=load(args.reference)
    write=anchor["u_A0"].float().cuda()
    read=anchor["w_A0"].float().cuda()
    sums={name:torch.zeros((len(write),len(read)),device="cuda") for name in MOMENTS}
    checkpoint=args.out/"COLLECT_RESUME.pt"
    previous=[]
    start=0
    if checkpoint.exists():
        saved=load(checkpoint)
        if saved["config_sha256"]!=digest(lock):
            raise ValueError("Cached source gradients have a different sample lock")
        start=saved["processed"]
        previous=saved["records"]
        if [a["id"] for a in previous]!=used[:start]:
            raise ValueError("Cached data selection keys differ from the frozen source")
        sums={name:matrix.cuda() for name,matrix in saved["sums"].items()}
    begin=time.perf_counter()
    for first in range(start,len(chosen),budget):
        recs=measure(chosen[first:first+budget],foil[first:first+budget],archive,model,tok,args.mode,
                     4,write,read,sums)
        previous.extend(recs)
        if len(previous) % (32*budget)==0 or len(previous)==len(chosen):
            save_pt(checkpoint,dict(processed=len(previous),records=previous,
                     sums={name:tensor.cpu() for name,tensor in sums.items()},config_sha256=digest(lock)))
            print("SIGNED_SOURCE_PROGRESS",args.dataset,len(previous),len(chosen),flush=True)
    summary={"n":len(previous),"pool_population":len(full),"seconds_this_attempt":time.perf_counter()-begin,
             "resume_sha256":digest(checkpoint),"mostly_aligned":sum(r["aligned_tokens"]>=.9*r["receiver_tokens"] for r in previous)}
    for name in ("signed_true","signed_proxy","signed_full","unsigned_matrix","unsigned_gradient","error_gap"):
        summary[name]=sum(row[name] for row in previous)/len(previous)
    summary["native_winners"]=dict(Counter(str(row["native_winner"]) for row in previous))
    rows=args.out/"SCORES.jsonl"
    temp=rows.with_suffix(".partial")
    temp.write_text("".join(json.dumps(record,ensure_ascii=False)+"\n" for record in previous),encoding="utf-8")
    temp.replace(rows)
    save_json(args.out/"SOURCE_FEATURES.json",dict(summary,score_sha256=digest(rows),lock_sha256=digest(lock)))
    print("SIGNED_SOURCE_COMPLETE",args.dataset,len(previous),digest(rows),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("source","model","archive","previous","reference","out"):
        parser.add_argument(f"--{name}",type=Path,required=True)
    parser.add_argument("--source-sha256",required=True)
    parser.add_argument("--model-sha256",required=True)
    parser.add_argument("--dataset",required=True)
    parser.add_argument("--mode",choices=("candidate","generation"),required=True)
    parser.add_argument("--batch",type=int,default=4)
    parser.add_argument("--limit",type=int,default=0)
    parser.add_argument("--fold",type=int,default=0)
    parser.add_argument("--folds",type=int,default=1)
    parser.add_argument("--seed",type=int,default=26112641)
    run(parser.parse_args())


if __name__=="__main__":
    main()

