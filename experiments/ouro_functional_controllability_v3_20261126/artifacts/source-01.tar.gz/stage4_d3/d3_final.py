"""Summarize the source-level forecast separately from the paired causal reversal."""
import argparse
import json
from pathlib import Path

from d2_worker import digest, save_json


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_text(path,lines):
    temp=path.with_suffix(".partial")
    temp.write_text("\n".join(lines)+"\n",encoding="utf-8")
    temp.replace(path)


def run(work):
    frozen=work/"FORECAST_LOCK_V3.json"
    pin=digest(frozen)
    if frozen.with_suffix(".sha256").read_text().split()[0]!=pin:
        raise ValueError("Invalid preregistered forecast")
    before=read(frozen)
    outcomes=work/"D3A_FORECAST_AUDIT.json"
    result=read(outcomes)
    reversal=work/"D3B_REVERSAL_RESULTS.json"
    trial=read(reversal)
    if result["forecast_sha256"]!=pin or trial["forecast_sha256"]!=pin or trial["n_arms"]!=84:
        raise ValueError("Both independently verified D3 parts are required")
    fit=work/"D3A_SOURCE_VALUES.json"
    save_json(fit,dict(input_sha256=digest(outcomes),values=result["subject_values"]))
    cold="Cold_FixedWork"
    prospective=result["group_results"]["prospective"][cold]
    signed=prospective["P1_signed_true"]["spearman"]["estimate"]
    ordinary=prospective["B1_ordinary_functional"]["spearman"]["estimate"]
    step=result["group_results"]["all"][cold]["P1_signed_true"]["spearman"]["estimate"]
    signal=trial["pooled_equal_sources"][cold]
    criteria={
        "signed_direction_top_beats_bottom_on_dev":signal["top_minus_bottom"]["ci95_pp"][0]>0,
        "true_gradient_beats_proxy_on_dev":signal["true_minus_proxy"]["ci95_pp"][0]>0,
        "signed_beats_unsigned_on_dev":signal["signed_minus_unsigned"]["ci95_pp"][0]>0,
        "positive_prospective_ranking":signed is not None and signed>0,
        "exceeds_ordinary_on_prospective_ranking":signed is not None and ordinary is not None and signed>ordinary,
    }
    positive=[source for source in before["rankings"]["P1_signed_true"]
              if source in before["partition_groups"]["candidate"] and
              before["per_source"][source]["features"]["P1_signed_true"]>0.]
    top=positive[:3]
    outside=[source for source in positive if source!="arc_challenge"][:3]
    verdict=dict(forecast_sha256=pin,reversal_sha256=digest(reversal),prospective_sha256=digest(outcomes),
                 verified_criteria=criteria,effect_estimates=dict(within_source=signal,prospective_spearman=signed,
                 ordinary_prospective_spearman=ordinary,overall_cold_spearman=step),
                 d4_rule=dict(score="P1_signed_true",all_track=top,strictly_nonarc=outside,
                              positive_sources=positive,weighting="positive signed true, .75 per-source power",
                              evidence_qualified=criteria["signed_direction_top_beats_bottom_on_dev"] and
                                                criteria["exceeds_ordinary_on_prospective_ranking"]),
                 exploratory_due_to_four_prospective_sources=True,official_test_used=False)
    final=work/"D3_VERDICT.json"
    if final.exists() and read(final)!=verdict:
        raise ValueError("The design decision and upstream files cannot change")
    save_json(final,verdict)
    source_lines=["# D3-A 前瞻数据价值审计","",
                  "| 分组 | 初始化 | 预注册指标 | Spearman | Kendall | Top-3 | Top-1 后悔（pp） |",
                  "| --- | --- | --- | ---: | ---: | ---: | ---: |"]
    def scalar(x):
        return f"{x:+.3f}" if x is not None else "—"
    for group,items in result["group_results"].items():
        for condition,scores in items.items():
            for key,value in scores.items():
                source_lines.append(f"| {group} | {condition} | {key} | {scalar(value['spearman']['estimate'])} | "
                                    f"{scalar(value['kendall']['estimate'])} | {value['top3_matches']} | "
                                    f"{value['top1_regret_pp']:.3f} |")
    source_lines.extend(["",f"前瞻组只有四个来源。无标签锚点、打分公式及完整来源顺序先于任何源训练冻结。",
                         "同源样本反转的配对证据见 D3B_REPORT.md。D3-A 的相关性单位是来源。"])
    write_text(work/"D3A_REPORT.md",source_lines)
    print("D3_FINAL_VERDICT",digest(final),flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--work",type=Path,required=True)
    run(p.parse_args().work)

