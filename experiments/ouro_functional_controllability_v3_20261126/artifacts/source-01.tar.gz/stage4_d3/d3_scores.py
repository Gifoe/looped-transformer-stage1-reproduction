"""Signed operator contrasts for matched and mismatched receiving contexts."""

from hashlib import sha256

import torch


def mismatch_pairs(rows, seed):
    """Assign a fixed different stem to each row without changing its choices."""
    ordered = sorted(rows, key=lambda row: sha256(f"{seed}:{row['id']}".encode()).hexdigest())
    if len({row["stem"] for row in ordered}) < 2:
        raise ValueError("A source needs at least two distinct stems for a mismatch control")
    assignment = {}
    for index, original in enumerate(ordered):
        for offset in range(1, len(ordered)):
            swapped = ordered[(index + offset) % len(ordered)]
            if swapped["stem"] != original["stem"]:
                assignment[original["id"]] = swapped["id"]
                break
    return assignment


def ranking_error(scores, label):
    """Return the exact native probability error for the gold candidate."""
    if scores.ndim != 1 or len(scores) < 2 or label not in range(len(scores)):
        raise ValueError("Expected valid scores and one gold candidate per question")
    return 1 - torch.softmax(scores, dim=0)[label]


def projected_change(gradient, states, u, w):
    if gradient.shape != states.shape or gradient.ndim != 2:
        raise ValueError("A contribution needs matching receiving states and gradients")
    return (gradient @ u) @ (states @ w)


def matrix_frobenius(gradient, states):
    """Compute the Frobenius norm of G^T H using the smaller token-space Gram matrices."""
    gg = gradient @ gradient.mT
    hh = states @ states.mT
    return (gg * hh).sum().clamp_min(0).sqrt()


def context_scores(g, h, swapped_g, swapped_h, true_positions, swapped_positions, u, w, weight):
    if g.shape != h.shape or swapped_g.shape != swapped_h.shape:
        raise ValueError("Mismatch contexts must have their own full receiver-gradient tapes")
    if true_positions.shape != swapped_positions.shape:
        raise ValueError("Proxy tape requires aligned prediction positions")
    selected_g = g.index_select(0, true_positions)
    selected_h = h.index_select(0, true_positions)
    actual_swap = swapped_g.index_select(0, swapped_positions)
    differential = selected_g - actual_swap
    true = projected_change(g, h, u, w) - projected_change(swapped_g, swapped_h, u, w)
    proxy = projected_change(differential, selected_h, u, w)
    fully_signed_g = torch.cat((g, -swapped_g))
    fully_signed_h = torch.cat((h, swapped_h))
    return dict(
        signed_true=weight * true,
        signed_proxy=weight * proxy,
        unsigned_matrix=weight * matrix_frobenius(fully_signed_g, fully_signed_h),
        unsigned_gradient=weight * differential.norm(),
        error_gap=weight,
    )
