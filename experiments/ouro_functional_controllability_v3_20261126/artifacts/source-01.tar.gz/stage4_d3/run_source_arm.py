"""Resume a locked D3 source fit and score its final weight on the common panel."""
import argparse
from datetime import datetime, timezone
import gc
import json
from pathlib import Path
from types import SimpleNamespace

import torch

from d2_worker import digest, save_json
from score_shared_dev import run
from train_source import fit


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("forecast","reference","e0-config","source","out"):
        parser.add_argument(f"--{name}",required=True,type=Path)
    parser.add_argument("--dataset",required=True)
    parser.add_argument("--init",required=True,choices=("Cold_FixedWork","D2Warm_FixedWork"))
    parser.add_argument("--seed",required=True,type=int)
    parser.add_argument("--subset",type=Path)
    args=parser.parse_args()
    forecast=digest(args.forecast)
    doc=json.loads(args.forecast.read_text())
    if (args.forecast.with_suffix(".sha256").read_text().split()[0]!=forecast or
            datetime.fromisoformat(doc["timestamp_utc"])>=datetime.now(timezone.utc)):
        raise ValueError("The forecast must be frozen first")
    args.out.mkdir(parents=True,exist_ok=True)
    stamp=args.out/"train_source_started.json"
    if not stamp.exists():
        save_json(stamp,dict(forecast_sha256=forecast,started_utc=datetime.now(timezone.utc).isoformat(),
                            source=args.dataset,seed=args.seed,init=args.init))
    start=json.loads(stamp.read_text())
    if (start["forecast_sha256"]!=forecast or
            datetime.fromisoformat(start["started_utc"])<=datetime.fromisoformat(doc["timestamp_utc"])):
        raise ValueError("Source-training timestamp is inconsistent with forecast freeze")
    fit(args)
    gc.collect()
    torch.cuda.empty_cache()
    meta=json.loads((args.out/"TRAIN.json").read_text())
    run(SimpleNamespace(config=args.e0_config,weight=args.out/"controller.pt",out=args.out/"dev",
                         weight_sha256=meta["checkpoint_sha256"],arm=".".join(args.out.parts[-4:])))


if __name__=="__main__":
    main()

