"""Seal the complete source forecast before fitting any supervised source controller."""

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
from hashlib import file_digest
import itertools
import json
import math
from pathlib import Path
import statistics

import torch

from d2_worker import digest, load, save_json
from freeze_forecast import axis, projection, robust


SOURCES = ("arc_challenge","csqa","obqa","qasc","scienceqa","boolq","social_iqa","race",
           "squad","gsm8k","piqa","hellaswag","winogrande","medmcqa")
GENERATIVE = {"squad","gsm8k"}
PREDICTORS = ("P1_signed_true","P2_signed_proxy","P3_ufr_subspace_ratio","P4_unlabeled_fin_audit",
              "P5_frozen_composite","B0_source_only","B1_ordinary_functional","B2_loop_contrast",
              "B3_unsigned_ctv","B4_ce_gap_only")


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def normalized_entropy(records, source):
    if source in GENERATIVE:
        return 1.0
    counters=defaultdict(Counter)
    for row in records:
        choices=row["option_count"]
        winner=row["native_winner"]
        if choices < 2 or winner not in range(choices):
            raise ValueError("Candidate prior has invalid class index")
        counters[choices][winner]+=1
    total=len(records)
    entropy=0.
    for choices,counter in counters.items():
        n=sum(counter.values())
        entropy += n/total * -sum((count/n)*math.log(count/n) for count in counter.values())/math.log(choices)
    return entropy


def feature_standard_errors(records, full_size):
    names=("signed_true","signed_proxy","signed_full","unsigned_matrix","error_gap")
    n=len(records)
    if not 1<n<=full_size:
        raise ValueError("The observed feature sample must belong to the locked finite population")
    correction=math.sqrt(1-n/full_size)
    sampling={}
    for field in names:
        sample=[row[field] for row in records]
        center=statistics.mean(sample)
        standard=statistics.stdev(sample)/math.sqrt(n)
        finite=standard*correction
        sampling[field]={"observed_mean":center,
                         "standard_error_without_finite_population_correction":standard,
                         "finite_population_standard_error":finite,
                         "relative_finite_population_standard_error":finite/abs(center) if abs(center)>1e-12 else None}
    return sampling


def source_analysis(source, settings, reference_sha, audit_sha, seed):
    paths=[Path(path) for path in settings["shards"]]
    if len(paths)!=4:
        raise ValueError(f"Source {source} must have four predeclared feature folds")
    n=0
    marks={}
    records=[]
    means={}
    contrasts=[]
    source_identity=None
    for i,path in enumerate(paths):
        stamp=read(path.with_name("SOURCE_FEATURES.json"))
        spec=read(path.with_name("COLLECT_LOCK.json"))
        identity=(spec["source_sha256"],spec["limit"],spec["mode"],spec["seed"],spec["reference_sha256"])
        if source_identity is not None and identity!=source_identity:
            raise ValueError(f"Source definition differs across feature folds: {source}")
        source_identity=identity
        if spec["dataset"]!=source or spec["folds"]!=4 or spec["fold"]!=i or spec["reference_sha256"]!=reference_sha:
            raise ValueError(f"Source condition was not captured under the predeclared fold rules: {source}")
        if digest(path)!=stamp["resume_sha256"]:
            raise ValueError(f"Changed source-moment file at {path}")
        raw=load(path)
        count=raw["processed"]
        if count!=stamp["n"] or count!=len(raw["records"]):
            raise ValueError(f"Source and feature populations disagree at {path}")
        n+=count
        records.extend(raw["records"])
        marks[str(path)]=digest(path)
        contrast=raw["sums"]["loop_contrast"].float()
        contrasts.append(axis(contrast/max(count,1),seed)[0])
        for key in ("ordinary","loop_contrast"):
            means[key]=means.get(key,0)+raw["sums"][key].float()
    if n!=settings["n_used"] or len(set(row["id"] for row in records))!=n:
        raise ValueError(f"Incorrect source feature population at {source}")
    uncertainty=feature_standard_errors(records,settings["n"])
    audit=Path(settings["finite"])
    probe=read(audit)
    if probe["shard_sha256"]!=marks or probe["cohort"]!=n or probe["external_unlabeled_count"]!=512:
        raise ValueError(f"The unlabelled finite audit used a different source operator: {source}")
    if (probe["controller_sha256"],probe["audit_sha256"]) != (reference_sha,audit_sha):
        raise ValueError("The audit used a different corpus or reference")
    if not math.isclose(probe["p4"],probe["pmi"]-.3*probe["kl"],rel_tol=1e-7,abs_tol=1e-12):
        raise ValueError(f"The finite audit has an inconsistent P4 score: {source}")
    utility=torch.tensor([row["original_utility"] for row in records],dtype=torch.float64)
    iq=torch.quantile(utility,utility.new_tensor([.25,.75]))
    scale=max(.25,float((iq[1]-iq[0])/1.349))
    converted={key:value/n/scale for key,value in means.items()}
    leading,sigma=axis(converted["loop_contrast"],seed)
    ordinary,ordinary_sigma=axis(converted["ordinary"],seed)
    cosine=[float((u @ a)*(v @ b)) for (u,v),(a,b) in itertools.combinations(contrasts,2)]
    signed=dict(P1_signed_true=statistics.mean(x["signed_true"] for x in records),
                P2_signed_proxy=statistics.mean(x["signed_proxy"] for x in records),
                P3_ufr_subspace_ratio=probe["p3_ufr_subspace_ratio"],
                P4_unlabeled_fin_audit=probe["p4"],
                B0_source_only=statistics.mean(cosine)*float(sigma[0]),
                B3_unsigned_ctv=statistics.mean(x["unsigned_matrix"] for x in records),
                B4_ce_gap_only=statistics.mean(x["error_gap"] for x in records))
    return dict(features=signed,matrices=converted,direction=leading,ordinary_direction=ordinary,identity=identity,shards=marks,
                finite_audit_sha256=digest(audit),n=n,fold_stability=cosine,
                group="generation" if source in GENERATIVE else "candidate",
                prior_balance=normalized_entropy(records,source),kl=probe["kl"],utility_robust_scale=scale,
                gradient_stability=statistics.mean(cosine),loop_leading_singular=float(sigma[0]),
                ordinary_leading_singular=float(ordinary_sigma[0]),
                witness_se={key:entry["standard_error_without_finite_population_correction"]
                            for key,entry in uncertainty.items()},
                finite_population_feature_uncertainty=uncertainty,
                sampling_population={"total_rows":settings["n"],"feature_rows":n,
                                     "method":"hash sample without replacement across four folds" if n<settings["n"] else "complete audited source pool"})


def run(args):
    spec=read(args.inputs)
    locked=read(args.reference.with_name("D2_SUBSPACE_LOCK.json"))
    reference_sha=digest(args.reference)
    if reference_sha!=locked["controller_sha256"] or set(spec)!=set(SOURCES):
        raise ValueError("The zero-label reference and 14-source scope must be frozen before forecasting")
    env=read(args.env)
    if env["status"]!="PREFLIGHT_OK":
        raise ValueError("No authoritative unified development panel")
    audit=env["frozen_data"]["UNLABELED_CORPUS/audit_unlabeled.jsonl"]["sha256"]
    arms={name:source_analysis(name,spec[name],reference_sha,audit,args.seed) for name in SOURCES}
    scale=max(statistics.pstdev(item["features"]["P1_signed_true"] for item in arms.values()),1e-12)
    for src,item in arms.items():
        others=[r for r in SOURCES if r!=src]
        direction=item["direction"]
        score=item["features"]
        score["B1_ordinary_functional"]=robust([projection(arms[ref]["matrices"]["ordinary"],item["ordinary_direction"]) for ref in others])
        score["B2_loop_contrast"]=robust([projection(arms[ref]["matrices"]["loop_contrast"],direction) for ref in others])
        score["P5_frozen_composite"]=(score["P1_signed_true"]/scale)*item["prior_balance"]*math.exp(-item["kl"])
        if set(score)!=set(PREDICTORS) or not all(math.isfinite(value) for value in score.values()):
            raise ValueError(f"Predictor missing or non-finite for {src}")
    historical_file=Path("/root/ouro-functional-transferability-20261123/results/ROUND2_AUDIT/RESULTS.json")
    historical=read(historical_file)
    entry=historical["predictor_audit"]["signed_source_moment"]
    from scipy.stats import spearmanr
    points=historical["per_cell"]
    historical_source_rho=float(spearmanr([x["forecast"]["signed_source_moment"] for x in points],
                                          [x["log_odds"] for x in points]).statistic)
    if not math.isclose(historical_source_rho,entry["pooled_log_odds_rank"],abs_tol=1e-8):
        raise ValueError("The independently recomputed historical B0 statistic disagrees")
    loop_source=Path("/root/ouro-loop-aware-functional-identification-20261125/results/forecast_candidate/AUDIT.json")
    regime=[item for item in read(loop_source)["confirmation"] if item["depth"]==4 and item["dose"]==1.]
    if {item["scope"] for item in regime}!={"leave_source_out","leave_task_type_out"}:
        raise ValueError("Incomplete historical full-dose candidate benchmark")
    old_strength={}
    for panel in regime:
        score=panel["methods"]["source_only"]
        measured=statistics.mean(target["spearman"] for target in score["targets"])
        if not math.isclose(measured,score["aggregate"]["spearman_mean"],abs_tol=1e-10):
            raise ValueError("Source-only historical rank aggregation differs")
        old_strength[panel["scope"]]=measured
    historical_scores={"path":str(historical_file),"sha256":digest(historical_file),"n_cells":historical["cell_count"],
                       "continuous_utility_spearman":historical_source_rho,
                       "loop_aware_candidate_spearman":old_strength,"loop_aware_sha256":digest(loop_source),
                       "accuracy_spearman":entry["pooled_acc_norm_rank"],"used_in_fitting":False}
    result=dict(status="FROZEN_BEFORE_SOURCE_TRAINING",seed=args.seed,reference_sha256=reference_sha,
                e0_verdict_sha256=digest(args.e0),historical_b0_reference=historical_scores,
                b0_forecast_formula="first excess singular value times mean pairwise fold operator cosine, on v3 feature cohort",
                environment_manifest_sha256=digest(args.env),input_manifest_sha256=digest(args.inputs), 
                dev_roster={key:v for key,v in env["frozen_data"].items() if key.startswith("UNIFIED_EXT_DEV/")},
                composite={"formula":"P1 / within-study population standard deviation, times native entropy balance and exp(-KL)",
                           "signed":True,"generation_prior_balance":1.0,"uncentered_deviation":scale},
                partition_groups={"historical":list(SOURCES[:10]),"prospective":list(SOURCES[10:]),
                                  "candidate":[key for key in SOURCES if key not in GENERATIVE]},
                per_source={key:{field:value for field,value in data.items() if field not in ("matrices","direction","ordinary_direction")}
                            for key,data in arms.items()},
                rankings={metric:sorted(SOURCES,key=lambda key:(-arms[key]["features"][metric],key))
                          for metric in PREDICTORS})
    args.out.mkdir(parents=True,exist_ok=True)
    target=args.out/"FORECAST_LOCK_V3.json"
    digest_path=target.with_suffix(".sha256")
    result=json.loads(json.dumps(result))
    if target.exists():
        current=read(target)
        elapsed=current.pop("timestamp_utc")
        if current!=result or digest_path.read_text().split()[0]!=digest(target):
            raise ValueError("The sealed forecast cannot be changed")
        return
    if any(args.out.rglob("train_source_started.json")) or any(args.out.rglob("train_source_*.log")):
        raise ValueError("Source training cannot precede the pre-registered forecast")
    result["timestamp_utc"]=datetime.now(timezone.utc).isoformat()
    save_json(target,result)
    temporary=digest_path.with_suffix(".partial")
    temporary.write_text(f"{digest(target)}  {target.name}\n")
    temporary.replace(digest_path)
    print("FORECAST_V3_FROZEN",len(arms),digest(target),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("reference","env","e0","inputs","out"):
        parser.add_argument(f"--{name}",type=Path,required=True)
    parser.add_argument("--seed",type=int,default=26112643)
    run(parser.parse_args())


if __name__=="__main__":
    main()

