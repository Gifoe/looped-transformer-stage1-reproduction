"""Fit one source arm under the pre-registered Ouro v3 training and panel contract."""

import argparse
from pathlib import Path
import json
import time

import torch

import minimal
from e0_reuse import BASE_SHA, DEPTHS, RECIPE, score_rows, streams
from d2_worker import digest, load, save_json, save_pt


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def select(args, forecast):
    rows=minimal.load_jsonl(args.source)
    if args.subset is None:
        return rows
    frozen=read(args.subset)
    if frozen["source_sha256"]!=digest(args.source) or frozen["forecast_sha256"]!=digest(args.forecast):
        raise ValueError("D3-B sample IDs need a frozen source and forecast")
    ids=frozen["sample_ids"]
    index={row["sample_id"]:row for row in rows}
    if len(set(ids))!=len(ids) or not set(ids)<=index.keys():
        raise ValueError("The fixed-size source intervention must contain only known, distinct questions")
    return [index[key] for key in ids]


def fit(args):
    torch.set_num_threads(4)
    forecast=read(args.forecast)
    sha=args.forecast.with_suffix(".sha256").read_text().split()[0]
    if sha!=digest(args.forecast) or forecast["status"]!="FROZEN_BEFORE_SOURCE_TRAINING":
        raise ValueError("The final D3 forecast must be read-only before source fitting")
    if forecast["reference_sha256"]!=digest(args.reference):
        raise ValueError("Mismatched zero-label initialization or witness")
    if args.dataset not in forecast["per_source"]:
        raise ValueError("Unknown source outside the 14 pre-registered groups")
    if digest(args.source)!=forecast["per_source"][args.dataset]["identity"][0]:
        raise ValueError("The full source pool changed after freezing its prediction")
    config=read(args.e0_config)
    if config["approved_env_sha256"]!=forecast["environment_manifest_sha256"]:
        raise ValueError("The training arms no longer use the same evaluation panel")
    mode=forecast["per_source"][args.dataset]["group"]
    objective="rank" if mode=="candidate" else "nll_rank"
    expected=420 if args.subset is not None else 840
    args.out.mkdir(parents=True,exist_ok=True)
    lock=args.out/"SOURCE_FIT_LOCK.json"
    specification=dict(dataset=args.dataset,init=args.init,seed=args.seed,updates=expected,mode=mode,
                      objective="ranking" if mode=="candidate" else "token_average_nll",recipe=RECIPE,
                      forecast_sha256=sha,source_sha256=digest(args.source),reference_sha256=digest(args.reference),
                      subset_sha256=digest(args.subset) if args.subset else None,runner_sha256=digest(Path(__file__)))
    if lock.exists() and read(lock)!=specification:
        raise ValueError("This source arm has a different resumable training contract")
    save_json(lock,specification)
    final=args.out/"TRAIN.json"
    weights=args.out/"controller.pt"
    if final.exists():
        if digest(weights)!=read(final)["checkpoint_sha256"]:
            raise ValueError("A closed source controller changed")
        return
    archive,model,tokenizer,pin=minimal.runtime(Path(config["archive"]),Path(config["previous"]),Path(config["model"]))
    if pin["model_sha256"]!=BASE_SHA or any(p.requires_grad for p in model.parameters()):
        raise ValueError("Source fitting must preserve every frozen model parameter")
    torch.manual_seed(args.seed)
    net=minimal.Minimal("linear",1,.45)
    if args.init=="D2Warm_FixedWork":
        net.load_state_dict(load(args.reference)["state"])
    net.to(model.device).requires_grad_(True)
    opt=torch.optim.AdamW(net.parameters(),lr=RECIPE["learning_rate"],weight_decay=RECIPE["weight_decay"])
    data=select(args,forecast)
    batch_size=RECIPE["effective_batch"]
    iterator=streams(data,args.seed,"D3_SOURCE_FIXED_WORK")
    trace=[]
    begin=time.perf_counter()
    padding=completed=0
    visited=set()
    checkpoint=args.out/"SOURCE_RESUME.pt"
    if checkpoint.exists():
        snapshot=load(checkpoint)
        if snapshot["lock_sha256"]!=digest(lock):
            raise ValueError("Source checkpoint does not match training lock")
        net.load_state_dict(snapshot["network"])
        opt.load_state_dict(snapshot["optimizer"])
        completed=snapshot["completed"]
        padding=snapshot["padded_token_loops"]
        trace=snapshot["trace"]
        for _ in range(completed*batch_size): visited.add(next(iterator)["sample_id"])
    microbatch=1 if args.dataset in ("race","squad") else batch_size
    for step in range(completed,expected):
        minibatch=[next(iterator) for _ in range(batch_size)]
        visited.update(row["sample_id"] for row in minibatch)
        depth=DEPTHS[step%len(DEPTHS)]
        opt.zero_grad(set_to_none=True)
        loss_value=0.
        with torch.enable_grad():
            for start in range(0,batch_size,microbatch):
                inputs=minibatch[start:start+microbatch]
                loss,_,_,work=score_rows(archive,model,tokenizer,net,inputs,depth,objective)
                scaled=loss*len(inputs)/batch_size
                scaled.backward()
                loss_value+=float(scaled.detach())
                padding+=work
        gradient=torch.nn.utils.clip_grad_norm_(net.parameters(),RECIPE["clip"])
        if not gradient.isfinite().item():
            raise ValueError("Non-finite gradient in declared source fit")
        opt.step()
        if (step+1)%70==0 or step+1==expected:
            trace.append(dict(step=step+1,loss=loss_value,unique_rows=len(visited),padded_token_loops=padding))
            save_pt(checkpoint,dict(network=net.state_dict(),optimizer=opt.state_dict(),completed=step+1,
                     padded_token_loops=padding,trace=trace,lock_sha256=digest(lock)))
            print("D3_SOURCE_TRAIN",args.dataset,args.init,args.seed,step+1,expected,len(visited),flush=True)
    save_pt(weights,dict(form="rank1",state={key:data.detach().cpu() for key,data in net.state_dict().items()},
                         meta=dict(forecast_sha256=sha,training_lock_sha256=digest(lock))))
    save_json(final,dict(**specification,checkpoint_sha256=digest(weights),pool_size=len(data),unique_training_rows=len(visited),
                        microbatch=microbatch,padded_token_loops=padding,trace=trace,seconds_this_attempt=time.perf_counter()-begin))
    print("D3_SOURCE_FITTED",args.dataset,args.init,args.seed,len(visited),digest(weights),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("forecast","reference","e0-config","source","out"):
        parser.add_argument(f"--{name}",required=True,type=Path)
    parser.add_argument("--dataset",required=True)
    parser.add_argument("--init",required=True,choices=("Cold_FixedWork","D2Warm_FixedWork"))
    parser.add_argument("--seed",type=int,required=True)
    parser.add_argument("--subset",type=Path)
    fit(parser.parse_args())


if __name__=="__main__":
    main()

