"""Verify all routed D3 feature receipts against the original scientific roster."""
import argparse
from hashlib import file_digest, sha256
import json
from pathlib import Path


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    with path.open("rb") as source:
        return file_digest(source, "sha256").hexdigest()


def config_hash(job):
    return sha256(json.dumps(job, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def verify(work):
    base=work/"D3_FEATURES_DISPATCH.json"
    routed=work/"D3_FEATURES_EXECUTION.json"
    input_plan=work/"FORECAST_INPUTS.json"
    amendment=work/"D3_FEATURE_ROUTING_AMENDMENT.json"
    extension=work/"D3_FEATURES_DUAL_EXTENSION.json"
    stamp, initial, actual, inputs = map(load, (amendment, base, routed, input_plan))
    pins = {"original_dispatch_sha256":base,"amended_dispatch_sha256":routed,
            "inputs_sha256":input_plan,"dual_extension_sha256":extension}
    if any(stamp[name] != digest(path) for name, path in pins.items()):
        raise ValueError("A frozen D3 routing input changed")
    if {k:v for k,v in initial.items() if k!="jobs"} != {k:v for k,v in actual.items() if k!="jobs"}:
        raise ValueError("The feature-routing amendment changed the original device setup")
    checked={}
    n_total=0
    amendment_map=stamp["ownership_changes"]
    changed=[]
    for old, current in zip(initial["jobs"], actual["jobs"], strict=True):
        name=old["job_id"]
        slot=amendment_map.get(name, old["preferred_gpu"])
        if (name in amendment_map and (old["preferred_gpu"]!="0" or slot not in {"1","2"})
                or current!=dict(old, preferred_gpu=slot)):
            raise ValueError(f"The feature input or protocol changed for {name}")
        if name in amendment_map:
            changed.append(current)
        marker=Path(current["done_marker"])
        result=load(marker)
        if (result["job_id"]!=name or result["logical_gpu"]!=slot or result["config_sha256"]!=config_hash(current)
                or set(result["artifact_sha256"])!=set(current["artifacts"])):
            raise ValueError(f"A feature receipt does not match the active routing at {name}")
        for file, expected in result["artifact_sha256"].items():
            if digest(Path(file)) != expected:
                raise ValueError(f"An acquired D3 feature artifact changed at {file}")
        resource=next(Path(path) for path in current["artifacts"] if path.endswith("/SOURCE_FEATURES.json"))
        info=load(resource)
        _,_,source,fold=name.split(".")
        if info["n"]!=len(range(int(fold),inputs[source]["n_used"],4)):
            raise ValueError(f"Feature fold population differs from the original at {name}")
        n_total+=info["n"]
        checked[name]={"receipt_sha256":digest(marker),"observations":info["n"],"logical_gpu":slot}
    if (len(checked)!=56 or len(amendment_map)!=13 or len(inputs)!=14
            or load(extension)["jobs"]!=changed
            or n_total!=sum(row["n_used"] for row in inputs.values())):
        raise ValueError("Final D3 feature roster or routed observations are incomplete")
    output=work/"D3_FEATURES_VERIFIED.json"
    manifest={"n_folds":len(checked),"n_observations":n_total,"routing_amendment_sha256":digest(amendment),
              "execution_sha256":digest(routed),"receipts":checked,"official_test_used":False}
    if output.exists() and load(output)!=manifest:
        raise ValueError("The closed feature acquisition receipt changed")
    temp=output.with_suffix(".partial")
    temp.write_text(json.dumps(manifest,indent=2,sort_keys=True,ensure_ascii=False)+"\n",encoding="utf-8")
    temp.replace(output)
    print("D3_ACQUISITION_REVERIFIED",len(checked),n_total,digest(output),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work",type=Path,required=True)
    verify(parser.parse_args().work.resolve())
