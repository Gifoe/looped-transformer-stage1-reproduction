"""Compute paired D1 protocol results from complete frozen scored requests."""

import argparse
from collections import defaultdict
from hashlib import file_digest
import json
from pathlib import Path

import numpy as np

from d1_stats import decompose, paired, rotation_correctness


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def rows(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def load_predictions(path, request_ids):
    receipt = read(path.with_suffix(".json"))
    if digest(path) != receipt["rows_sha256"]:
        raise ValueError(f"Predictions and receipt disagree at {path}")
    items = rows(path)
    if [row["id"] for row in items] != request_ids:
        raise ValueError("Prediction protocol or request population differs")
    return {row["id"]: row for row in items}


def tensors(requests, prediction):
    by_protocol = defaultdict(dict)
    by_question = defaultdict(set)
    for request in requests:
        source = prediction[request["id"]]
        if source["choices"] != request["choices"] or source["gold"] != request["target"]:
            raise ValueError("The scorer changed stable candidate identities")
        scores = np.asarray(source["scores"], dtype=np.float64)
        rtype = request["protocol"]
        if rtype.endswith("_full"):
            scores = scores / np.asarray(source["chars"], dtype=np.float64)
        key = request["source_id"]
        domain = request["benchmark"]
        symbols = request["symbols"]
        gold = (request["target"] - request["shift"]) % 4
        item = by_protocol[domain, rtype, symbols].setdefault(key, dict(gold=gold, shifts={}))
        if gold != item["gold"] or request["shift"] in item["shifts"]:
            raise ValueError("Rotation changed option content or gold identity")
        item["shifts"][request["shift"]] = scores
        if symbols == "1234":
            by_question[domain].add(key)

    cohort = {}
    for key, items in by_protocol.items():
        keys = list(items)
        scores = []
        gold = []
        for name in keys:
            record = items[name]
            if key[1] == "hidden_full":
                if set(record["shifts"]) != {0}:
                    raise ValueError("The hidden prompts should share their canonical request")
                vectors = [np.roll(record["shifts"][0], shift) for shift in range(4)]
            else:
                if set(record["shifts"]) != set(range(4)):
                    raise ValueError("Expected four complete rotations")
                vectors = [record["shifts"][shift] for shift in range(4)]
            scores.append(vectors)
            gold.append(record["gold"])
        cohort[key] = (keys, np.asarray(scores), np.asarray(gold))
    return cohort, by_question


def compare(current, baseline):
    group, right, gold = current
    old_ids, left, historical = baseline
    if old_ids != group or not np.array_equal(gold, historical):
        raise ValueError("The two arms do not share a paired question population")
    split = decompose(left, right)
    old = rotation_correctness(left, gold)
    new = rotation_correctness(right, gold)
    content = split["content_effect"]
    correct = content[np.arange(len(gold)), gold]
    error = (content.sum(1) - correct) / 3
    return {
        "question_count": len(group),
        "correctness": {method: paired(old[method], new[method]) for method in old},
        "total_variance": split["total_variance"],
        "components": split["component"],
        "fractions": split["fraction"],
        "global_slot_effect": split["global_slot_effect"].tolist(),
        "content_response_correct_mean": float(correct.mean()),
        "content_response_wrong_mean": float(error.mean()),
    }


def protocol_contrast(current, native, first, second):
    """Compare two controller effects on strictly matched underlying questions."""
    a_ids, a_native, a_gold = native[first]
    b_ids, b_native, b_gold = native[second]
    a_after, b_after = current[first], current[second]
    if a_after[0] != a_ids or b_after[0] != b_ids:
        raise ValueError("The treatment changed the source item roster")
    if not np.array_equal(a_after[2], a_gold) or not np.array_equal(b_after[2], b_gold):
        raise ValueError("The treatment changed the content label")
    b_lookup = {key: i for i, key in enumerate(b_ids)}
    left = np.asarray([i for i, key in enumerate(a_ids) if key in b_lookup])
    right = np.asarray([b_lookup[a_ids[i]] for i in left])
    if not len(left) or not np.array_equal(a_gold[left], b_gold[right]):
        raise ValueError("The scoring protocols need a common semantic gold target")
    values = (
        rotation_correctness(a_native[left], a_gold[left]),
        rotation_correctness(a_after[1][left], a_gold[left]),
        rotation_correctness(b_native[right], b_gold[right]),
        rotation_correctness(b_after[1][right], b_gold[right]),
    )
    rng = np.random.default_rng(26112639)
    outcomes = {}
    for view in values[0]:
        a0, a1, b0, b1 = [row[view].astype(np.int8) for row in values]
        a = a1 - a0
        b = b1 - b0
        delta = a - b
        levels, counts = np.unique(delta, return_counts=True)
        draws = rng.multinomial(len(delta), counts/len(delta), size=10000) @ levels / len(delta)
        outcomes[view] = {
            "n": len(delta), "first_delta_pp": 100*float(a.mean()), "second_delta_pp": 100*float(b.mean()),
            "difference_of_effects_pp": 100*float(delta.mean()),
            "paired_question_bootstrap_ci95_pp": (100*np.quantile(draws,[.025,.975])).tolist()
        }
    return {"first": "/".join(first), "second": "/".join(second), "views": outcomes}


def gather(args):
    protocol = read(args.protocol)
    request_path = args.protocol.parent/"REQUESTS.jsonl"
    if protocol["REQUESTS.jsonl"] != digest(request_path):
        raise ValueError("D1 input protocol changed")
    requests = rows(request_path)
    if args.only_mmlu:
        requests = [row for row in requests if row["benchmark"] == "mmlu"]
    request_ids = [row["id"] for row in requests]
    native, numeric = tensors(requests, load_predictions(args.native, request_ids))
    examined, _ = tensors(requests, load_predictions(args.controller, request_ids))
    results = {}
    for key, current in examined.items():
        results["/".join(key)] = compare(current, native[key])
    matched = {}
    for domain, selected in numeric.items():
        for readout in ("shown_full", "shown_letter"):
            for suffix in ("ABCD", "1234"):
                key = (domain, readout, suffix)
                keys, data, gold = examined[key]
                _, baseline, _ = native[key]
                mask = np.asarray([item in selected for item in keys])
                shared = [item for item in keys if item in selected]
                matched["/".join(key)] = compare((shared, data[mask], gold[mask]),
                                                  (shared, baseline[mask], gold[mask]))
    contrasts = {}
    for domain in sorted({key[0] for key in examined}):
        displayed = (domain, "shown_full", "ABCD")
        contrasts[domain] = {
            "full_content_minus_letter_when_shown": protocol_contrast(
                examined, native, displayed, (domain, "shown_letter", "ABCD")),
            "shown_minus_hidden_with_full_content": protocol_contrast(
                examined, native, displayed, (domain, "hidden_full", "ABCD")),
            "digit_minus_letter_symbols_with_letter_scoring": protocol_contrast(
                examined, native, (domain, "shown_letter", "1234"), (domain, "shown_letter", "ABCD")),
        }
    record = dict(model=args.model, controller=args.arm, request_sha256=digest(request_path),
                  same_question_protocol_contrasts=contrasts,
                  native_predictions_sha256=digest(args.native),
                  controller_predictions_sha256=digest(args.controller),
                  protocols=results, matched_symbol_subset=matched)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    stage=args.out.with_suffix(".partial")
    stage.write_text(json.dumps(record, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
    stage.replace(args.out)
    print("D1A_VARIANCE_AUDITED", args.model, args.arm, len(results), digest(args.out))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("native", "controller", "protocol", "out"):
        parser.add_argument(f"--{key}", required=True, type=Path)
    parser.add_argument("--model", required=True)
    parser.add_argument("--arm", required=True)
    parser.add_argument("--only-mmlu", action="store_true")
    gather(parser.parse_args())


if __name__ == "__main__":
    main()

