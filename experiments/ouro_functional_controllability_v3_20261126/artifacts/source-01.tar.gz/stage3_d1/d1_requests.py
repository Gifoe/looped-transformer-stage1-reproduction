"""Build paired no-test prompts for the Ouro v3 protocol factorial."""

import argparse
from collections import Counter, defaultdict, deque
from hashlib import file_digest, sha256
import json
from pathlib import Path
from unicodedata import normalize


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def rows(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def order_key(seed, key):
    return sha256(f"{seed}:{key}".encode()).hexdigest()


def distinct(options):
    return len({" ".join(normalize("NFKC",text).split()) for text in options})==len(options)


def select_mmlu(source, seed, count):
    from e0_external_dev import options_and_gold
    strata = defaultdict(list)
    excluded=[]
    for row in source:
        _, options, _ = options_and_gold(row)
        if len(options)==4 and distinct(options):
            strata[row["subject"]].append(row)
        else:
            excluded.append(row["sample_id"])
    queues = {subject: deque(sorted(group, key=lambda r: order_key(seed, r["sample_id"])))
              for subject, group in sorted(strata.items())}
    if sum(map(len, queues.values())) < count:
        raise ValueError("The locked MMLU development set cannot support the requested count")
    chosen = []
    while len(chosen) < count:
        for queue in queues.values():
            if queue:
                chosen.append(queue.popleft())
                if len(chosen) == count:
                    break
    return chosen,excluded


def questions(name, source):
    from e0_external_dev import options_and_gold

    records = []
    sizes = Counter()
    ambiguous=[]
    for row in source:
        primary = row.get("candidate") or row
        key = row.get("sample_id", primary.get("id", row.get("id")))
        if key is None:
            raise ValueError("Question has no stable record ID")
        view = dict(primary, sample_id=str(key))
        question, options, correct = options_and_gold(view)
        sizes[len(options)] += 1
        if len(options) == 4 and not distinct(options):
            ambiguous.append(str(key))
        if len(options) == 4 and distinct(options):
            records.append(dict(id=str(key), source=name, question=question, options=options, gold=correct))
    if len(records) != len({r["id"] for r in records}):
        raise ValueError(f"Duplicate D1 questions after population selection: {name}")
    return records, sizes, ambiguous


def rendered(item, protocol, shift, symbols):
    stem = item["question"]
    content = [(pos - shift) % 4 for pos in range(4)]
    choices = [item["options"][index] for index in content]
    gold = (item["gold"] + shift) % 4
    context = f"{stem}\nAnswer:"
    if protocol.startswith("shown"):
        view = "\n".join(f"{symbol}. {text}" for symbol, text in zip(symbols, choices, strict=True))
        context = f"{stem}\n{view}\nAnswer:"
    targets = list(symbols) if protocol == "shown_letter" else choices
    key = f"{item['source']}|{item['id']}|{protocol}|{''.join(symbols)}|{shift}"
    return dict(id=key, task=item["source"], benchmark=item["source"], doc_id=0, target=gold,
                choices=targets, underlying_choices=choices, source_id=item["id"],
                protocol=protocol, shift=shift, symbols="".join(symbols), content_by_slot=content,
                requests=[dict(type="loglikelihood", args=[context, " " + value], idx=index)
                          for index, value in enumerate(targets)])


def build(args):
    shared = json.loads(args.env.read_text(encoding="utf-8"))
    if shared["status"] != "PREFLIGHT_OK":
        raise ValueError("D1 inputs must use the approved Stage 0 panel")
    mmlu = args.env.parent / "UNIFIED_EXT_DEV" / "mmlu_val.jsonl"
    if digest(mmlu) != shared["frozen_data"]["UNIFIED_EXT_DEV/mmlu_val.jsonl"]["sha256"]:
        raise ValueError("MMLU development rows changed after Stage 0")
    if digest(args.arc) != args.arc_validation_sha256:
        raise ValueError("ARC requests did not come from the frozen official validation artifact")
    arc_rows = rows(args.arc)
    if len(arc_rows) != 299:
        raise ValueError("Expected the complete 299-row ARC validation split")
    arc, sizes, arc_ambiguous = questions("arc_challenge", arc_rows)
    mmlu_rows, mmlu_excluded = select_mmlu(rows(mmlu), args.seed, 400)
    mmlu_questions, mmlu_sizes, ambiguous = questions("mmlu", mmlu_rows)
    if ambiguous:
        raise ValueError("Ambiguous MMLU candidate text cannot enter the same-item factorial")
    if len(mmlu_questions) != 400:
        raise ValueError("MMLU factorial requires four exact options")
    rng = lambda item: order_key(args.seed+1, item["id"])
    alternate = {(item["source"], item["id"]) for domain in (arc, mmlu_questions) for item in sorted(domain,key=rng)[:50]}
    all_items = arc + mmlu_questions
    experiments = []
    for item in all_items:
        experiments.append(rendered(item, "hidden_full", 0, "ABCD"))
        for protocol in ("shown_full", "shown_letter"):
            for shift in range(4):
                experiments.append(rendered(item, protocol, shift, "ABCD"))
        if (item["source"], item["id"]) in alternate:
            for protocol in ("shown_full", "shown_letter"):
                for shift in range(4):
                    experiments.append(rendered(item, protocol, shift, "1234"))
    for index, row in enumerate(experiments):
        row["doc_id"] = index
    args.out.mkdir(parents=True, exist_ok=True)
    pins = dict(seed=args.seed, arc_validation_sha256=digest(args.arc), mmlu_sha256=digest(mmlu),
                env_sha256=digest(args.env), arc_choice_counts=dict(sizes), mmlu_choice_counts=dict(mmlu_sizes),
                n_arc=len(arc), n_mmlu=len(mmlu_questions), numeric_symbol_questions=len(alternate),
                arc_duplicate_option_exclusions=arc_ambiguous, mmlu_eligible_filter_exclusions=mmlu_excluded,
                exact_option_audit="distinct after Unicode NFKC and whitespace normalization, case preserved",
                hidden_reuse="Only the unrotated Cloze requests are forwarded. Every other slot order reuses the same four text scores.",
                primary_protocols=["hidden_full", "shown_full", "shown_letter"], requests=len(experiments))
    payloads = {"QUESTIONS.jsonl": all_items, "REQUESTS.jsonl": experiments}
    for name, population in payloads.items():
        path = args.out / name
        payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in population)
        if path.exists() and path.read_text(encoding="utf-8") != payload:
            raise ValueError(f"Existing D1 data cannot change: {path}")
        if not path.exists():
            stage = path.with_suffix(".partial")
            stage.write_text(payload, encoding="utf-8")
            stage.replace(path)
        pins[name] = digest(path)
    lock = args.out / "D1_REQUESTS_LOCK.json"
    content = json.dumps(pins, indent=2, ensure_ascii=False, sort_keys=True) + "\n"
    if lock.exists() and lock.read_text(encoding="utf-8") != content:
        raise ValueError("D1 requests changed after protocol freeze")
    if not lock.exists():
        stage = lock.with_suffix(".partial")
        stage.write_text(content, encoding="utf-8")
        stage.replace(lock)
    print("D1_REQUESTS_READY", len(all_items), len(experiments), digest(lock))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env", required=True, type=Path)
    parser.add_argument("--arc", required=True, type=Path)
    parser.add_argument("--arc-validation-sha256", required=True)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--seed", type=int, default=26112630)
    build(parser.parse_args())


if __name__ == "__main__":
    main()

