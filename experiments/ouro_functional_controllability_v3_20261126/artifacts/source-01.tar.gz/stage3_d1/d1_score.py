"""Score a frozen D1 request population using established Ouro or Huginn forward paths."""

import argparse
from collections import Counter
import json
from pathlib import Path
import sys
import time

import torch

import minimal
from controller_io import controller
from evaluate_benchmarks import candidate_row
from evaluate_core import finish, verified
from evaluate_transfer import load_runtime, timestamp_cost


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def models(args):
    if args.name == "huginn-0125":
        import huginn_control as huginn
        import transformers
        if transformers.__version__ != "4.49.0":
            raise ValueError("Huginn requires the archived isolated environment")
        model, tok = huginn.load_model(args.model)
        net = None
        if args.arm != "native":
            huginn.CAP = args.cap
            net = huginn.RankOne().to(model.device)
            net.load_state_dict(torch.load(args.checkpoint, weights_only=True, map_location="cpu")["state"])
            net.requires_grad_(False).eval()
        return model, tok, net, dict(depth=32, gpu=torch.cuda.get_device_name(), dtype=str(model.dtype))
    if args.name == "ouro-1.4b-base":
        _, model, tok, info = minimal.runtime(args.archive, args.previous, args.model)
        if info["model_sha256"] != args.model_sha256:
            raise ValueError("The Base evaluation checkpoint differs")
        runtime = dict(depth=4, gpu=torch.cuda.get_device_name(), dtype=str(model.dtype))
    else:
        model, tok, _, runtime = load_runtime(args)
        runtime["depth"] = 4
    net = controller(args.checkpoint, model.device) if args.arm != "native" else None
    if net is not None:
        net.bound = args.cap
        net.requires_grad_(False).eval()
    return model, tok, net, runtime


def run(args):
    if not 0.0 <= args.cap <= .45:
        raise ValueError("Unsupported relative RMS limit")
    if args.arm != "native":
        if args.checkpoint is None or minimal.sha(args.checkpoint) != args.checkpoint_sha256:
            raise ValueError("The controller SHA differs from the declared diagnostic checkpoint")
    if args.name != "ouro-1.4b-base" and args.name != "huginn-0125":
        if minimal.sha(args.model/"MODEL_LOCK.json") != args.model_sha256:
            raise ValueError("The official model receipt differs from Stage 0")
    if args.name == "huginn-0125" and minimal.sha(args.model/"MODEL_LOCK.json") != args.model_sha256:
        raise ValueError("Huginn model receipt differs from Stage 0")
    protocol = read(args.protocol)
    requests = args.protocol.parent / "REQUESTS.jsonl"
    if minimal.sha(requests) != protocol["REQUESTS.jsonl"]:
        raise ValueError("The paired prompts changed after locking")
    with requests.open(encoding="utf-8") as source:
        population = [json.loads(line) for line in source]
    if args.only_mmlu:
        population = [row for row in population if row["benchmark"] == "mmlu"]
    if args.only_letter_and_cloze:
        population = [row for row in population if row["symbols"] == "ABCD" and row["protocol"] in ("hidden_full", "shown_letter")]
    sys.path.insert(0, str(args.stage2 / "code"))
    import stage2_score as stage
    import seven_unified as scoring

    old = read(args.stage2/"scores"/"arc_challenge"/"LOCK.json")
    fields = ("max_length", "max_batch", "token_cap", "attention_cap", "head_rows", "shard_size")
    config = {key: old[key] for key in fields}
    if args.name == "huginn-0125":
        config["token_cap"] = min(config["token_cap"], 3072)
    lock = dict(protocol_sha256=minimal.sha(args.protocol), checkpoint_sha256=args.checkpoint_sha256,
                model_name=args.name, model_sha256=args.model_sha256, cap=args.cap, arm=args.arm,
                scope=("letter_and_cloze" if args.only_letter_and_cloze else "mmlu" if args.only_mmlu else "all"),
                scorer_sha256=minimal.sha(Path(stage.__file__)), config=config, seed=261126301)
    args.out.mkdir(parents=True, exist_ok=True)
    shards = args.out / "shards"
    shards.mkdir(exist_ok=True)
    path = args.out / "PREDICTIONS.jsonl"
    ids = [row["id"] for row in population]
    if verified(path, lock, ids):
        return
    m, tok, net, runtime = models(args)
    if args.name == "huginn-0125":
        from evaluate_huginn import candidate_shard
    encoder = stage.HarnessEncoder(tok, config["max_length"])
    stage.APPLE_BENCHMARKS = dict.fromkeys(stage.APPLE_BENCHMARKS, 0)
    output, total = [], Counter()
    n = config["shard_size"]
    with torch.no_grad():
        for start in range(0, len(population), n):
            examples = population[start:start+n]
            batch_ids = [row["id"] for row in examples]
            dest = shards / f"{start:05d}.jsonl"
            plan = dict(lock, start=start, end=start+len(examples))
            prefix = verified(dest, plan, batch_ids)
            if prefix:
                measured, cost = prefix
            else:
                if args.name == "huginn-0125":
                    torch.cuda.synchronize()
                    torch.cuda.reset_peak_memory_stats()
                    before = time.perf_counter()
                    measured, cost = candidate_shard(stage, m, tok, examples, config, net, lock["seed"]+start)
                    torch.cuda.synchronize()
                    cost.update(elapsed_seconds=time.perf_counter()-before, peak_allocated_bytes=torch.cuda.max_memory_allocated(),
                                peak_reserved_bytes=torch.cuda.max_memory_reserved())
                else:
                    found, cost = scoring.shard_score(stage, minimal, m, encoder, net, examples, config, m.device)
                    measured = [candidate_row(row, scoring.UNIFIED) for row in found]
                for pred, row in zip(measured, examples, strict=True):
                    if (pred["id"], pred["choices"], pred["gold"]) != (row["id"], row["choices"], row["target"]):
                        raise ValueError("The diagnostic scorer did not preserve the paired candidates")
                finish(dest, measured, plan, cost, runtime)
            output.extend(measured)
            timestamp_cost(total, cost)
    finish(path, output, lock, total, runtime)
    print("D1_SCORED", args.name, args.arm, args.cap, len(output), minimal.sha(path), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("models", "model", "t1", "archive", "previous", "stage2", "protocol", "out"):
        parser.add_argument(f"--{name}", required=True, type=Path)
    parser.add_argument("--name", required=True)
    parser.add_argument("--model-sha256", required=True)
    parser.add_argument("--arm", choices=("native", "t1", "mixed"), required=True)
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--checkpoint-sha256")
    parser.add_argument("--cap", type=float, default=.45)
    parser.add_argument("--only-letter-and-cloze", action="store_true")
    parser.add_argument("--only-mmlu", action="store_true")
    run(parser.parse_args())


if __name__ == "__main__":
    main()

