"""Freeze D1 cohort identities from approved development data."""

import argparse
from collections import Counter, defaultdict
from pathlib import Path

from e0_external_dev import options_and_gold
from e0_reuse import load_json, save_json
from stage0_data import digest, items, order_key, write_rows


def canonical(row):
    question, options, gold = options_and_gold(row)
    return {"sample_id": row["sample_id"], "question": question, "options": options,
            "gold_index": gold, "subject": row.get("subject")}


def stratify(rows, count, seed):
    groups = defaultdict(list)
    for row in sorted(rows, key=lambda row: order_key(seed, row["sample_id"])):
        groups[row["subject"]].append(row)
    selected = []
    while any(groups.values()):
        for name in sorted(groups):
            if groups[name]:
                selected.append(groups[name].pop(0))
            if len(selected) == count:
                return selected
    raise ValueError(f"Only {len(selected)} eligible stratified D1 inputs")


def prepare(root):
    e0 = root / "stage1_e0"
    config = load_json(e0 / "E0_CONFIG.json")
    stage = root / "stage0_env"
    env_path = stage / "ENV_MANIFEST.json"
    env = load_json(env_path)
    env_sha = digest(env_path)
    if env["status"] != "PREFLIGHT_OK" or env_sha != config["approved_env_sha256"]:
        raise ValueError("D1 cohorts require the approved Stage 0 manifest and E0 input configuration")
    arc_path = Path(config["legacy_dev"]["panel"]) / "dev_arc_challenge.jsonl"
    arc_rows = list(items(arc_path))
    arc_protocol = load_json(Path(config["legacy_dev"]["protocol"]))["cohorts"]["arc_challenge/candidate"]
    if len(arc_rows) != 299 or set(arc_protocol["ids"]) != {row["sample_id"] for row in arc_rows}:
        raise ValueError("ARC-Challenge validation differs from the frozen historical 299")
    arc_all = [canonical(row) for row in arc_rows]
    arc_four = [row for row in arc_all if len(row["options"]) == 4]
    omitted = {row["sample_id"]: len(row["options"]) for row in arc_all if len(row["options"]) != 4}
    if Counter(omitted.values()) != {3: 3, 5: 1} or len(arc_four) != 295:
        raise ValueError("Unexpected ARC-Challenge choice counts")
    main = {}
    source_hashes = {"arc_challenge": digest(arc_path)}
    for name in ("mmlu_val", "sciq_val", "arc_easy_val", "cosmosqa_val"):
        path = stage / "UNIFIED_EXT_DEV" / f"{name}.jsonl"
        record = env["frozen_data"][path.relative_to(stage).as_posix()]
        source_hashes[name] = digest(path)
        if source_hashes[name] != record["sha256"]:
            raise ValueError(f"Frozen development input {name} changed")
        main[name] = [canonical(row) for row in items(path)]
        if len(main[name]) != record["rows"]:
            raise ValueError(f"Frozen development population {name} changed")
    mmlu_pool = main.pop("mmlu_val")
    mmlu_eligible = [row for row in mmlu_pool if len(row["options"]) == len(set(row["options"])) == 4]
    mmlu_omitted = sorted({row["sample_id"] for row in mmlu_pool} - {row["sample_id"] for row in mmlu_eligible})
    mmlu = stratify(mmlu_eligible, 400, 26112601)
    panels = {"A_arc_challenge": arc_four, "A_mmlu": mmlu,
              "B_arc_challenge": arc_all, **{f"B_{name}": rows for name, rows in main.items()}}
    symbol = sorted([dict(row, dataset=name) for name, rows in panels.items() if name.startswith("A_") for row in rows],
                    key=lambda row: order_key(26112602, f"{row['dataset']}/{row['sample_id']}"))[:100]
    panels["A_symbol_probe"] = symbol
    folder = root / "stage3_d1/cohorts"
    manifest = {"env_sha256": env_sha, "input_sha256": source_hashes, "arc_d1a_excluded": omitted,
                "arc_d1a_counts_excluded_by_number_of_options": dict(Counter(omitted.values())),
                "mmlu_d1a_excluded_without_four_distinct_options": mmlu_omitted,
                "protocols": ["Cloze-FullText", "Shown-FullText", "Shown-Letter"],
                "shifts": [0, 1, 2, 3], "seeds": {"mmlu": 26112601, "symbol_probe": 26112602}, "outputs": {}}
    lock = folder / "D1_COHORTS.json"
    if lock.exists():
        raise FileExistsError(f"D1 cohorts are already frozen at {lock}")
    for name, rows in panels.items():
        manifest["outputs"][name] = write_rows(folder / f"{name}.jsonl", rows)
    save_json(lock, manifest)
    print("D1_COHORTS_READY", {name: len(rows) for name, rows in panels.items()}, digest(lock), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    prepare(parser.parse_args().root.resolve())
