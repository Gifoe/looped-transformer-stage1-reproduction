"""Create matched D1-A prompts and content-to-slot maps from frozen development cohorts."""

import argparse
from pathlib import Path

from e0_reuse import load_json, save_json
from stage0_data import digest, items, write_rows


PROTOCOLS = {"Cloze-FullText": (False, False), "Shown-FullText": (True, False), "Shown-Letter": (True, True)}
SYMBOLS = {"letters": "ABCD", "numbers": "1234"}


def request(sample, dataset, protocol, shift, symbol_set):
    display, label_target = PROTOCOLS[protocol]
    names = SYMBOLS[symbol_set]
    choices = sample["options"]
    if len(choices) != 4 or len(set(choices)) != 4:
        raise ValueError(f"Protocol factorial requires four distinct options: {sample['sample_id']}")
    indexes = [(slot - shift) % 4 for slot in range(4)]
    slot_options = [choices[index] for index in indexes]
    gold_slot = indexes.index(sample["gold_index"])
    question = sample["question"].rstrip()
    if display:
        lines = "\n".join(f"{label}. {option}" for label, option in zip(names, slot_options, strict=True))
        question += "\n" + lines
    prompt = question + "\nAnswer:"
    continuation = list(names) if label_target else slot_options
    return {"sample_id": sample["sample_id"], "dataset": dataset, "protocol": protocol,
            "shift": shift, "symbols": symbol_set, "prompt": prompt,
            "requests": [{"type": "loglikelihood", "args": [prompt, " " + text], "idx": index}
                         for index, text in enumerate(continuation)],
            "content_options": choices, "slot_options": slot_options,
            "slot_to_content": indexes, "gold_content": sample["gold_index"], "gold_slot": gold_slot}


def prepare(root):
    stage = root / "stage3_d1"
    cohort_path = stage / "cohorts/D1_COHORTS.json"
    cohorts = load_json(cohort_path)
    for name in ("A_arc_challenge", "A_mmlu", "A_symbol_probe"):
        path = cohort_path.parent / f"{name}.jsonl"
        frozen = cohorts["outputs"][name]
        if digest(path) != frozen["sha256"]:
            raise ValueError(f"Frozen D1 cohort changed: {name}")
        samples = list(items(path))
        if len(samples) != frozen["rows"]:
            raise ValueError(f"Frozen D1 population changed: {name}")
        cohort = []
        is_probe = name == "A_symbol_probe"
        for sample in samples:
            protocols = ("Shown-FullText", "Shown-Letter") if is_probe else PROTOCOLS
            for protocol in protocols:
                for shift in range(4):
                    cohort.append(request(sample, sample["dataset"] if is_probe else name, protocol, shift,
                                          "numbers" if is_probe else "letters"))
        expected = len(samples) * (8 if is_probe else 12)
        if expected != len({(row["dataset"], row["sample_id"], row["protocol"], row["shift"]) for row in cohort}):
            raise ValueError(f"D1 protocol cells were duplicated: {name}")
        yield name, cohort


def publish(root):
    stage = root / "stage3_d1"
    saved = {}
    for name, cohort in prepare(root):
        path = stage / "requests" / f"{name}.jsonl"
        partial = path.with_suffix(".partial")
        saved[name] = write_rows(partial, cohort)
        if path.exists() and digest(path) != saved[name]["sha256"]:
            raise ValueError(f"Earlier D1 factorial requests differ: {path}")
        partial.replace(path)
    lock = stage / "requests/D1A_PROTOCOL_INPUTS.json"
    context = {"cohorts_sha256": digest(stage / "cohorts/D1_COHORTS.json"), "files": saved,
               "protocols": list(PROTOCOLS), "shifts": [0, 1, 2, 3], "symbols": SYMBOLS}
    if lock.exists() and load_json(lock) != context:
        raise ValueError("Earlier D1 factorial request lock differs")
    if not lock.exists():
        save_json(lock, context)
    print("D1A_REQUESTS_READY", {key: info["rows"] for key, info in saved.items()}, digest(lock), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    publish(parser.parse_args().root.resolve())
