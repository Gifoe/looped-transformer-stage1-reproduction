"""Build and analyze matched Cloze, visible-choice and null-context controls."""

import argparse
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import logsumexp

from d1_factorial import load_predictions
from d1_requests import digest, rows
from d1_stats import paired
from e0_external_dev import options_and_gold


TASKS=("arc_challenge","sciq_val","arc_easy_val","cosmosqa_val")


def atomic(path, content):
    tmp=path.with_suffix(path.suffix+".partial")
    tmp.write_text(content,encoding="utf-8")
    tmp.replace(path)


def requests(args):
    approved=json.loads(args.env.read_text())
    if approved["status"]!="PREFLIGHT_OK" or digest(args.arc)!=args.arc_sha256:
        raise ValueError("D1-B needs the read-only ARC validation and approved external panel")
    all_rows={}
    for task in TASKS:
        source=args.arc if task=="arc_challenge" else args.env.parent/"UNIFIED_EXT_DEV"/f"{task}.jsonl"
        if task!="arc_challenge" and digest(source)!=approved["frozen_data"][f"UNIFIED_EXT_DEV/{task}.jsonl"]["sha256"]:
            raise ValueError("The development population changed")
        all_rows[task]=rows(source)
    if len(all_rows["arc_challenge"])!=299:
        raise ValueError("Use the complete ARC development split for D1-B")
    population=[]
    for task,data in all_rows.items():
        for item in data:
            primary=item.get("candidate") or item
            key=item.get("sample_id",primary.get("id"))
            if key is None:
                raise ValueError("Benchmark example lacks stable ID")
            stem,answers,label=options_and_gold(dict(primary,sample_id=str(key)))
            list_view="\n".join(f"{chr(65+i)}. {answer}" for i,answer in enumerate(answers))
            forms={"cloze":f"{stem}\nAnswer:","elicited":f"{stem}\n{list_view}\nAnswer:","null":"Answer:"}
            for mode,prompt in forms.items():
                population.append(dict(id=f"{task}|{key}|{mode}",source_id=str(key),benchmark=task,task=task,
                     doc_id=len(population),protocol=mode,symbols="",target=label,choices=answers,
                     requests=[dict(type="loglikelihood",args=[prompt," "+choice],idx=i) for i,choice in enumerate(answers)]))
    if len({value["id"] for value in population})!=len(population):
        raise ValueError("Duplicate D1-B requests")
    args.out.mkdir(parents=True,exist_ok=True)
    out=args.out/"REQUESTS.jsonl"
    blob="".join(json.dumps(row,ensure_ascii=False)+"\n" for row in population)
    if out.exists() and out.read_text(encoding="utf-8")!=blob:
        raise ValueError("Cannot change the frozen Cloze mechanism requests")
    if not out.exists():
        atomic(out,blob)
    report=dict(env_sha256=digest(args.env),abc_validation_sha256=args.arc_sha256,
                cohorts={task:len(vals) for task,vals in all_rows.items()},null_context="Answer:",
                choice_metric="character-normalized candidate log likelihood",
                temperature="candidate-level global scalar, five held-out folds",
                validation_fold_seed=26112633, **{"REQUESTS.jsonl":digest(out)})
    path=args.out/"D1B_REQUESTS_LOCK.json"
    stamp=json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+"\n"
    if path.exists() and path.read_text(encoding="utf-8")!=stamp:
        raise ValueError("The Cloze experimental lock differs")
    if not path.exists():
        atomic(path,stamp)
    print("D1B_MATCHED_REQUESTS",len(population),digest(path),flush=True)


def fit_temperature(items, folds):
    result=np.empty(len(items),dtype=float)
    chosen={}
    for current in range(5):
        fit=[row for row,group in zip(items,folds,strict=True) if group!=current]
        def objective(beta):
            return np.mean([logsumexp(beta*row["native"]["cloze"])-beta*row["native"]["cloze"][row["target"]]
                            for row in fit])
        chosen[current]=float(minimize_scalar(objective,bounds=(.1,10),method="bounded").x)
        result[folds==current]=chosen[current]
    return result,chosen


def contrast(items, values, baseline):
    old=np.asarray([np.argmax(x)==row["target"] for x,row in zip(baseline,items,strict=True)])
    new=np.asarray([np.argmax(x)==row["target"] for x,row in zip(values,items,strict=True)])
    differences=[]
    for x,row in zip(values,items,strict=True):
        marker=row["target"]
        rivals=np.delete(x,marker)
        differences.append(x[marker]-rivals.max())
    centered=np.concatenate([item-item.mean() for item in baseline])
    z=np.concatenate([item-item.mean() for item in values])
    slope=float((centered@z)/max(centered@centered,1e-20))
    residual=z-centered*slope
    score=1-float((residual@residual)/max(z@z,1e-20))
    nll=float(np.mean([logsumexp(v)-v[row["target"]] for v,row in zip(values,items,strict=True)]))
    return dict(paired=paired(old,new),candidate_margin=float(np.mean(differences)),
                regression_slope=slope, regression_r2=score,candidate_nll=nll)


def paired_control_overlap(items, alternatives):
    gold=np.asarray([row["target"] for row in items])
    correctness={key:np.asarray([np.argmax(x) for x in scores])==gold
                 for key,scores in alternatives.items()}
    native=correctness["Native_Cloze"]
    treatment=correctness["Rank1_T1"]
    t1_rescues=~native & treatment
    result={}
    for tag,other in correctness.items():
        if tag in ("Native_Cloze","Rank1_T1"):
            continue
        competitor_rescues=~native & other
        result[tag]={
            "rank1_t1_vs_competitor":paired(other,treatment),
            "both_rescue_native_wrong":int((t1_rescues & competitor_rescues).sum()),
            "only_rank1_rescues_native_wrong":int((t1_rescues & ~competitor_rescues).sum()),
            "only_competitor_rescues_native_wrong":int((~t1_rescues & competitor_rescues).sum()),
            "neither_rescues_native_wrong":int((~native & ~treatment & ~other).sum())
        }
    return result


def report(args):
    lock=json.loads(args.protocol.read_text())
    req=args.protocol.parent/"REQUESTS.jsonl"
    if lock["REQUESTS.jsonl"]!=digest(req):
        raise ValueError("Frozen Cloze controls lost their request identity")
    data=rows(req)
    ids=[item["id"] for item in data]
    predictions={name:load_predictions(path,ids) for name,path in (("native",args.native),("t1",args.t1))}
    groups={}
    for row in data:
        key=(row["benchmark"],row["source_id"])
        point=groups.setdefault(key,dict(target=row["target"],native={},t1={}))
        if row["target"]!=point["target"]:
            raise ValueError("The null and elicited controls changed answer identity")
        for method,table in predictions.items():
            p=table[row["id"]]
            score=np.asarray(p["scores"])/np.asarray(p["chars"])
            if p["gold"]!=row["target"] or p["choices"]!=row["choices"]:
                raise ValueError("Frozen option contents diverged across the six arms")
            point[method][row["protocol"]]=score
    ordered=list(groups)
    cohorts=list(groups.values())
    fold=np.asarray([int(sha256(f"{lock['validation_fold_seed']}:{key}".encode()).hexdigest(),16)%5 for key in ordered])
    betas,settings=fit_temperature(cohorts,fold)
    payload={}
    overlaps={}
    for task in TASKS:
        indexes=[i for i,key in enumerate(ordered) if key[0]==task]
        items=[cohorts[i] for i in indexes]
        old=[row["native"]["cloze"] for row in items]
        alternatives={
            "Native_Cloze":old,
            "Native_Elicited":[row["native"]["elicited"] for row in items],
            "Native_Candidate_Temperature":[r["native"]["cloze"]*betas[i] for i,r in zip(indexes,items,strict=True)],
            "Native_PMI_DC":[row["native"]["cloze"]-row["native"]["null"] for row in items],
            "Rank1_T1":[row["t1"]["cloze"] for row in items],
            "Rank1_T1_PMI_DC":[row["t1"]["cloze"]-row["t1"]["null"] for row in items]}
        payload[task]={key:contrast(items,current,old) for key,current in alternatives.items()}
        overlaps[task]=paired_control_overlap(items,alternatives)
    info=dict(protocol_sha256=digest(args.protocol),native_sha256=digest(args.native),t1_sha256=digest(args.t1),
              heldout_temperature=settings,cohorts=payload,overlap_against_rank1_t1=overlaps)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    atomic(args.out,json.dumps(info,ensure_ascii=False,indent=2)+"\n")
    print("D1B_MECHANISM_RESULTS",len(payload),digest(args.out),flush=True)


if __name__=="__main__":
    root=argparse.ArgumentParser(description=__doc__)
    modes=root.add_subparsers(dest="mode",required=True)
    build=modes.add_parser("requests")
    for key in ("env","arc","out"):
        build.add_argument(f"--{key}",type=Path,required=True)
    build.add_argument("--arc-sha256",required=True)
    analyze=modes.add_parser("report")
    for key in ("protocol","native","t1","out"):
        analyze.add_argument(f"--{key}",type=Path,required=True)
    args=root.parse_args()
    (requests if args.mode=="requests" else report)(args)

