"""Quantify causal feedback dose on matched prompts, including calibration and slot drift."""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.special import logsumexp

from d1_factorial import digest, load_predictions, rows, tensors
from d1_stats import decompose, paired, rotation_correctness, softmax


DOSES=(0.,.05,.10,.15,.25,.35,.45)


def calibration(values, gold):
    scores=values[:,0,:]
    probability=softmax(scores)
    confidence=probability.max(-1)
    correct=scores.argmax(-1)==gold
    nll=float(np.mean(logsumexp(scores,axis=-1)-scores[np.arange(len(gold)),gold]))
    ece=0.
    for members in np.array_split(np.argsort(confidence,kind="stable"),15):
        if len(members):
            ece += len(members)/len(gold)*abs(float(confidence[members].mean()-correct[members].mean()))
    return dict(nll=nll,ece_equal_count_15=ece,accuracy=float(correct.mean()),
                mean_confidence=float(confidence.mean())),correct,confidence


def describe(current, reference, gold):
    native,old,confidence=calibration(reference,gold)
    metrics,new,_=calibration(current,gold)
    high=confidence>.7
    metrics["paired"]=paired(old,new)
    metrics["native"]=native
    metrics["paired_confidence"]={label:paired(old[mask],new[mask]) if mask.any() else {"n":0}
                                  for label,mask in (("high",high),("other",~high))}
    left=(reference-reference.mean(-1,keepdims=True)).ravel()
    right=(current-current.mean(-1,keepdims=True)).ravel()
    scale=float(left@right)/max(float(left@left),1e-20)
    error=right-scale*left
    metrics.update(native_slope=scale,native_r_squared=1-float(error@error)/max(float(right@right),1e-20),
                   centered_shift_std=float(np.std(right-left)))
    pieces=decompose(reference,current)
    total_slot=pieces["fraction"]["slot"]
    global_slot=pieces["fraction"]["global_slot"]
    metrics["total_slot_fraction"]=total_slot
    metrics["global_slot_fraction"]=global_slot
    metrics["question_specific_slot_fraction"]=total_slot-global_slot
    aligned={}
    for method,baseline in rotation_correctness(reference,gold).items():
        aligned[method]=paired(baseline,rotation_correctness(current,gold)[method])
    metrics["aligned"]=aligned
    return metrics


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("protocol","native","full-dose","dose-directory","out"):
        parser.add_argument(f"--{name}",required=True,type=Path)
    parser.add_argument("--model",required=True)
    parser.add_argument("--endpoints-are-compact",action="store_true")
    args=parser.parse_args()
    protocol=json.loads(args.protocol.read_text())
    request_file=args.protocol.with_name("REQUESTS.jsonl")
    if digest(request_file)!=protocol["REQUESTS.jsonl"]:
        raise ValueError("The D1-C protocol changed")
    request=rows(request_file)
    subset=[item for item in request if item["symbols"]=="ABCD" and
            item["protocol"] in {"hidden_full","shown_letter"}]
    full_ids=[item["id"] for item in request]
    wanted=[item["id"] for item in subset]
    source=load_predictions(args.native,wanted if args.endpoints_are_compact else full_ids)
    baseline,_=tensors(subset,source)
    result={}
    for dose in DOSES:
        if dose==0.:
            path=args.native
            current=baseline
        else:
            path=(args.full_dose if dose==.45 else
                  args.dose_directory/f"{dose:.2f}"/"PREDICTIONS.jsonl")
            prior=load_predictions(path,full_ids if dose==.45 and not args.endpoints_are_compact else wanted)
            current,_=tensors(subset,prior)
        comparison={}
        for key,(ids,vectors,gold) in current.items():
            other,base,ref_labels=baseline[key]
            if ids!=other or not np.array_equal(gold,ref_labels):
                raise ValueError("The dose changed the question identities")
            comparison["/".join(key)]=dict(n=len(ids),**describe(vectors,base,gold))
        result[f"{dose:.2f}"]=dict(predictions_sha256=digest(path),cohorts=comparison)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    temporary=args.out.with_suffix(".partial")
    temporary.write_text(json.dumps(dict(model=args.model,dose_type="relative RMS cap",
                  ece="15 equal-count bins",protocol_sha256=digest(args.protocol),results=result),indent=2)+"\n")
    temporary.replace(args.out)
    print("D1C_DOSE_RESPONSE_COMPLETE",args.model,flush=True)


if __name__=="__main__":
    main()

