"""Question-clustered statistics for cyclic option rotation experiments."""

import numpy as np
from scipy.special import logsumexp
from scipy.stats import binomtest


def aligned_by_content(scores):
    """Map the cyclic displayed slot back to its stable answer content."""
    data = np.asarray(scores, dtype=np.float64)
    if data.ndim != 3 or data.shape[1:] != (4, 4):
        raise ValueError("Expected [question, shift, displayed slot] with four complete rotations")
    if not np.isfinite(data).all():
        raise ValueError("Option scores must be finite")
    return np.stack([np.roll(data[:, shift], -shift, axis=1) for shift in range(4)], axis=1)


def decompose(native, modified):
    native = np.asarray(native, dtype=np.float64)
    modified = np.asarray(modified, dtype=np.float64)
    if native.shape != modified.shape:
        raise ValueError("The comparison must use matching questions, rotations, and slots")
    change = modified - native
    aligned = aligned_by_content(change)
    base = change.mean(axis=(1, 2), keepdims=True)
    content_effect = aligned.mean(axis=1) - base[:, 0]
    slot_effect = change.mean(axis=1) - base[:, 0]
    by_slot = np.stack([np.roll(content_effect, shift, axis=1) for shift in range(4)], axis=1)
    recentered = change - base
    residual = recentered - by_slot - slot_effect[:, None, :]
    var_all = np.mean(recentered ** 2, axis=(1, 2))
    var_content = np.mean(content_effect ** 2, axis=1)
    var_slot = np.mean(slot_effect ** 2, axis=1)
    var_residual = np.mean(residual ** 2, axis=(1, 2))
    if not np.allclose(var_all, var_content + var_slot + var_residual, rtol=1e-10, atol=1e-12):
        raise ArithmeticError("The components are not orthogonal on the declared rotations")
    total = float(var_all.mean())
    global_slot = slot_effect.mean(axis=0)
    component = dict(content=float(var_content.mean()), slot=float(var_slot.mean()),
                     residual=float(var_residual.mean()), global_slot=float((global_slot ** 2).mean()))
    return dict(total_variance=total, component=component, fraction={
        key: value / total if total > 0 else 0.0 for key, value in component.items()
    }, content_effect=content_effect, slot_effect=slot_effect, global_slot_effect=global_slot)


def softmax(scores):
    return np.exp(scores - logsumexp(scores, axis=-1, keepdims=True))


def rotation_correctness(scores, gold):
    aligned = aligned_by_content(scores)
    target = np.asarray(gold, dtype=int)
    if target.shape != (aligned.shape[0],) or not np.isin(target, np.arange(4)).all():
        raise ValueError("Gold content identities do not match the aligned items")
    probability = softmax(aligned)
    votes = (probability.argmax(axis=-1)[..., None] == np.arange(4)).sum(axis=1)
    aggregate = probability.mean(axis=1)
    tied = votes == votes.max(axis=1, keepdims=True)
    vote_choice = np.where(tied, aggregate, -np.inf).argmax(axis=1)
    return dict(unrotated=aligned[:, 0].argmax(axis=1) == target,
                averaged=aggregate.argmax(axis=1) == target, majority=vote_choice == target)


def paired(before, after, replicates=10000, seed=26112630):
    x = np.asarray(before, dtype=bool)
    y = np.asarray(after, dtype=bool)
    if x.ndim != 1 or y.shape != x.shape or not len(x):
        raise ValueError("Expected two matching one-dimensional per-question correctness arrays")
    differences = y.astype(np.int8) - x.astype(np.int8)
    rescue, damage = int((differences == 1).sum()), int((differences == -1).sum())
    rng = np.random.default_rng(seed)
    # A three-category multinomial is the exact bootstrap distribution for paired binary differences.
    p = [(differences == value).mean() for value in (-1, 0, 1)]
    sampled = rng.multinomial(len(x), p, size=replicates)
    contrast = (sampled[:, 2] - sampled[:, 0]) / len(x)
    return dict(n=len(x), before=int(x.sum()), after=int(y.sum()), rescue=rescue, damage=damage,
                difference=float(differences.mean()), ci95=np.quantile(contrast, [0.025, 0.975]).tolist(),
                mcnemar_p=float(binomtest(rescue, rescue+damage).pvalue) if rescue+damage else 1.0)
