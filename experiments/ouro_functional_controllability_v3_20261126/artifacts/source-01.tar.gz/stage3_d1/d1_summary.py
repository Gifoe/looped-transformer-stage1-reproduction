"""Close the development-only D1 diagnostics and explicit soft-regularizer gate."""
import argparse
import json
from pathlib import Path
from types import SimpleNamespace

from d1_cloze import report as cloze
from d1_factorial import digest, gather as factorial


def atomic(path,data):
    temp=path.with_suffix(".partial")
    temp.write_text(json.dumps(data,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    temp.replace(path)


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def core(work):
    plan=read(work/"D1_DISPATCH.prefrozen.json")
    for job in plan["jobs"]:
        receipt=read(Path(job["done_marker"]))
        if receipt["job_id"]!=job["job_id"] or set(receipt["artifact_sha256"])!=set(job["artifacts"]):
            raise ValueError("A required protocol arm is incomplete")
        for name,sha in receipt["artifact_sha256"].items():
            if digest(Path(name))!=sha:
                raise ValueError(f"Changed predictions on D1: {name}")
    reports=work/"analysis"
    reports.mkdir(parents=True,exist_ok=True)
    a_protocol=work/"protocol"/"D1_REQUESTS_LOCK.json"
    b_protocol=work/"protocol_cloze"/"D1B_REQUESTS_LOCK.json"
    result_a={}
    result_b={}
    result_c={}
    for model in ("ouro-1.4b-base","ouro-1.4b-thinking","ouro-2.6b","huginn-0125","ouro-2.6b-thinking"):
        result_a[model]={}
        for arm in (("t1","mixed") if model=="ouro-1.4b-base" else ("t1",)):
            output=reports/f"factorial.{model}.{arm}.json"
            folder=work/"A"/model
            factorial(SimpleNamespace(protocol=a_protocol,native=folder/"native"/"PREDICTIONS.jsonl",
                       controller=folder/arm/"PREDICTIONS.jsonl",out=output,model=model,arm=arm,
                       only_mmlu=model=="ouro-2.6b-thinking"))
            result_a[model][arm]=read(output)
        if model in ("ouro-1.4b-base","ouro-2.6b"):
            output=reports/f"cloze.{model}.json"
            folder=work/"B"/model
            cloze(SimpleNamespace(protocol=b_protocol,native=folder/"native"/"PREDICTIONS.jsonl",
                                  t1=folder/"t1"/"PREDICTIONS.jsonl",out=output))
            result_b[model]=read(output)
        if model in ("ouro-1.4b-base","ouro-2.6b","huginn-0125"):
            import subprocess
            import sys
            compact=model=="huginn-0125"
            where=work/"C"/model
            native=(where/"0.00" if compact else work/"A"/model/"native")/"PREDICTIONS.jsonl"
            full=(where/"0.45" if compact else work/"A"/model/"t1")/"PREDICTIONS.jsonl"
            out=reports/f"dose.{model}.json"
            command=[sys.executable,str(work/"d1_dose.py"),"--model",model,"--protocol",str(a_protocol),
                     "--native",str(native),"--full-dose",str(full),"--dose-directory",str(where),"--out",str(out)]
            if compact:
                command.append("--endpoints-are-compact")
            subprocess.run(command,check=True)
            result_c[model]=read(out)
    for key,item in (("D1A_PROTOCOL_FACTORIAL",result_a),("D1B_MECHANISM_ARMS",result_b),("D1C_DOSE_RESPONSE",result_c)):
        atomic(work/f"{key}.json",item)
    dose=result_c["ouro-1.4b-base"]["results"]["0.45"]["cohorts"]["mmlu/shown_letter/ABCD"]
    high=dose["paired_confidence"]["high"]
    harm=high["n"]>0 and high["ci95"][1]<0.
    result=dict(test_accessed=False,development_only=True,
                high_confidence_soft_regularization={"use_as_ablation":harm,
                     "threshold_p":.7,"previous_arms":high,
                     "native_model":"ouro-1.4b-base","target_dose":.45,
                     "decision":"upper endpoint of paired 95% CI below zero"},
                models={key:{arm:{label:report["correctness"] for label,report in dataset["protocols"].items()
                                 if label.startswith("mmlu/")}
                             for arm,dataset in arms.items()} for key,arms in result_a.items()},
                anchors={key:digest(work/f"{key}.json") for key in ("D1A_PROTOCOL_FACTORIAL",
                                                 "D1B_MECHANISM_ARMS","D1C_DOSE_RESPONSE")})
    atomic(work/"D1_PROTOCOL_VERDICT.json",result)
    text=["# D1 同题协议与剂量诊断","",
          "| 模型 | 控制器 | MMLU 单字母原槽位变化（pp） | 置换对齐概率平均（pp） | 全局槽位方差 | 题目相关槽位方差 |",
          "| --- | --- | ---: | ---: | ---: | ---: |"]
    contrasts=[]
    for name,arms in result_a.items():
        for arm,record in arms.items():
            entry=record["protocols"]["mmlu/shown_letter/ABCD"]
            accuracy=entry["correctness"]
            fractions=entry["fractions"]
            shared=fractions["global_slot"]
            conditional=fractions["slot"]-shared
            text.append(f"| {name} | {arm} | {100*accuracy['unrotated']['difference']:+.2f} | {100*accuracy['averaged']['difference']:+.2f} "
                        f"| {100*shared:.2f}% | {100*conditional:.2f}% |")
            detail=record["same_question_protocol_contrasts"]["mmlu"]["full_content_minus_letter_when_shown"]["views"]["unrotated"]
            lo,hi=detail["paired_question_bootstrap_ci95_pp"]
            contrasts.append(f"| {name} | {arm} | {detail['n']} | {detail['first_delta_pp']:+.2f} | {detail['second_delta_pp']:+.2f} | "
                             f"{detail['difference_of_effects_pp']:+.2f} [{lo:+.2f}, {hi:+.2f}] |")
    text.extend(["", "## 展示同一组选项时，完整文本与字母评分的差异", "",
                 "| 模型 | 控制器 | 题数 | 完整文本变化（pp） | 字母变化（pp） | 同题处理效应差及 95% 区间（pp） |",
                 "| --- | --- | ---: | ---: | ---: | ---: |",*contrasts,"",
                 "保留原始选项槽位，在同一问题上计算两个评分协议的控制增益之差，然后逐题配对重采样。"
                 "槽位方差拆为跨题共同方向和随题目变化的成分。"])
    text+=["",f"高置信原生 MMLU 组纳入 {high['n']} 题。"
              f"在上界 0.45 的配对结果下，软状态正则的消融门槛{'达到' if harm else '未达到'}。",
           "", "D1-B 的候选级正标量温度用于校准；它保持单道题的选项排序。"
               "PMI 与展示选项的效果以相同候选内容的配对分数衡量。"]
    report=work/"D1_REPORT.md"
    temp=report.with_suffix(".partial")
    temp.write_text("\n".join(text)+"\n",encoding="utf-8")
    temp.replace(report)
    print("D1_PROTOCOLS_CLOSED",digest(work/"D1_PROTOCOL_VERDICT.json"),flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--work",type=Path,required=True)
    core(p.parse_args().work)

