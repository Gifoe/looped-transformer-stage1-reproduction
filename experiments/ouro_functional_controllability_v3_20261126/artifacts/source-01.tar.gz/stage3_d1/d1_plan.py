"""Prepare the complete D1 diagnostics without touching official test splits."""
import argparse
from hashlib import file_digest
import json
import os
from pathlib import Path
import sys

from d1_dose import DOSES


CROSS=Path("/root/ouro-cross-model-functional-controllability-20261125")
MODEL_ROOT=Path("/dev/shm/ouro-cross-model-20261125")
JOINT=Path("/root/ouro-external-data-joint-training-20261124")


def sha(path):
    with path.open("rb") as f:
        return file_digest(f,"sha256").hexdigest()


def read(path):
    return json.loads(path.read_text())


def plan(root):
    preflight=root/"stage0_env"/"ENV_MANIFEST.json"
    env=read(preflight)
    machine=root/"stage0_env"/env["hosts"]["old"]["receipt"]
    if env["status"]!="PREFLIGHT_OK" or sha(machine)!=env["hosts"]["old"]["sha256"]:
        raise ValueError("Stage 0 preflight receipt changed")
    assets=read(machine)
    models=assets["models"]
    anchors=assets["anchors"]
    config=read(root/"stage1_e0"/"E0_CONFIG.json")
    work=root/"stage3_d1"
    a=work/"protocol"/"D1_REQUESTS_LOCK.json"
    b=work/"protocol_cloze"/"D1B_REQUESTS_LOCK.json"
    protocols={"A":a,"B":b}
    for path in protocols.values():
        if sha(path.with_name("REQUESTS.jsonl"))!=read(path)["REQUESTS.jsonl"]:
            raise ValueError(f"Existing D1 requests changed: {path}")
    output=[]
    standard=(("ouro-1.4b-base",1),("ouro-1.4b-thinking",2),("ouro-2.6b",2),("huginn-0125",0))
    supplemental=("ouro-2.6b-thinking",1)
    native_checkpoint={
        "t1": anchors["t1"],
        "mixed": anchors["mixed"],
        "huginn": models["huginn-0125"]["controller"],
    }
    def under_root(name):
        record=native_checkpoint[name]
        path=work/"anchors"/(name+".pt")
        if sha(path)!=record["sha256"]:
            raise ValueError(f"Local immutable historical checkpoint differs: {name}")
        return dict(path=str(path),sha256=record["sha256"])

    capacity=under_root("huginn")
    t1=under_root("t1")

    def add(label,model,slot,arm,protocol,folder,cap=.45,compact=False):
        flags=[]
        pin=models.get(model)
        model_path=Path(config["model"]) if pin is None else MODEL_ROOT/model
        lock_sha=anchors["base"]["sha256"] if pin is None else pin["model_lock_sha256"]
        if arm=="native":
            control=None
        elif arm=="mixed":
            control=under_root("mixed")
        else:
            control=capacity if model=="huginn-0125" else t1
        data={"models":CROSS/"MODELS.json","model":model_path,"t1":Path(t1["path"]),
              "archive":config["archive"],"previous":config["previous"],"stage2":JOINT/"mixed_full"/"archive",
              "protocol":protocol,"out":folder,"name":model,"model-sha256":lock_sha,"arm":arm,"cap":cap}
        references={Path(__file__).resolve(),preflight,machine,work/"d1_score.py",protocol,protocol.with_name("REQUESTS.jsonl")}
        if model!="huginn-0125":
            references.add(Path(t1["path"]))
        if control is not None:
            data.update(checkpoint=control["path"],**{"checkpoint-sha256":control["sha256"]})
            references.add(Path(control["path"]))
        extra=(str(work),str(CROSS),"/root/ouro-unified-rank1-20261123",
               str(JOINT),str(JOINT/"mixed_full"/"archive"/"code"),os.environ["PYTHONPATH"])
        if model=="huginn-0125":
            extra=(str(CROSS/"huginn_deps"),*extra)
        env={"PYTHONPATH":":".join(extra)}
        if model==supplemental[0]:
            flags.append("--only-mmlu")
        if compact:
            flags.append("--only-letter-and-cloze")
        identifier=f"d1.{label}.{model}.{arm}.{cap:.2f}"
        device=str(slot)
        output.append(dict(job_id=identifier,preferred_gpu=device,estimated_seconds=500 if model=="huginn-0125" else 200,
                      cmd=[sys.executable,"-u",str(work/"d1_score.py")]+
                          [part for key,val in data.items() for part in ("--"+key,str(val))]+flags,
                      done_marker=str(work/"receipts"/f"{identifier}.json"),
                      artifacts=[str(folder/"PREDICTIONS.jsonl"),str(folder/"PREDICTIONS.json")],
                      log_path=str(work/"logs"/f"{identifier}.log"),
                      input_sha256={str(path):sha(path) for path in references},env_overrides=env))

    for model,slot in (*standard,supplemental):
        for arm in ("native","t1","mixed") if model=="ouro-1.4b-base" else ("native","t1"):
            add("a",model,slot,arm,a,work/"A"/model/arm)
        if model in {"ouro-1.4b-base","ouro-2.6b"}:
            for arm in ("native","t1"):
                add("b",model,slot,arm,b,work/"B"/model/arm)
        if model in {"ouro-1.4b-base","ouro-2.6b","huginn-0125"}:
            doses=DOSES if model=="huginn-0125" else DOSES[1:-1]
            for cap in doses:
                arm="native" if cap==0. else "t1"
                add("c",model,slot,arm,a,work/"C"/model/f"{cap:.2f}",cap=cap,compact=True)
    if len(output)!=32 or len({job["job_id"] for job in output})!=len(output):
        raise AssertionError("The protocol roster must contain 11 A, 4 B and 17 matched dose jobs")
    return dict(devices={slot:{"host":gpu["host"],"local_index":gpu["local_index"]}
                         for slot,gpu in env["gpu_devices"].items()},jobs=output,
                a_mmlu_only_supplement=supplemental[0],test_used=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",required=True,type=Path)
    parser.add_argument("--out",required=True,type=Path)
    args=parser.parse_args()
    spec=plan(args.root.resolve())
    if args.out.exists() and read(args.out)!=spec:
        raise ValueError("The locked D1 GPU plan cannot change")
    temporary=args.out.with_suffix(".partial")
    temporary.write_text(json.dumps(spec,indent=2,sort_keys=True)+"\n")
    temporary.replace(args.out)
    print("D1_DISPATCH_FROZEN",len(spec["jobs"]),sha(args.out),flush=True)


if __name__=="__main__":
    main()

