"""Stage the official Qwen2.5 Base for the v3 cross-architecture control."""
from concurrent.futures import ThreadPoolExecutor
from hashlib import file_digest
import json
from pathlib import Path

import requests

from fetch_ouro import fetch


spec = {
    "repository": "Qwen/Qwen2.5-1.5B",
    "revision": "8faed761d45a263340a0528343f099c05c9a4323",
    "weight_sha256": "a961db72e75d52b18e6b0c9d379e51a26973b233385e0e127fdda7d648aec796",
    "weight_bytes": 3087467144,
}
mirror = "https://hf-mirror.com"
response = requests.get(f"{mirror}/api/models/{spec['repository']}/revision/{spec['revision']}", params={"blobs":"true"}, timeout=30)
response.raise_for_status()
info = response.json()
if info["sha"] != spec["revision"]:
    raise ValueError("The official Qwen Base revision changed")
allowed = {"config.json","generation_config.json","merges.txt","model.safetensors","tokenizer.json","tokenizer_config.json","vocab.json"}
files = {item["rfilename"]:item for item in info["siblings"] if item["rfilename"] in allowed}
required = {"config.json","model.safetensors","tokenizer.json","tokenizer_config.json"}
if not required <= files.keys():
    raise ValueError("Official Qwen files incomplete")
asset = files["model.safetensors"]
if (asset["size"],asset["lfs"]["sha256"]) != (spec["weight_bytes"],spec["weight_sha256"]):
    raise ValueError("Model metadata disagrees with the declared Qwen weight")
target = Path("/dev/shm/ouro-cross-model-20261125/Qwen2.5-1.5B")
target.mkdir(parents=True,exist_ok=True)
with ThreadPoolExecutor(max_workers=4) as pool:
    for future in [pool.submit(fetch,target,mirror,spec,item,6,True) for item in files.values()]:
        future.result()
cfg=json.loads((target/"config.json").read_text())
if (cfg["hidden_size"],cfg["num_hidden_layers"],cfg["model_type"]) != (1536,28,"qwen2"):
    raise ValueError("Wrong architecture for the frozen non-instruction model")
receipt={}
for name in files:
    path=target/name
    with path.open("rb") as stream:
        receipt[name] = {"sha256":file_digest(stream,"sha256").hexdigest(),"size":path.stat().st_size}
partial=target/"MODEL_LOCK.partial"
partial.write_text(json.dumps(dict(**spec,hidden_size=1536,layers=28,files=receipt),indent=2)+"\n")
partial.replace(target/"MODEL_LOCK.json")
print("QWEN_BASE_READY",spec["revision"],flush=True)
