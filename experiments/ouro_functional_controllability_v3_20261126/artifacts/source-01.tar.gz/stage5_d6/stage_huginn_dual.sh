#!/usr/bin/env bash
set -euo pipefail
study=/root/ouro-v3-controllability-20261126
cross=/root/ouro-cross-model-functional-controllability-20261125
cd /root/ouro-external-data-joint-training-20261124
source external_env.sh
huginn_dir=/dev/shm/ouro-cross-model-20261125/huginn-0125
[[ "$huginn_dir" == /dev/shm/ouro-cross-model-20261125/huginn-0125 && "$huginn_dir" != "$model" ]]
cd "$study"
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
exec 8>"$study/locks/stage_huginn_dual.lock"
flock 8
if ! test -s "$cross/huginn_deps/transformers-4.49.0.dist-info/METADATA"; then
    pending="$cross/huginn_deps.v3-incoming"
    mkdir -p "$pending"
    "$py" -m pip install --no-deps --no-cache-dir --disable-pip-version-check --target "$pending" transformers==4.49.0
    test -s "$pending/transformers-4.49.0.dist-info/METADATA"
    if ! test -e "$cross/huginn_deps"; then mv "$pending" "$cross/huginn_deps"; fi
fi
PYTHONPATH="$cross/huginn_deps:$PYTHONPATH" "$py" -c 'import transformers; assert transformers.__version__ == "4.49.0"; print("HUGINN_DEPENDENCY_STAGED", transformers.__version__)'
"$py" -u "$cross/fetch_huginn.py" --out "$huginn_dir" --workers 4 --range-workers 8
"$py" - "$huginn_dir" <<'HUGINN_CHECK'
import json,sys
from pathlib import Path
from hashlib import file_digest
root=Path(sys.argv[1])
lock=json.loads((root/"MODEL_LOCK.json").read_text())
assert lock["revision"]=="bb6621b65e90b6a4b9b29ef88dc83866d450470c"
assert len(lock["files"])==12
for name,check in lock["files"].items():
    with (root/name).open("rb") as asset:
        assert file_digest(asset,"sha256").hexdigest()==check,name
print("HUGINN_OFFICIAL_ASSET_STAGED",lock["revision"],len(lock["files"]),flush=True)
HUGINN_CHECK
