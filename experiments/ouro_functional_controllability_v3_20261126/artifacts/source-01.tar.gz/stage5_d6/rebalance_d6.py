"""Reassign only D6 execution slots after the second host verifies the published Huginn assets."""

import argparse
import json
from pathlib import Path
import re

from d2_worker import digest, save_json


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def job_cost(job):
    name=job["job_id"]
    if name.startswith("d6.huginn.fisher."):
        horizon=int(name.rsplit(".",1)[1])
        return 1800+2000*horizon
    if name.startswith("d6.ouro.fisher."):
        return 5000 if "2.6b" in name else 3300
    if name.startswith("d6.qwen.fisher."):
        return 120+180*int(name.rsplit(".",1)[1])
    horizon=re.search(r"(?:horizon_|fixed_)(\d+)",name)
    if name.startswith("d6.huginn."):
        return 650+80*(int(horizon.group(1)) if horizon else 4)
    return 480 if ".fit." in name or ".source_" in name else 280


def balance(manifest,receipt,receipt_hash):
    if set(manifest["devices"])!={"0","1","2"}:
        raise ValueError("The recorded study needs exactly the three verified compute slots")
    if (receipt["revision"]!="bb6621b65e90b6a4b9b29ef88dc83866d450470c"
        or receipt["isolated_transformers"]!="4.49.0" or len(receipt["assets"])!=12):
        raise ValueError("Huginn may move only after complete dual-host model verification")
    jobs=manifest["jobs"]
    wall={"0":0.,"1":0.,"2":0.}
    routes={}
    for source in sorted(jobs,key=lambda job:(-job_cost(job),job["job_id"])):
        job=dict(source)
        name=job["job_id"]
        is_huginn=name.startswith("d6.huginn.")
        allowed=("1","2") if name.startswith(("d6.qwen.","d6.ouro.fisher.")) else ("0","1","2")
        weight=job_cost(job)
        scale=lambda slot:1.55 if slot=="0" and ".fisher." not in name else 1.
        slot=min(allowed,key=lambda target:(wall[target]+scale(target)*weight,target))
        wall[slot]+=scale(slot)*weight
        if is_huginn and "huginn_deps" not in job["env_overrides"]["PYTHONPATH"]:
            raise ValueError("The Huginn evaluator lost its isolated Transformers environment")
        job["preferred_gpu"]=slot
        job["estimated_seconds"]=weight
        routes[name]=job
    # Keep the scientific manifest order and modify no command, inputs, or outputs.
    return dict(manifest,jobs=[routes[job["job_id"]] for job in jobs],
                huginn_dual_asset_receipt_sha256=receipt_hash,
                scheduler="architecture-constrained longest processing time first",
                scheduling_cost_units=wall)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ("plan","asset-receipt","out"):
        p.add_argument(f"--{arg}",required=True,type=Path)
    args=p.parse_args()
    result=balance(read(args.plan),read(args.asset_receipt),digest(args.asset_receipt))
    if args.out.exists() and read(args.out)!=result:
        raise ValueError("A sealed D6 dispatch cannot be rebalanced after results exist")
    save_json(args.out,result)
    print("D6_BALANCED_DISPATCH",result["phase"],len(result["jobs"]),digest(args.out),flush=True)


if __name__=="__main__":
    main()
