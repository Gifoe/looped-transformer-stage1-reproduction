"""Retain completed candidate predictions after the generation-only Ouro KV repair."""

import argparse
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import shutil

from d2_worker import digest, save_json


BEFORE = "c7f3a63ebf4fd410f826d2fd999d1f368220d914ecf196e933180b82e3c1f578"
AFTER = "b58dfa9887303de6ac1afbda276b08ac4c99106dad715c596d0d370dfce94403"
BOTH = ("native", "transfer")
COHORTS = {"arc_challenge": 299, "sciq_val": 500, "arc_easy_val": 536,
           "cosmosqa_val": 500, "mmlu_val": 658}


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def canonical(job):
    return sha256(json.dumps(job, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def archive_copy(source, target):
    if not target.exists():
        shutil.copy2(source,target)
    elif digest(source)!=digest(target):
        raise ValueError(f"Archived bytes differ from the original at {source}")
    return digest(target)


def verify_plans(original, updated, scorer):
    prior = load(original)
    revised = load(updated)
    compare = deepcopy(prior)
    changed = []
    for job in compare["jobs"]:
        for key in ("input_sha256","externally_verified_input_sha256"):
            pins = job.get(key,{})
            if str(scorer) not in pins:
                continue
            if pins[str(scorer)] != BEFORE or "d6_development.py" not in job["cmd"][2]:
                raise ValueError("The old scorer binding must precede the generation-only repair")
            pins[str(scorer)] = AFTER
            changed.append(job["job_id"])
    if compare != revised or len(changed) != 11:
        raise ValueError("Only provenance for the repaired development scorer can change")
    return prior, revised, changed


def reserve_failure(root, archive, old, arm):
    job_id=f"d6.ouro26.dev.{arm}"
    incident=archive/arm
    incident.mkdir(exist_ok=True)
    log=Path(old["log_path"])
    if Path(old["done_marker"]).exists() or any(Path(path).is_file() for path in old["artifacts"]):
        raise ValueError(f"An already closed job cannot be recovered as a failure: {job_id}")
    content=log.read_text()
    if "IndexError: list index out of range" not in content or 'self.lengths[layer_idx]' not in content:
        raise ValueError(f"The failed run does not match the Ouro KV incident: {job_id}")
    log_sha=archive_copy(log,incident/"failed_execution.log")
    permission=root/"locks"/f"{job_id}.config.json"
    prior=incident/permission.name
    if permission.exists():
        if load(permission)["config_sha256"]!=canonical(old):
            raise ValueError(f"The failed job's config differs: {job_id}")
        archive_copy(permission,prior)
        permission.unlink()
    if not prior.exists() or load(prior)["config_sha256"]!=canonical(old):
        raise ValueError(f"Missing archived config for {job_id}")
    return incident, log_sha, digest(prior)


def adopt_candidates(incident, current):
    observed={}
    for cohort,population in COHORTS.items():
        data=current/f"{cohort}.jsonl"
        receipt=data.with_suffix(".receipt.json")
        prior=incident/receipt.name
        raw=load(receipt)
        if not prior.exists():
            if raw["identity"]["scorer_sha256"]!=BEFORE:
                raise ValueError("The original prediction receipt was lost before archival")
            archive_copy(receipt,prior)
        earlier=load(prior)
        adopted=deepcopy(earlier)
        if earlier["identity"]["scorer_sha256"]!=BEFORE or earlier["identity"]["architecture"]!="ouro26":
            raise ValueError("Wrong candidate scorer or model")
        if earlier["predictions"]["rows"]!=population or earlier["predictions"]["sha256"]!=digest(data):
            raise ValueError("Incomplete or changed candidate payload")
        ids=[json.loads(row)["id"] for row in data.read_text(encoding="utf-8").splitlines() if row.strip()]
        if len(ids)!=population or len(set(ids))!=population:
            raise ValueError("The recovered candidates must have unique IDs")
        adopted["identity"]["scorer_sha256"]=AFTER
        adopted["reused_from_generation_only_repair"]={"receipt_sha256":digest(prior),"scorer_sha256":BEFORE}
        if raw not in (earlier,adopted):
            raise ValueError("The candidate metrics or costs changed during the repair")
        if raw==earlier:
            save_json(receipt,adopted)
        observed[cohort]={"original_receipt_sha256":digest(prior),"adopted_receipt_sha256":digest(receipt),
                          "untouched_predictions_sha256":digest(data),"rows":population}
    return observed


def run(root):
    work=root/"stage5_d6"
    archive=work/"pre_cache_repair_attempt"
    scorer=work/"d6_development.py"
    if digest(scorer)!=AFTER or digest(scorer.with_name(f"d6_development.pre_cache_repair_{BEFORE}.py"))!=BEFORE:
        raise ValueError("The unadapted and corrected scorer code hashes are required")
    original=archive/"D6_PRIMARY_DISPATCH.json"
    active=work/"D6_PRIMARY_DISPATCH.json"
    prior,revised,changed=verify_plans(original,active,scorer)
    arms={}
    for arm in BOTH:
        job=next(item for item in prior["jobs"] if item["job_id"]==f"d6.ouro26.dev.{arm}")
        incident,log_sha,config_sha=reserve_failure(root,archive,job,arm)
        rows=adopt_candidates(incident,work/"development"/"ouro26"/arm)
        arms[arm]={"failing_log_sha256":log_sha,"failing_config_file_sha256":config_sha,"candidate_cohorts":rows}
    selected=deepcopy(revised)
    selected["jobs"]=[job for job in revised["jobs"]
                      if job["job_id"] in {"d6.ouro26.dev.native","d6.ouro26.dev.transfer"}]
    assert len(selected["jobs"])==2 and all(job["preferred_gpu"]=="0" for job in selected["jobs"])
    dispatch=work/"D6_OURO26_PREFETCH_CACHE_REPAIR.json"
    output=work/"D6_OURO26_CACHE_REPAIR_AUDIT.json"
    report={"original_code_sha256":BEFORE,"repaired_code_sha256":AFTER,
            "original_dispatch_sha256":digest(original),"repaired_dispatch_sha256":digest(active),
            "jobs_with_only_changed_scorer_input":changed,"failed_arms":arms,
            "protocol_source":"evaluate_transfer.py original full cross-model scoring",
            "repair":"four times physical layers for KV slots and historical layer-scaled token budget",
            "candidate_prediction_bytes_changed":False,"official_test_used":False}
    for path,value in ((dispatch,selected),(output,report)):
        if path.exists():
            if load(path)!=value:
                raise ValueError(f"Do not revise the frozen recovery at {path}")
        else:
            save_json(path,value)
    print("D6_OURO26_CACHE_REPAIR_AUDITED",digest(output),digest(dispatch),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,required=True)
    run(parser.parse_args().root.resolve())
