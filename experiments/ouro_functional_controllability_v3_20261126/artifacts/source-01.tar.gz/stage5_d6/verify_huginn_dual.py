"""Certify that the second host owns the exact official Huginn release and old controller."""

import json
from pathlib import Path
import time

from d2_worker import digest, save_json


def main():
    here=Path(__file__).resolve().parent
    old=here.parent/"stage0_env"/"HOST_old.json"
    prior=json.loads(old.read_text())["models"]["huginn-0125"]
    model_lock=Path(prior["assets"]["config.json"]["path"]).with_name("MODEL_LOCK.json")
    for _ in range(540):
        if model_lock.is_file():
            break
        time.sleep(15)
    else:
        raise TimeoutError("Official mirrored model assets have not finished staging")
    stamp=json.loads(model_lock.read_text())
    if stamp["repository"]!="tomg-group-umd/huginn-0125" or stamp["revision"]!=prior["revision"]:
        raise ValueError("The mirror has a different official model revision")
    expected={name:spec["sha256"] for name,spec in prior["assets"].items()}
    if expected!=stamp["files"]:
        raise ValueError("The old and second host disagree on published Huginn assets")
    import transformers
    if transformers.__version__ != prior["isolated_transformers"]:
        raise ValueError("The isolated dependency does not match the original host")
    for name,record in prior["assets"].items():
        path=Path(record["path"])
        if path.stat().st_size!=record["bytes"]:
            raise ValueError(f"Unexpected asset size: {name}")
    controller=prior["controller"]
    if digest(Path(controller["path"]))!=controller["sha256"]:
        raise ValueError("The fixed historical Huginn Rank-1 differs")
    receipt=dict(host="dual",revision=prior["revision"],assets=expected,
                 isolated_transformers=transformers.__version__,controller=controller,
                 stage0_receipt_sha256=digest(old),dual_model_lock_sha256=digest(model_lock),
                 old_model_lock_sha256=prior["model_lock_sha256"],
                 verification="compare the full checksummed official asset manifest against the original Stage 0 host receipt")
    target=here/"HUGINN_DUAL_READY.json"
    if target.exists() and json.loads(target.read_text())!=receipt:
        raise ValueError("Huginn environment receipt changed after validation")
    save_json(target,receipt)
    print("HUGINN_DUAL_READY",digest(target),flush=True)


if __name__=="__main__":
    main()
