"""Compile the three independent D6 lanes from the frozen D2 reference."""
import argparse
import json
import os
from pathlib import Path
import sys

from d2_worker import digest, save_json


HORIZONS=(1,2,3,4,6,8,12)
LAYERS=(24,16,6,0)
QWEN_SEEDS=(261126601,261126602)
HUG_SEED=261125137
CROSS=Path("/root/ouro-cross-model-functional-controllability-20261125")
MODELS=Path("/dev/shm/ouro-cross-model-20261125")
GEOMETRY_CACHE=Path("/root/autodl-tmp/ouro-v3-cache/d6")
SLOTS={"0":{"host":"old","local_index":0},"1":{"host":"dual","local_index":0},"2":{"host":"dual","local_index":1}}


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def configure(args):
    root=args.root.resolve()
    env=root/"stage0_env"/"ENV_MANIFEST.json"
    e0=root/"stage1_e0"/"E0_CONFIG.json"
    core=read(env)
    primary=root/"stage2_d2"/"D2_SUBSPACE_LOCK.json"
    reference=primary.with_name("D2_REF_OPERATOR.pt")
    trust=read(primary)
    if core["status"]!="PREFLIGHT_OK" or trust["controller_sha256"]!=digest(reference):
        raise ValueError("Freeze the primary no-label D2 reference before D6")
    documents=env.parent/"UNLABELED_CORPUS"
    fit=documents/"fit_unlabeled.jsonl"
    audit=documents/"audit_unlabeled.jsonl"
    if digest(fit)!=trust["fit_sha256"] or digest(audit)!=trust["audit_sha256"]:
        raise ValueError("All architecture comparisons use the identical independent text populations")
    host=core["hosts"]["old"]
    physical=env.parent/host["receipt"]
    if digest(physical)!=host["sha256"]:
        raise ValueError("The local model preflight changed")
    assets=read(physical)["models"]
    settings=read(e0)
    official=root/"stage3_d1"/"protocol"/"D1_REQUESTS_LOCK.json"
    study=root/"stage5_d6"
    historic_hug=Path(assets["huginn-0125"]["controller"]["path"])
    historic_t1=Path(settings["historical_t1"])
    official_arc=args.arc_corpus/"train.parquet"
    if digest(official_arc)!="0f84cb4e393a729371c3dfd334fce14215a99dcff8095bf31271787f1e305f20":
        raise ValueError("Huginn must reuse the originally published 1,119-example training split")
    variants=("ouro-1.4b-thinking","ouro-2.6b","ouro-2.6b-thinking")
    base_paths=(study,root/"stage2_d2",root/"stage1_e0"/"code",root/"stage3_d1",
                CROSS,Path(settings["followup"]),Path(settings["unified"]))
    ordinary=":".join(map(str,base_paths))+":"+os.environ["PYTHONPATH"]
    isolated=str(CROSS/"huginn_deps")+":"+ordinary
    pending=[]

    def add(job,function,slot,arguments,files,artifacts):
        script=study/function
        all_inputs={p:digest(p) for p in set(files)|{script,env,e0,primary,reference,Path(__file__)}}
        out=dict(job_id=f"d6.{job}",preferred_gpu=str(slot),estimated_seconds=360,
                 cmd=[sys.executable,"-u",str(script),*map(str,arguments)],
                 input_sha256={str(p):h for p,h in all_inputs.items() if p.resolve().is_relative_to(root)},
                 externally_verified_input_sha256={str(p):h for p,h in all_inputs.items() if not p.resolve().is_relative_to(root)},
                 env_overrides={"PYTHONPATH":isolated if slot==0 else ordinary},
                 log_path=str(study/"logs"/f"{job}.log"),done_marker=str(study/"receipts"/f"{job}.json"),
                 artifacts=[str(p) for p in artifacts])
        pending.append(out)

    def score(model,slot,q,horizon,tag,weight=None):
        folder=study/"development"/q/tag
        model_arg=["--model",MODELS/model,"--architecture",q,"--depth-setting",horizon]
        anchor_flags=["--weight",weight,"--weight-sha256",digest(weight)] if weight else []
        emitted=[folder/"DEVELOPMENT.json"]
        if q=="huginn" and weight:
            emitted.append(folder/"STATE_RESPONSE.json")
        add(f"{q}.dev.{tag}","d6_development.py",slot,model_arg+["--config",e0,"--rotation-protocol",official,
            "--ouro-models",CROSS/"MODELS.json","--out",folder]+anchor_flags,
            [official,official.with_name("REQUESTS.jsonl")]+([weight] if weight else []),emitted)

    def huginn_fits():
        for horizon in HORIZONS:
            seeds=(HUG_SEED,261126602) if horizon in (1,4,6,8) else (HUG_SEED,)
            for seed in seeds:
                tag=f"horizon_{horizon}.{seed}"
                yield horizon,seed,tag,study/"fits"/"huginn"/tag

    def qwen_fits():
        for depth in LAYERS:
            for seed in QWEN_SEEDS:
                tag=f"layers_{depth}.{seed}"
                yield depth,seed,tag,study/"fits"/"qwen"/tag

    if args.phase=="primary":
        score("huginn-0125",0,"huginn",1,"native")
        for horizon in HORIZONS:
            tag=f"fixed_{horizon}"
            score("huginn-0125",0,"huginn",horizon,tag,historic_hug)
        for horizon,seed,tag,folder in huginn_fits():
            add(f"huginn.fit.{tag}","d6_huginn.py",0,["--model",MODELS/"huginn-0125","--archive",settings["archive"],
                "--corpus",args.arc_corpus,"--out",folder,"--horizon",horizon,"--seed",seed],
                [official_arc],[folder/"controller.pt",folder/"FIT.json"])
        for horizon in HORIZONS:
            folder=study/"geometry"/"huginn"/f"m{horizon}"
            add(f"huginn.fisher.{horizon}","d6_huginn_geometry.py",0,
                ["--env",env,"--model",MODELS/"huginn-0125","--fit",fit,"--reference",primary,
                 "--out",folder,"--horizon",horizon],
                [fit],[folder/"HORIZON_FISHER.json",folder/"LEADING_HORIZON_AXIS.pt"])
        score("ouro-2.6b",1,"ouro26",4,"native")
        score("ouro-2.6b",1,"ouro26",4,"transfer",historic_t1)
        for init in ("cold","transferred_t1"):
            tag=f"{init}.261126601"
            folder=study/"fits"/"ouro26"/tag
            add(f"ouro26.fit.{tag}","d6_ouro_fit.py",1,
                ["--config",e0,"--models",CROSS/"MODELS.json","--model",MODELS/"ouro-2.6b","--out",folder,
                 "--source","arc_challenge","--initialization",init,"--seed",261126601],
                [],[folder/"controller.pt",folder/"TRAIN.json"])
        for model in variants:
            folder=study/"geometry"/model
            add(f"ouro.fisher.{model}","d6_ouro_spectrum.py",1,
                ["--model",MODELS/model,"--model-sha256",assets[model]["weights"]["sha256"],
                 "--fit",fit,"--env",env,"--d2-lock",primary,"--out",folder,"--cache-root",GEOMETRY_CACHE],
                [fit],[folder/"FISHER_SUBSPACES.pt",folder/"SPECTRUM.json"])
        score("Qwen2.5-1.5B",2,"qwen",0,"native")
        for depth,seed,tag,folder in qwen_fits():
            add(f"qwen.fit.{tag}","d6_qwen.py",2,["--model",MODELS/"Qwen2.5-1.5B","--config",e0,"--out",folder,
                "--remaining",depth,"--seed",seed],[],[folder/"TRAIN.json",folder/"controller.pt"])
        for depth in reversed(LAYERS):
            folder=study/"geometry"/"qwen"/f"layers_{depth}"
            add(f"qwen.fisher.{depth}","d6_qwen_geometry.py",2,
                ["--model",MODELS/"Qwen2.5-1.5B","--fit",fit,"--environment",env,"--d2-lock",primary,
                 "--out",folder,"--remaining",depth,"--cache-root",GEOMETRY_CACHE],
                [fit],[folder/"D6_QWEN_GEOMETRY.json",folder/"FISHER_SUBSPACES.pt"])
    elif args.phase=="fitted_dev":
        for horizon,seed,tag,folder in huginn_fits():
            score("huginn-0125",0,"huginn",horizon,tag,folder/"controller.pt")
        for depth,seed,tag,folder in qwen_fits():
            score("Qwen2.5-1.5B",2,"qwen",depth,tag,folder/"controller.pt")
        for init in ("cold","transferred_t1"):
            tag=f"{init}.261126601"
            score("ouro-2.6b",1,"ouro26",4,tag,study/"fits"/"ouro26"/tag/"controller.pt")
    elif args.phase=="intrinsic":
        best=study/"HUGINN_HORIZON_SELECTION.json"
        choice=read(best)
        m=choice["best"]
        assert m in HORIZONS
        for model,slot,tag,horizon,space in (
             ("ouro-2.6b",1,"ouro26",4,study/"geometry"/"ouro-2.6b"/"FISHER_SUBSPACES.pt"),
             ("huginn-0125",0,"huginn",m,study/"geometry"/"huginn"/f"m{m}"/"LEADING_HORIZON_AXIS.pt")):
            folder=study/"orientation"/tag
            add(f"{tag}.intrinsic","d6_intrinsic_anchor.py",slot,
                ["--d2-lock",primary,"--model",MODELS/model,"--subspace",space,"--fit",fit,"--audit",audit,
                 "--out",folder,"--architecture",tag,"--horizon",horizon],
                [space,fit,audit,best],[folder/"INTRINSIC_LOCK.json",folder/"controller.pt",folder/"AUDIT.json"])
    elif args.phase in {"source_probes","source_fits","source_development"}:
        from d6_signed_source import SOURCES
        best=study/"HUGINN_HORIZON_SELECTION.json"
        chosen=read(best)["best"]
        setups=(("huginn",0,"huginn-0125",chosen),("ouro26",1,"ouro-2.6b",4))
        for arch,slot,model,depth in setups:
            folder=study/"orientation"/arch
            anchor=folder/"controller.pt"
            lock=folder/"INTRINSIC_LOCK.json"
            if digest(anchor)!=read(lock)["controller_sha256"]:
                raise ValueError("Architecture source probes require a closed no-label initial point")
            source_folder=study/"source_forecasts"/arch
            forecast=source_folder/"CROSS_ARCH_FORECAST.json"
            if args.phase=="source_probes":
                add(f"{arch}.source_probes","d6_signed_source.py",slot,
                    ["--config",e0,"--reference",anchor,"--model",MODELS/model,"--ouro-models",CROSS/"MODELS.json",
                     "--out",source_folder,"--architecture",arch,"--horizon",depth],
                    [anchor,lock,best],[forecast,forecast.with_suffix(".sha256")])
                continue
            if forecast.with_suffix(".sha256").read_text().split()[0]!=digest(forecast):
                raise ValueError("A D6 source forecast must be frozen before training")
            for source in SOURCES:
                path=study/"source_fits"/arch/source
                if args.phase=="source_fits":
                    common=["--config",e0,"--model",MODELS/model,"--out",path,
                             "--source",source,"--seed",261126627]
                    files=[anchor,lock,forecast,forecast.with_suffix(".sha256")]
                    outputs=[path/"controller.pt",path/"TRAIN.json"]
                    if arch=="huginn":
                        add(f"huginn.source_fit.{source}","d6_huginn_fit_source.py",slot,
                            common+["--horizon",depth,"--forecast",forecast,"--reference",anchor],files,outputs)
                    else:
                        add(f"ouro26.source_fit.{source}","d6_ouro_fit.py",slot,
                            common+["--models",CROSS/"MODELS.json","--initialization","intrinsic",
                                    "--orientation",anchor,"--source-forecast",forecast],files,outputs)
                else:
                    score(model,slot,arch,depth,f"source_{source}",path/"controller.pt")
        if args.phase=="source_fits":
            arch,slot,model,depth=setups[1]
            folder=study/"orientation"/arch
            tag="intrinsic.261126601"
            root_target=study/"fits"/arch/tag
            add(f"{arch}.fit.{tag}","d6_ouro_fit.py",slot,
                ["--config",e0,"--model",MODELS/model,"--models",CROSS/"MODELS.json","--out",root_target,
                 "--source","arc_challenge","--seed",261126601,"--initialization","intrinsic",
                 "--orientation",folder/"controller.pt"],
                [folder/"controller.pt",folder/"INTRINSIC_LOCK.json"],[root_target/"controller.pt",root_target/"TRAIN.json"])
        if args.phase=="source_development":
            score("ouro-2.6b",1,"ouro26",4,"intrinsic.261126601",
                  study/"fits"/"ouro26"/"intrinsic.261126601"/"controller.pt")
    if len({x["job_id"] for x in pending})!=len(pending):
        raise ValueError("Duplicate cross-architecture computation")
    manifest=dict(devices=SLOTS,jobs=pending,phase=args.phase,official_test=False)
    if args.out.exists() and read(args.out)!=manifest:
        raise ValueError("Immutable D6 roster changed")
    save_json(args.out,manifest)
    print("D6_DISPATCH",args.phase,len(pending),digest(args.out),flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root",required=True,type=Path)
    p.add_argument("--out",required=True,type=Path)
    p.add_argument("--phase",required=True,choices=("primary","fitted_dev","intrinsic","source_probes","source_fits","source_development"))
    p.add_argument("--arc-corpus",required=True,type=Path)
    configure(p.parse_args())

