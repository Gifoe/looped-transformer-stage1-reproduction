"""Render the closed D2 mechanism, transfer and sample-efficiency evidence."""
import argparse
from hashlib import file_digest
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator


BLUE="#0F4D92"
SKY="#3775BA"
RED="#B64342"
TEAL="#42949E"
VIOLET="#9A4D8E"
GRAY="#767676"
BLACK="#272727"
GRID="#E7E7E7"


plt.rcParams.update({
    "font.family":"sans-serif",
    "font.sans-serif":["Arial","Helvetica","Liberation Sans","DejaVu Sans"],
    "font.size":11,
    "axes.spines.right":False,
    "axes.spines.top":False,
    "axes.linewidth":1.2,
    "axes.labelcolor":BLACK,
    "text.color":BLACK,
    "legend.frameon":False,
    "legend.fontsize":9,
    "pdf.fonttype":42,
    "svg.fonttype":"none",
})


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    with path.open("rb") as f:
        return file_digest(f,"sha256").hexdigest()


def panel(ax,letter,title):
    ax.set_title(f"{letter}   {title}",loc="left",fontweight="bold",fontsize=12,pad=11)
    ax.tick_params(axis="both",labelsize=10)
    ax.set_axisbelow(True)


def spectra(ax,released):
    panel(ax,"A","Recurrent Fisher spectra")
    records=released["results"]
    for key,legend,color,style in (
        ("normalized_reg_small",r"$\gamma=0.01$",SKY,"--"),
        ("main",r"$\gamma=0.1$",BLUE,"-"),
        ("normalized_reg_large",r"$\gamma=1$",RED,"-."),
    ):
        points=records[key]["eigenvalues"]
        ax.plot(np.arange(1,len(points)+1),points,label=legend,color=color,ls=style,lw=2.05)
    ax.set_yscale("log")
    ax.set_xlabel("Generalized eigenvalue rank")
    ax.set_ylabel(r"Fisher quotient $\mu$")
    ax.xaxis.set_major_locator(FixedLocator([1,8,16,24,32]))
    ax.legend(loc="upper right",borderaxespad=.25)
    ax.grid(axis="y",color=GRID,linewidth=.6)


def transient(ax,released):
    panel(ax,"B","Propagation of a matched write")
    depths=np.arange(4,9)
    for name,label,color,marker in (("random","Fisher − random",BLUE,"o"),("pca","Fisher − PCA",TEAL,"s")):
        pairs=[released["curves"][str(k)]["state_amplification"]["pairing"][name] for k in depths]
        means=[entry["mean_paired_delta"] for entry in pairs]
        low,high=np.asarray([entry["mean_paired_delta_ci95"] for entry in pairs]).T
        ax.fill_between(depths,low,high,color=color,alpha=.14,linewidth=0)
        ax.plot(depths,means,color=color,lw=2,marker=marker,markersize=4,label=label)
    ax.axhline(0,color=GRAY,lw=1,ls=":")
    ax.set_xticks(depths)
    ax.set_xlabel("Total native loops")
    ax.set_ylabel("Paired difference in amplification (×)")
    ax.grid(axis="y",color=GRID,linewidth=.6)
    ax.legend(loc="upper left",borderaxespad=.25)


def samples(ax,released):
    panel(ax,"C","Supervised ARC sample efficiency")
    sizes=[8,16,32,64,128,256,1013]
    colors=[
        ("Full_Cold","Full cold",BLACK,"o","-"),
        ("UFR16_Proj","Fisher-16 projection",BLUE,"s","-"),
        ("U1_PMI_Warm","PMI warm start",RED,"D","-"),
        ("PCA16_Proj","PCA-16 projection",TEAL,"^","--"),
        ("Rand16_Proj","Random-16 projection",GRAY,"x",":"),
    ]
    for key,label,color,marker,style in colors:
        points=[released["groups"][f"{key}.{n}"] for n in sizes]
        mean,sd=np.asarray([[100*point["mean"],100*point["std"]] for point in points]).T
        ax.fill_between(sizes,mean-sd,mean+sd,color=color,alpha=.085,linewidth=0)
        ax.plot(sizes,mean,lw=1.75,color=color,marker=marker,markersize=3.8,ls=style,label=label)
    ax.axhline(released["native"]*100,linestyle=":",linewidth=1,color=VIOLET)
    ax.set_xscale("log",base=2)
    ax.set_xticks(sizes,labels=[str(n) if n!=1013 else "1,013" for n in sizes])
    ax.minorticks_off()
    ax.set_xlabel("ARC-Challenge training examples")
    ax.set_ylabel("Held-out macro accuracy (%)")
    ax.set_ylim(54,69)
    ax.grid(axis="y",color=GRID,linewidth=.6)
    return ax.get_legend_handles_labels()


def doses(ax,released):
    panel(ax,"D","Task effects of replacing the write axis")
    entries=[
        ("ufr1_mean","Fisher rank 1",BLUE,"o"),
        ("jacobian_right1","Jacobian top right singular vector",RED,"D"),
        ("exit_gate","Exit gate",GRAY,"^"),
        ("natural_displacement","Natural displacement",TEAL,"s"),
    ]
    table=released["paired_only_write_direction_changed"]
    for index,(key,label,color,marker) in enumerate(entries):
        item=table[key]["fixed_input_candidate_only_macro"]
        effect=item["delta_pp"]
        lo,hi=item["ci95_pp"]
        ax.errorbar(effect,index,xerr=[[effect-lo],[hi-effect]],fmt=marker,capsize=3.4,
                    color=color,elinewidth=1.8,markersize=6,zorder=3)
    ax.set_yticks(range(len(entries)),labels=[row[1] for row in entries],fontsize=9.25)
    ax.set_ylim(len(entries)-.45,-.55)
    ax.axvline(0,color=GRAY,ls=":",lw=1.1)
    ax.set_xlim(-14,2.4)
    ax.set_xlabel("Accuracy difference vs. random write (pp)")
    ax.grid(axis="x",color=GRID,linewidth=.6)
    ax.tick_params(axis="y",length=0)


def render(study,out):
    work=study/"stage2_d2"
    verdict=read(work/"D2_VERDICT.json")
    chosen=(
        "spectral/D2_SPECTRAL_AUDIT.json",
        "D2_PHYSICAL_TRANSIENT_PAIRED_AUDIT.json",
        "D2_SAMPLE_EFFICIENCY.json",
        "D2_MATCHED_WRITE_DIRECTION.json",
    )
    loaded=[]
    for source in chosen:
        path=work/source
        if sha(path)!=verdict["files_sha256"][source]:
            raise ValueError(f"The plotted source differs from the closed D2 manifest at {path}")
        loaded.append(read(path))
    if loaded[1]["n"]!=64 or loaded[2]["n_arms"]!=105:
        raise ValueError("The plotted runs must have the original independent populations")
    fig,axs=plt.subplots(2,2,figsize=(12.6,8.0),gridspec_kw={"width_ratios":[1.02,1]})
    spectra(axs[0,0],loaded[0])
    transient(axs[0,1],loaded[1])
    handles,labels=samples(axs[1,0],loaded[2])
    doses(axs[1,1],loaded[3])
    handles.append(Line2D([0],[0],color=VIOLET,ls=":",lw=1))
    labels.append("Native")
    fig.tight_layout(pad=1.6,w_pad=2.7,h_pad=2.2,rect=(0,.105,1,1))
    fig.legend(handles,labels,ncol=3,loc="lower center",bbox_to_anchor=(.5,.01),columnspacing=2.4)
    out.mkdir(parents=True,exist_ok=True)
    targets=[]
    for ext in ("pdf","png","svg"):
        dest=out/f"FIG_D2_CONTROL_SENSITIVITY.{ext}"
        fig.savefig(dest,dpi=300,facecolor="white")
        targets.append(dest)
    plt.close(fig)
    manifest={
        "scope":"Frozen mechanism and development evidence only",
        "stage2_verdict_sha256":sha(work/"D2_VERDICT.json"),
        "sources_sha256":{source:verdict["files_sha256"][source] for source in chosen},
        "panels":{
            "A":"Top 32 generalized recurrent Fisher eigenvalues from 1,024 unlabeled fit segments, three normalized-write ridges.",
            "B":"Mean paired difference in the measured state-amplification ratio, 64 independent text segments and epsilon 0.001. Bands are 95% document-bootstrap intervals.",
            "C":"Equal-weight macro accuracy across five fixed development tasks, mean and sample SD of three seeds. Each method received the same ARC examples and 280 updates in a seed.",
            "D":"Equal-gain, fixed-input comparisons on four candidate-scoring development cohorts and 2,194 questions. Intervals are pointwise paired 95% bootstrap intervals."
        },
        "files_sha256":{path.name:sha(path) for path in targets},
        "matplotlib_version":matplotlib.__version__,
        "renderer_sha256":sha(Path(__file__)),
    }
    point=out/"FIG_D2_CONTROL_SENSITIVITY.json"
    point.write_text(json.dumps(manifest,indent=2,sort_keys=True,ensure_ascii=False)+"\n",encoding="utf-8")
    print("D2_FIGURE_RENDERED",sha(point),flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--study",type=Path,required=True)
    p.add_argument("--out",type=Path,required=True)
    a=p.parse_args()
    render(a.study.resolve(),a.out.resolve())
