"""Plot fully closed within-question protocol contrasts and controlled dose responses."""
import argparse
import json
from pathlib import Path

import numpy as np

from plot_d2 import BLACK, BLUE, GRAY, GRID, RED, SKY, TEAL, VIOLET, panel, plt, read, sha


ORDER=(
    ("ouro-1.4b-base","t1","Ouro-1.4B Base"),
    ("ouro-1.4b-thinking","t1","Ouro-1.4B Thinking"),
    ("ouro-2.6b","t1","Ouro-2.6B Base"),
    ("ouro-2.6b-thinking","t1","Ouro-2.6B Thinking"),
    ("huginn-0125","t1","Huginn-3.5B"),
    ("ouro-1.4b-base","mixed","1.4B Base (Mixed)"),
)
DOSE_MODELS=(
    ("ouro-1.4b-base","Ouro-1.4B Base",BLUE,"o"),
    ("ouro-2.6b","Ouro-2.6B Base",TEAL,"s"),
    ("huginn-0125","Huginn-3.5B",RED,"D"),
)


def style_rows(ax):
    ax.set_yticks(range(len(ORDER)),labels=[entry[2] for entry in ORDER],fontsize=9.2)
    ax.set_ylim(len(ORDER)-.45,-.55)
    ax.tick_params(axis="y",length=0)
    ax.grid(axis="x",color=GRID,lw=.6)


def protocol(ax,stats):
    panel(ax,"A","Complete text vs. letter scoring")
    for i,(model,arm,_) in enumerate(ORDER):
        views=stats[model][arm]["same_question_protocol_contrasts"]["mmlu"][
            "full_content_minus_letter_when_shown"]["views"]
        for name,offset,color,marker in (("unrotated",-.14,BLUE,"o"),("averaged",.15,RED,"s")):
            row=views[name]
            point=row["difference_of_effects_pp"]
            lo,hi=row["paired_question_bootstrap_ci95_pp"]
            ax.errorbar(point,i+offset,xerr=[[point-lo],[hi-point]],fmt=marker,color=color,
                        markersize=4,elinewidth=1.6,capsize=3,zorder=4)
    from matplotlib.lines import Line2D
    handles=[Line2D([0],[0],color=BLUE,marker="o",ls="",label="Original order"),
             Line2D([0],[0],color=RED,marker="s",ls="",label="Average over four orders")]
    ax.axvline(0,color=GRAY,ls=":",lw=1)
    ax.set_xlabel("Difference in controller effects (pp)")
    style_rows(ax)
    return handles


def variance(ax,stats):
    panel(ax,"B","Where letter-score changes vary")
    colors=[BLUE,"#E9A6A1","#AADCA9","#CFCECE"]
    names=["Answer content","Global slot","Question-specific slot","Residual"]
    for i,(model,arm,_) in enumerate(ORDER):
        condition=stats[model][arm]["protocols"]["mmlu/shown_letter/ABCD"]["fractions"]
        points=[condition["content"],condition["global_slot"],
                condition["slot"]-condition["global_slot"],condition["residual"]]
        if not np.isclose(sum(points),1,atol=1e-10):
            raise ValueError("The plotted decomposition must have disjoint variance components")
        previous=0
        for j,(part,color,tag) in enumerate(zip(points,colors,names,strict=True)):
            ax.barh(i,100*part,left=previous,height=.63,color=color,edgecolor=BLACK,lw=.35,
                    hatch=("//" if j==1 else None),label=tag if i==0 else None,zorder=3)
            previous+=100*part
    ax.set_xlim(0,100)
    ax.set_xticks([0,25,50,75,100])
    ax.set_xlabel("Fraction of centered score-change variance (%)")
    style_rows(ax)
    return ax.get_legend_handles_labels()


def dose_curves(ax,calibration,stats):
    title="Confidence calibration across doses" if calibration else "MMLU accuracy across doses"
    panel(ax,"D" if calibration else "C",title)
    for model,label,color,marker in DOSE_MODELS:
        entries=stats[model]["results"]
        pairs=sorted((float(a),row["cohorts"]["mmlu/shown_letter/ABCD"]) for a,row in entries.items())
        if len(pairs)!=7:
            raise ValueError("Each model needs all seven matched receiver doses")
        doses=[a for a,_ in pairs]
        if calibration:
            values=[100*(r["ece_equal_count_15"]-r["native"]["ece_equal_count_15"]) for _,r in pairs]
        else:
            values=[100*r["paired"]["difference"] for _,r in pairs]
            lo,hi=100*np.asarray([r["paired"]["ci95"] for _,r in pairs]).T
            ax.fill_between(doses,lo,hi,color=color,alpha=.12,linewidth=0)
        ax.plot(doses,values,color=color,label=label,lw=2,marker=marker,markersize=4)
    ax.axhline(0,color=GRAY,lw=1,ls=":")
    ax.set_xticks([0,.05,.10,.15,.25,.35,.45],labels=["0",".05",".10",".15",".25",".35",".45"])
    ax.set_xlabel("Relative RMS cap")
    ax.set_ylabel("Change in ECE (pp)" if calibration else "Change in accuracy (pp)")
    ax.grid(axis="y",color=GRID,lw=.6)
    return ax.get_legend_handles_labels()


def render(study,out):
    work=study/"stage3_d1"
    gate=work/"D1_PROTOCOL_VERDICT.json"
    verdict=read(gate)
    if verdict["test_accessed"] or not verdict["development_only"]:
        raise ValueError("The protocol figure is based exclusively on matched development data")
    names=("D1A_PROTOCOL_FACTORIAL","D1C_DOSE_RESPONSE")
    raw=[]
    for name in names:
        file=work/(name+".json")
        if sha(file)!=verdict["anchors"][name]:
            raise ValueError(f"The plotted D1 result changed after the stage closed: {name}")
        raw.append(read(file))
    fig,axs=plt.subplots(2,2,figsize=(13.4,8.5),gridspec_kw={"width_ratios":[1.03,1]})
    a=protocol(axs[0,0],raw[0])
    b,bl=variance(axs[0,1],raw[0])
    c,cl=dose_curves(axs[1,0],False,raw[1])
    dose_curves(axs[1,1],True,raw[1])
    for ax,handles,labels in ((axs[0,0],a,[x.get_label() for x in a]),(axs[0,1],b,bl)):
        ax.legend(handles,labels,loc="upper left",bbox_to_anchor=(-.02,-.24),ncol=2,
                  columnspacing=1.0,borderaxespad=0.,handletextpad=.5)
    fig.tight_layout(pad=1.6,w_pad=2.25,h_pad=4.3,rect=(0,.065,1,1))
    fig.legend(c,cl,ncol=3,loc="lower center",bbox_to_anchor=(.5,.009),columnspacing=2.6)
    out.mkdir(parents=True,exist_ok=True)
    targets=[]
    for extension in ("pdf","png","svg"):
        file=out/f"FIG_D1_PROTOCOL_AND_DOSE.{extension}"
        fig.savefig(file,facecolor="white",dpi=300)
        print(file.name,sha(file),flush=True)
        targets.append(file)
    plt.close(fig)
    receipt={
        "d1_verdict_sha256":sha(gate),"sources_sha256":{k:verdict["anchors"][k] for k in names},
        "renderer_sha256":sha(Path(__file__)),"shared_style_sha256":sha(Path(__file__).with_name("plot_d2.py")),
        "files_sha256":{p.name:sha(p) for p in targets},
        "scope":"400 matched four-choice MMLU development items. Both readout protocols present the same answer choices.",
        "panels":{
            "A":"Treatment effect under shown full-content scoring minus under shown letter scoring. Bootstrap uses matched questions.",
            "B":"Centered score-change variance, with the overall slot term split into shared and question-specific components.",
            "C":"Same-item accuracy difference within each model relative to its unmodified dose endpoint, with paired 95% bootstrap intervals.",
            "D":"Change in fifteen-bin equal-count expected calibration error relative to each model's unmodified endpoint."
        },
    }
    file=out/"FIG_D1_PROTOCOL_AND_DOSE.json"
    file.write_text(json.dumps(receipt,indent=2,sort_keys=True,ensure_ascii=False)+"\n",encoding="utf-8")
    print("D1_FIGURE_RENDERED",sha(file),flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--study",type=Path,required=True)
    p.add_argument("--out",type=Path,required=True)
    args=p.parse_args()
    render(args.study.resolve(),args.out.resolve())
