"""Resume a matched supervised sample-efficiency arm, then score its frozen weights."""
import argparse
import json
from pathlib import Path
from types import SimpleNamespace

from d2_sample_efficiency import arm, METHODS, SIZES, SEEDS
from score_shared_dev import run


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("reference","e0-config","out"):
        parser.add_argument(f"--{name}",type=Path,required=True)
    parser.add_argument("--method",choices=METHODS,required=True)
    parser.add_argument("--samples",type=int,choices=SIZES,required=True)
    parser.add_argument("--seed",type=int,choices=SEEDS,required=True)
    parser.add_argument("--steps",type=int,default=280)
    args=parser.parse_args()
    arm(args)
    import gc
    import torch
    gc.collect()
    torch.cuda.empty_cache()
    meta=json.loads((args.out/"TRAIN.json").read_text())
    run(SimpleNamespace(config=args.e0_config,weight=args.out/"controller.pt",out=args.out/"dev",
                         weight_sha256=meta["checkpoint_sha256"],arm=args.out.name))


if __name__=="__main__":
    main()

