"""Confirm fitted Fisher directions on a disjoint unlabelled corpus."""

import argparse
from hashlib import sha256
import json
from pathlib import Path

import torch
from torch.func import jvp, vmap
from torch.nn.attention import SDPBackend, sdpa_kernel

from d2_block import RMSFisherReadout
from d2_operator import capture, one_loop, write_scales
from d2_worker import digest, load, model_load, parse_rows, save_json, save_pt, token_ids


@torch.no_grad()
def variance(readout, cached, tangent, chunk=24):
    h,r,c,p=cached
    width=h.shape[-1]
    derivatives=tangent.reshape(tangent.shape[0],-1,width)
    sum_variance=derivatives.new_zeros(len(derivatives),dtype=torch.float64)
    for start in range(0,len(h),chunk):
        end=start+chunk
        point=h[start:end]
        scale=r[start:end]
        factor=c[start:end]
        delta=derivatives[:,start:end]
        d_at_norm=(delta-point*(point*delta).sum(-1,keepdim=True)*factor)*scale
        logits=d_at_norm@readout.weight.mT
        probability=p[start:end]
        mean=(probability*logits).sum(-1,keepdim=True)
        sum_variance += (probability*(logits-mean).square()).sum(dim=(-1,-2),dtype=torch.float64)
    return sum_variance/len(h)


def audit(args):
    identity=json.loads(args.environment.read_text())["frozen_data"]["UNLABELED_CORPUS/audit_unlabeled.jsonl"]["sha256"]
    if digest(args.audit)!=identity:
        raise ValueError("The data do not match the independent text audit")
    fitting=json.loads(args.spectrum_lock.read_text())
    if fitting["fit_sha256"]==identity:
        raise ValueError("A training corpus cannot substitute for held-out evidence")
    candidates=parse_rows(args.audit)
    if len(candidates)!=512 or not 0<=args.shard<args.shards:
        raise ValueError("The full declared audit population is required")
    subspace=load(args.subspaces)
    eigen=load(args.eigenvectors)["axes"].float()
    pca=subspace["U_PCA"][:,:16].float()
    rng=torch.Generator().manual_seed(26112626)
    random=torch.linalg.qr(torch.randn(eigen.shape[0],16,generator=rng)).Q
    directions=torch.cat((eigen,pca,random),dim=1)
    directions=(directions/directions.norm(dim=0)).cuda()
    joined=parse_rows(args.audit)[args.shard::args.shards]
    pca_fingerprint=sha256(pca.contiguous().cpu().numpy().tobytes()).hexdigest()
    spec=dict(audit_sha256=identity,eigensol_sha256=digest(args.eigenvectors),pca_directions_sha256=pca_fingerprint,
              fit_sha256=fitting["fit_sha256"],model_sha256=args.model_sha256,shard=args.shard,
              shards=args.shards,block=args.block,rank_groups=[eigen.shape[1],16,16],runner_sha256=digest(Path(__file__)))
    args.out.mkdir(parents=True,exist_ok=True)
    lock=args.out/"AUDIT_LOCK.json"
    if lock.exists() and json.loads(lock.read_text())!=spec:
        raise ValueError("Held-out operator audit configuration was changed")
    save_json(lock,spec)
    complete=args.out/"HELDOUT_RAYLEIGH.pt"
    if complete.exists():
        trial=load(complete)
        if ({key:trial.get(key) for key in spec}!=spec or trial["n"]!=len(joined)
            or trial["ids"]!=[row["id"] for row in joined]
            or any(trial[k].shape!=(len(joined),64) or not trial[k].isfinite().all() for k in ("direct","mediated"))):
            raise ValueError("A complete held-out shard used different directions or rows")
        print("D2_HELDOUT_RAYLEIGH_REUSED",args.shard,len(joined),flush=True)
        return
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32=False
    model,tokenizer=model_load(args)
    norm=model.model.norm
    head=RMSFisherReadout(model.lm_head.weight,norm.weight,norm.variance_epsilon,model.lm_head.bias)
    pool=[]
    with torch.no_grad(),sdpa_kernel(SDPBackend.MATH):
        for index,row in enumerate(joined):
            result=args.out/f"row_{index:04d}.pt"
            if result.exists():
                item=load(result)
                if item["id"]!=row["id"] or item["lock_sha256"]!=digest(lock):
                    raise ValueError("The held-out score and sample order differ")
            else:
                receiver=capture(model,token_ids(row,tokenizer))
                scales=write_scales(receiver.pre_loop,True)
                cache=head.bind(receiver.post_loop)
                def response(h):
                    return one_loop(model,receiver,h)
                held=[]
                direct=[]
                for group in directions.T.split(args.block):
                    tangents=scales[None,...]*group[:,None,None,:]
                    moved=vmap(lambda v:jvp(response,(receiver.pre_loop,),(v,))[1])(tangents)
                    held.append(variance(head,cache,moved).cpu())
                    direct.append(variance(head,cache,tangents).cpu())
                item=dict(id=row["id"],direct=torch.cat(direct),mediated=torch.cat(held),lock_sha256=digest(lock))
                if any(not item[k].isfinite().all().item() for k in ("direct","mediated")):
                    raise ValueError("Non-finite held-out Fisher response")
                save_pt(result,item)
            pool.append(item)
            if len(pool)%16==0: print("D2_AUDIT_ROWS",len(pool),len(joined),flush=True)
    save_pt(args.out/"HELDOUT_RAYLEIGH.pt",dict(spec,ids=[x["id"] for x in pool],n=len(pool),
           direct=torch.stack([x["direct"] for x in pool]),mediated=torch.stack([x["mediated"] for x in pool])))
    print("D2_HELDOUT_RAYLEIGH",args.shard,len(pool),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("audit","environment","spectrum-lock","subspaces","eigenvectors","model","out"):
        parser.add_argument(f"--{name}",type=Path,required=True)
    parser.add_argument("--model-sha256",required=True)
    parser.add_argument("--shard",type=int,required=True)
    parser.add_argument("--shards",type=int,default=3)
    parser.add_argument("--block",type=int,default=8)
    audit(parser.parse_args())


if __name__=="__main__":
    main()

