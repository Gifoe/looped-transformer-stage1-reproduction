"""Derive threshold-triggered, paired D2 diagnostics from frozen predictions."""

import argparse
import json
from pathlib import Path

from d1_stats import paired
from d2_worker import digest, save_json


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def prediction(path, entry, n):
    if digest(path)!=entry["sha256"]:
        raise ValueError(f"Frozen prediction digest mismatch: {path}")
    with path.open(encoding="utf-8") as records:
        rows=[json.loads(line) for line in records if line.strip()]
    if len(rows)!=n or entry["rows"]!=n or len({row["id"] for row in rows})!=n:
        raise ValueError(f"Incorrect paired population size: {path}")
    return rows


def close(work,e0):
    zero_path=work/"D2_ZERO_LABEL_EVAL.json"
    sample_path=work/"D2_SAMPLE_EFFICIENCY.json"
    zero=read(zero_path)
    sample=read(sample_path)
    delta=zero["arms"]["U1_PMI"]["external_pp_vs_native"]
    candidates={
        "arc_challenge_validation":("historical","arc_challenge__candidate",299,("acc","acc_norm")),
        "sciq_validation":(None,"sciq_val",500,("acc","acc_norm")),
        "mmlu_development":(None,"mmlu_val",658,("acc",)),
    }
    rows={}
    if delta>=2.0:
        native=e0/"e0_external_dev"/"native"
        controlled=work/"no_label_dev"/"U1_PMI"
        for key,(panel,topic,n,metrics) in candidates.items():
            paired_values=[]
            identities=[]
            for directory in (native,controlled):
                dev=read(directory/"DEVELOPMENT.json")
                section=dev[panel] if panel else dev
                record=section["predictions"][topic]
                archive=directory/panel if panel else directory
                paired_values.append(prediction(archive/f"{topic}.jsonl",record,n))
                identities.append(record["sha256"])
            before,after=paired_values
            if any((x["id"],x["gold"])!=(y["id"],y["gold"]) for x,y in zip(before,after,strict=True)):
                raise ValueError(f"U1 and Native predictions were not paired for {key}")
            rows[key]=dict(sha256=identities,metrics={
                metric:paired([r["metrics"][metric] for r in before],[r["metrics"][metric] for r in after])
                for metric in metrics})
    efficiency={}
    for method,points in sample["matched_cold_sample_ratio"].items():
        supported=[point for point in points if point["ratio"] is not None]
        censored=[point for point in points if point["ratio"] is None]
        efficiency[method]={
            str(rate):dict(achieved_at=[p["n"] for p in supported if p["ratio"]>=rate],
                           exceeds_at_least_at=[p["n"] for p in censored if p["lower_bound"]>=rate],
                           unconfirmed_at=[p["n"] for p in censored if p["lower_bound"]<rate])
            for rate in (2,4,8)}
    save_json(work/"D2_FOLLOWUP_DETAIL.json",dict(
        files_sha256={p.name:digest(p) for p in (zero_path,sample_path)},
        u1_threshold_pp=2.0,u1_external_delta_pp=delta,threshold_met=delta>=2.0,
        threshold_development_cohorts=rows,sample_saving_multiple=efficiency,
        sample_saving_scope="observed mean score on a discrete matched training grid; censored if cold never reached it"))
    print("D2_FOLLOWUP_DETAIL_CLOSED",flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work",required=True,type=Path)
    parser.add_argument("--e0",required=True,type=Path)
    values=parser.parse_args()
    close(values.work,values.e0)
