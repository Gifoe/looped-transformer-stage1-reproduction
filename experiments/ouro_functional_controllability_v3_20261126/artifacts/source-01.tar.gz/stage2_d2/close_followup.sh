#!/usr/bin/env bash
set -euo pipefail
study=$(cd "$(dirname "$0")/.." && pwd)
cd /root/ouro-external-data-joint-training-20261124
source external_env.sh
cd "$study"
d2_close_dir="$study/stage2_d2"
export OPENBLAS_NUM_THREADS=4 OMP_NUM_THREADS=4
export PYTHONPATH="$d2_close_dir:$study/stage1_e0/code:$study/stage3_d1:$study/tools:/root/ouro-loop-aware-functional-identification-20261125:$PYTHONPATH"
exec 8>"$study/locks/d2_finalize.lock"
flock 8
"$py" - "$study" <<'D2_VALIDATE'
import json
from pathlib import Path
import sys
from gpu_dispatch import canonical_hash, digest, within

root=Path(sys.argv[1]).resolve()
work=root/"stage2_d2"
previous=work/"DOWNSTREAM_FROZEN_EVALUATION.json"
current=work/"DOWNSTREAM_FROZEN_EVALUATION_RECOVERY.json"
repair=json.loads((work/"D2_SAMPLE_RECOVERY.json").read_text())
if repair["original_manifest_sha256"]!=digest(previous) or repair["replacement_manifest_sha256"]!=digest(current):
    raise ValueError("The D2 recovery receipt no longer matches its protected manifests")
manifest=json.loads(current.read_text())
old=json.loads(previous.read_text())
changed=0
for before,after in zip(old["jobs"],manifest["jobs"],strict=True):
    if before==after:
        continue
    pin=repair["corrected_training_module"]
    if (not before["job_id"].startswith("d2.sample.") or
        before["input_sha256"].get(pin)!=repair["prior_runner_sha256"] or
        after!=dict(before,input_sha256=dict(before["input_sha256"],**{pin:repair["replacement_runner_sha256"]}))):
        raise ValueError("Recovery may correct only the input runner hash for each supervised job")
    changed+=1
if changed!=105:
    raise ValueError("The repaired manifest must preserve all 105 supervised arms")
jobs=manifest["jobs"]
groups={"rayleigh":3,"no_label":8,"sample":105}
for group,count in groups.items():
    if sum(job["job_id"].startswith(f"d2.{group}.") for job in jobs)!=count:
        raise ValueError(f"D2 manifest is incomplete for {group}")
if len(jobs)!=116 or len({x["job_id"] for x in jobs})!=116:
    raise ValueError("D2 follow-up job list is not complete and unique")
for job in jobs:
    marker=within(root,job["done_marker"])
    receipt=json.loads(marker.read_text())
    if (receipt["job_id"]!=job["job_id"] or receipt["config_sha256"]!=canonical_hash(job)
        or receipt["logical_gpu"]!=job["preferred_gpu"]
        or set(receipt["artifact_sha256"])!=set(job["artifacts"])):
        raise ValueError(f"D2 worker receipt does not bind its locked job: {marker}")
    for filename,expected in receipt["artifact_sha256"].items():
        path=within(root,filename)
        if digest(path)!=expected:
            raise ValueError(f"Completed D2 artifact changed: {path}")
        if path.name!="DEVELOPMENT.json":
            continue
        document=json.loads(path.read_text())
        panels=[(path.parent,document["predictions"])]
        if "historical" in document:
            panels.append((path.parent/"historical",document["historical"]["predictions"]))
        for directory,predictions in panels:
            for task,prediction in predictions.items():
                output=within(root,str(directory/f"{task}.jsonl"))
                sidecar=json.loads(output.with_suffix(".receipt.json").read_text())
                if (sidecar["predictions"]!=prediction or digest(output)!=prediction["sha256"]):
                    raise ValueError(f"D2 development predictions changed: {output}")
print("D2_RECEIPT_VALIDATION_COMPLETE",len(jobs),flush=True)
D2_VALIDATE
if test -s "$d2_close_dir/D2_VERDICT.json" && test -s "$d2_close_dir/D2_REPORT.md"; then
    "$py" - "$d2_close_dir" <<'D2_REUSE'
from pathlib import Path
import json,sys
from gpu_dispatch import digest
work=Path(sys.argv[1])
verdict=json.loads((work/"D2_VERDICT.json").read_text())
for name,identity in verdict["files_sha256"].items():
    if digest(work/name)!=identity:
        raise ValueError(f"Already closed D2 references changed: {name}")
D2_REUSE
    echo D2_VERDICT_REUSED
    exit 0
fi
"$py" -u "$d2_close_dir/d2_audit_report.py" --work "$d2_close_dir" --phase rayleigh --audit "$study/stage0_env/UNLABELED_CORPUS/audit_unlabeled.jsonl"
"$py" -u "$d2_close_dir/d2_audit_report.py" --work "$d2_close_dir" --phase score --e0 "$study/stage1_e0"
"$py" -u "$d2_close_dir/d2_score_pairing.py" --work "$d2_close_dir" --e0 "$study/stage1_e0"
"$py" -u "$d2_close_dir/audit_pmi_generation.py"
"$py" -u "$d2_close_dir/audit_matched_write.py"
"$py" -u "$d2_close_dir/d2_audit_report.py" --work "$d2_close_dir" --phase sample --e0 "$study/stage1_e0"
"$py" -u "$d2_close_dir/d2_followup_detail.py" --work "$d2_close_dir" --e0 "$study/stage1_e0"
"$py" -u "$d2_close_dir/d2_finish.py" --root "$d2_close_dir"
test -s "$d2_close_dir/D2_REPORT.md"
