"""Generalized subspace iteration with a full-space Ritz residual audit."""

from dataclasses import dataclass

import torch


@dataclass
class Spectrum:
    values: torch.Tensor
    eigenvectors: torch.Tensor
    orthonormal_basis: torch.Tensor
    residuals: torch.Tensor
    cg_iterations: tuple[int, ...]


def block_cg(apply, targets, tolerance=1e-6, max_steps=96):
    """Solve independent positive-definite systems in shared matrix batches."""
    guess = torch.zeros_like(targets)
    residual = targets.clone()
    direction = residual.clone()
    squared = residual.square().sum(dim=0)
    threshold = squared * tolerance ** 2
    tiny = torch.finfo(targets.dtype).tiny

    for iteration in range(max_steps):
        active = squared > threshold
        if not active.any():
            return guess, iteration
        direction = direction * active
        transformed = apply(direction)
        curvature = (direction * transformed).sum(dim=0)
        if (curvature[active] <= 0).any():
            raise ValueError("The generalized normalizer did not have positive curvature")
        step = torch.where(active, squared / curvature.clamp_min(tiny), 0.0)
        guess = guess + direction * step
        residual = residual - transformed * step
        updated = residual.square().sum(dim=0)
        ratio = torch.where(active, updated / squared.clamp_min(tiny), 0.0)
        direction = residual + direction * ratio
        squared = updated
    if (squared > threshold).any():
        residual_ratio = (squared / targets.square().sum(dim=0).clamp_min(tiny)).sqrt()
        raise RuntimeError(f"The regularized solve did not converge: max residual {residual_ratio.max().item():.3g}")
    return guess, max_steps


def symmetrize(matrix):
    return (matrix + matrix.mT) / 2


def ritz(basis, a_basis, b_basis, rank):
    projected_a = symmetrize(basis.mT @ a_basis)
    projected_b = symmetrize(basis.mT @ b_basis)
    lower = torch.linalg.cholesky(projected_b)
    left_whitened = torch.linalg.solve_triangular(lower, projected_a, upper=False)
    whitened = torch.linalg.solve_triangular(lower, left_whitened.mT, upper=False).mT
    eigenvalues, eigenvectors = torch.linalg.eigh(symmetrize(whitened))
    indices = torch.arange(len(eigenvalues) - 1, len(eigenvalues) - rank - 1, -1, device=eigenvalues.device)
    values = eigenvalues[indices]
    coordinates = torch.linalg.solve_triangular(lower.mT, eigenvectors[:, indices], upper=True)
    left = a_basis @ coordinates
    right = (b_basis @ coordinates) * values
    denominator = (left.norm(dim=0) + right.norm(dim=0)).clamp_min(torch.finfo(basis.dtype).tiny)
    residual = (left - right).norm(dim=0) / denominator
    axes = basis @ coordinates
    return values, axes, residual


def orthogonal_extension(block, basis, limit):
    """Reorthogonalize against existing Krylov directions and drop numerical duplicates."""
    if basis is not None:
        for _ in range(2):
            block = block - basis @ (basis.mT @ block)
    left, singular, _ = torch.linalg.svd(block, full_matrices=False)
    threshold = max(float(singular.max()) * 1e-9, 1e-12)
    size = min(int((singular > threshold).sum()), limit)
    return left[:, :size]


def spectrum_family(loop, direct, width, trace_direct, gammas, rank=32, oversampling=16, iterations=6,
                    seed=26112620, cg_tolerance=1e-6, residual_tolerance=1e-3, refinement=6,
                    normalizer_matrix=None):
    if (trace_direct <= 0 or not 0 < rank <= width or iterations < 1 or refinement < 0
            or not gammas or min(gammas) <= 0 or len(set(gammas)) != len(gammas)):
        raise ValueError("Invalid generalized Fisher regularization or iteration budget")
    scales = {gamma: gamma * trace_direct / width for gamma in gammas}
    chol = {}
    if normalizer_matrix is not None:
        if normalizer_matrix.shape != (width, width) or not normalizer_matrix.isfinite().all():
            raise ValueError("Invalid exact dense direct Fisher normalizer")
        normalizer_matrix = symmetrize(normalizer_matrix)
        identity = torch.eye(width, dtype=normalizer_matrix.dtype, device=normalizer_matrix.device)
        for gamma, scale in scales.items():
            chol[gamma] = torch.linalg.cholesky(normalizer_matrix + scale * identity)

    def solve(gamma, rhs):
        if gamma not in chol:
            return block_cg(lambda x: direct(x) + scales[gamma]*x, rhs, tolerance=cg_tolerance)
        answer = torch.cholesky_solve(rhs, chol[gamma])
        residual = (direct(answer) + scales[gamma]*answer - rhs).norm(dim=0)
        relative = residual / rhs.norm(dim=0).clamp_min(torch.finfo(rhs.dtype).tiny)
        if float(relative.max()) > cg_tolerance:
            raise RuntimeError("Cholesky solve violates the declared relative residual")
        return answer, 0
    generator = torch.Generator().manual_seed(seed)
    initial = torch.randn(width, min(width, rank + oversampling), generator=generator, dtype=torch.float64)
    next_block = torch.linalg.qr(initial, mode="reduced").Q
    solves = []
    basis = loop_basis = direct_basis = None
    results = {}
    for step in range(iterations + refinement):
        pushed = loop(next_block)
        normalizer_block = direct(next_block)
        if basis is None:
            basis, loop_basis, direct_basis = next_block, pushed, normalizer_block
        else:
            basis = torch.cat((basis, next_block), dim=1)
            loop_basis = torch.cat((loop_basis, pushed), dim=1)
            direct_basis = torch.cat((direct_basis, normalizer_block), dim=1)
        results = {gamma: ritz(basis, loop_basis, direct_basis + scale * basis, rank)
                   for gamma, scale in scales.items()}
        unresolved = {gamma: parts for gamma, parts in results.items()
                      if float(parts[2].max()) > residual_tolerance}
        print("GENERALIZED_RITZ_RESIDUALS", step+1, basis.shape[1],
              {gamma: float(parts[2].max()) for gamma,parts in results.items()}, flush=True)
        if not unresolved:
            return {gamma: Spectrum(values, axes, torch.linalg.qr(axes, mode="reduced").Q,
                                    residuals, tuple(solves))
                    for gamma, (values, axes, residuals) in results.items()}
        if basis.shape[1] >= width or step + 1 == iterations + refinement:
            break

        if step + 1 < iterations:
            gamma = next(iter(unresolved))
            pulled, count = solve(gamma, pushed)
            solves.append(count)
        else:
            refinements = []
            for gamma, (values, axes, residuals) in unresolved.items():
                projected_axes = basis.mT @ axes
                normalizer = direct_basis + scales[gamma]*basis
                error = loop_basis @ projected_axes - (normalizer @ projected_axes) * values
                active = error[:, residuals > residual_tolerance]
                block, count = solve(gamma, active)
                solves.append(count)
                refinements.append(block)
            if len(refinements) > 1:
                # Ritz residuals are checked per ridge value. Balance their correction
                # blocks before the shared width truncation so one inverse scale cannot
                # consume an unrelated ridge's directions.
                block_norms = [part.norm() for part in refinements]
                refinements = [part / norm.clamp_min(torch.finfo(part.dtype).tiny)
                               for part, norm in zip(refinements, block_norms, strict=True)]
                print("SHARED_RITZ_REFINEMENT_BLOCKS", step+1,
                      {gamma:float(norm) for gamma,norm in zip(unresolved,block_norms,strict=True)}, flush=True)
            pulled = torch.cat(refinements, dim=1)
        capacity = min(width-basis.shape[1], rank+oversampling)
        next_block = orthogonal_extension(pulled, basis, capacity)
        if not next_block.shape[1]:
            break
    summary = {gamma: float(parts[2].max()) for gamma, parts in results.items()}
    raise RuntimeError(f"Uncertified generalized Fisher spectrum: max residuals {summary}")


def spectrum(loop, direct, width, trace_direct, gamma, **kwargs):
    return spectrum_family(loop, direct, width, trace_direct, (gamma,), **kwargs)[gamma]
