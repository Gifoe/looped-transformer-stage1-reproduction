"""GPU worker for sharded, frozen no-label Fisher-Rao measurements."""

import argparse
from hashlib import file_digest, sha256
import json
from pathlib import Path
import time

import torch
from torch.nn.attention import SDPBackend, sdpa_kernel
from transformers import AutoModelForCausalLM, AutoTokenizer
import transformers

from d2_direct import DirectFisher
from d2_block import RMSFisherReadout, fisher_blocks
from d2_operator import Boundary, capture, compression_product, fisher_matvec, one_loop, readout, write_scales


def digest(path):
    with path.open("rb") as data:
        return file_digest(data, "sha256").hexdigest()


def save_pt(path, obj):
    stage = path.with_suffix(".partial")
    torch.save(obj, stage)
    stage.replace(path)


def save_json(path, obj):
    stage = path.with_suffix(".partial")
    stage.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    stage.replace(path)


def load(path):
    return torch.load(path, map_location="cpu", weights_only=True)


def model_load(args):
    if digest(args.model / "model.safetensors") != args.model_sha256:
        raise ValueError("The native checkpoint differs from the serialized model lock")
    transformers.utils.import_utils._torchvision_available = False
    tok = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True, local_files_only=True)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, trust_remote_code=True, local_files_only=True,
        torch_dtype=torch.float32, attn_implementation="sdpa",
    ).to("cuda").requires_grad_(False).eval()
    return model, tok


def parse_rows(path):
    with path.open(encoding="utf-8") as stream:
        rows = [json.loads(line) for line in stream if line.strip()]
    seen = set()
    for row in rows:
        if set(row) & {"gold", "answer", "answers", "label", "target", "choices"}:
            raise ValueError("Only unlabelled continuous-text examples are permitted")
        raw_id = row.get("id", row.get("sample_id"))
        if raw_id is None or ("id" in row and "sample_id" in row and str(row["id"]) != str(row["sample_id"])):
            raise ValueError("The text source needs one unambiguous stable ID")
        key = str(raw_id)
        if not key or key in seen:
            raise ValueError(f"Missing or duplicate unlabelled row ID: {key}")
        row["id"] = key
        seen.add(key)
    return rows


def token_ids(row, tok):
    ids = row.get("input_ids")
    if ids is None:
        ids = tok.encode(row["text"], add_special_tokens=False)
    if len(ids) not in range(256, 385):
        raise ValueError(f"Unexpected unlabelled passage length: {row['id']} ({len(ids)})")
    return torch.tensor([ids], dtype=torch.long, device="cuda")


def states_for(args, model, tok, rows):
    cache = args.out / "states"
    cache.mkdir(exist_ok=True)
    states = []
    for start in range(0, len(rows), args.chunk):
        file = cache / f"{start:05d}.pt"
        block = rows[start:start+args.chunk]
        ids = [str(row["id"]) for row in block]
        if file.exists():
            cached = load(file)
            if [item["id"] for item in cached] != ids:
                raise ValueError(f"State cache does not match the locked examples: {file}")
        else:
            cached = []
            for row, key in zip(block, ids, strict=True):
                state = capture(model, token_ids(row, tok))
                if start == 0 and not cached:
                    with torch.no_grad():
                        measured = one_loop(model, state, state.pre_loop)
                    torch.testing.assert_close(measured, state.post_loop, rtol=1e-5, atol=2e-5)
                cached.append(dict(id=key, pre=state.pre_loop.cpu(), post=state.post_loop.cpu(),
                                   rotary=[tensor.cpu() for tensor in state.rotary]))
            save_pt(file, cached)
        states.extend(cached)
        print("STATE_CAPTURE", len(states), len(rows), flush=True)
    return states


def move(item):
    pre, post = item["pre"].cuda(), item["post"].cuda()
    steps = torch.arange(pre.shape[-2], device=pre.device)
    positions = steps.unsqueeze(0)
    mask = (steps[:, None] >= steps[None, :])[None, None, :, :]
    rotary = tuple(tensor.cuda() for tensor in item["rotary"])
    return Boundary(pre, post, mask, positions, rotary)


def base_statistics(model, states, path):
    if path.exists():
        return
    norm = model.model.norm
    gain = norm.weight
    width = len(gain)
    direct = [DirectFisher(model.lm_head.weight, gain, norm.variance_epsilon, model.lm_head.bias) for _ in range(2)]
    filled = torch.zeros((width, width), dtype=torch.float64, device="cuda")
    mean = torch.zeros(width, dtype=torch.float64, device="cuda")
    n = 0
    for item in states:
        pre, post = item["pre"].cuda(), item["post"].cuda()
        direct[0].add(post, write_scales(pre, True))
        direct[1].add(post, write_scales(pre, False))
        flat = pre.reshape(-1, width)
        filled += (flat.mT @ flat).double()
        mean += flat.sum(dim=0, dtype=torch.float64)
        n += len(flat)
    save_pt(path, dict(direct_normalized=direct[0].matrix().cpu(),
                       direct_constant=direct[1].matrix().cpu(),
                       conduct_sum=mean.cpu(), conduct_moment=filled.cpu(),
                       n_positions=n, n_examples=len(states)))
    print("BASE_STATISTICS", len(states), n, digest(path), flush=True)


def normalized_positions(state, selected):
    if selected == 0:
        return None
    limit = state.pre_loop.shape[-2]
    return torch.linspace(limit // 5, limit - 1, selected, device="cuda").round().long()


def apply_request(args, model, records, request, progress, request_sha):
    selected = request.get("ids")
    if selected is not None:
        keys = set(selected)
        records = [row for row in records if row["id"] in keys]
    n = len(records)
    mode = request["kind"]
    if mode == "direct":
        norm = model.model.norm
        acc = DirectFisher(model.lm_head.weight, norm.weight, norm.variance_epsilon, model.lm_head.bias)
        for item in records:
            boundary = move(item)
            scales = write_scales(boundary.pre_loop, request["normalized"])
            positions = normalized_positions(boundary, request.get("selected_positions", 0))
            values = boundary.post_loop
            if positions is not None:
                values = values.index_select(-2, positions)
                scales = scales.index_select(-2, positions)
            acc.add(values, scales)
        width = len(norm.weight)
        total = acc.matrix().cpu() * n if n else torch.zeros((width, width), dtype=torch.float64)
        return dict(sum=total, n=n)
    matrix = request["vectors"]
    if matrix.ndim != 2:
        raise ValueError("Expect a matrix with one direction per column")
    total = torch.zeros_like(matrix, dtype=torch.float64)
    population_sha = sha256(json.dumps([row["id"] for row in records], ensure_ascii=False).encode()).hexdigest()
    completed = 0
    if progress.exists():
        cache = load(progress)
        if cache["request_sha256"] != request_sha or cache["population_sha256"] != population_sha:
            raise ValueError("An operator checkpoint belongs to a different request or corpus")
        completed = cache["completed"]
        total = cache["sum"]
        if not 0 <= completed <= n or total.shape != matrix.shape or not total.isfinite().all():
            raise ValueError("Invalid checkpoint for a partial operator sum")
    inputs = matrix.cuda().float()
    block_decode = None
    if args.direction_block > 1 and mode in {"loop", "isolation"}:
        norm = model.model.norm
        block_decode = RMSFisherReadout(model.lm_head.weight, norm.weight, norm.variance_epsilon, model.lm_head.bias)
    for index, item in enumerate(records[completed:], start=completed):
        boundary = move(item)
        scales = write_scales(boundary.pre_loop, request["normalized"])
        positions = normalized_positions(boundary, request.get("selected_positions", 0))

        def transform(state):
            return one_loop(model, boundary, state)

        def decode(state):
            return readout(model, state)

        if mode == "compression":
            basis = request["basis"].cuda().float()
            for j, vector in enumerate(inputs.unbind(1)):
                total[:, j] += compression_product(transform, boundary.pre_loop, scales, basis, vector).cpu().double()
        elif mode == "loop":
            if block_decode is not None:
                total += fisher_blocks(transform, block_decode, boundary.pre_loop, scales, inputs,
                                       positions, args.direction_block, args.head_chunk).cpu().double()
            else:
                for j, vector in enumerate(inputs.unbind(1)):
                    total[:, j] += fisher_matvec(transform, decode, boundary.pre_loop, scales, vector,
                                               positions, args.head_chunk).cpu().double()
        elif mode == "isolation":
            if positions is None:
                raise ValueError("The isolation request omitted its matched positions")
            all_positions = torch.arange(boundary.pre_loop.shape[-2], device="cuda")
            for pos in positions:
                keep = (all_positions == pos)[None, :, None]
                if block_decode is not None:
                    values = fisher_blocks(transform, block_decode, boundary.pre_loop, scales*keep, inputs,
                                           pos.reshape(1), args.direction_block, args.head_chunk)
                    total += values.cpu().double() / len(positions)
                else:
                    for j, vector in enumerate(inputs.unbind(1)):
                        value = fisher_matvec(transform, decode, boundary.pre_loop, scales * keep, vector,
                                              pos.reshape(1), args.head_chunk)
                        total[:, j] += value.cpu().double() / len(positions)
        else:
            raise ValueError(f"Unknown derivative request: {mode}")
        if index % 8 == 7 or index + 1 == n:
            save_pt(progress, dict(request_sha256=request_sha, population_sha256=population_sha,
                                   completed=index+1, sum=total))
            print("OPERATOR_PROGRESS", mode, index+1, n, flush=True)
    return dict(sum=total, n=n)


def run(args):
    if args.nshards < 1 or not 0 <= args.shard < args.nshards:
        raise ValueError("Invalid corpus shard")
    args.out.mkdir(parents=True, exist_ok=True)
    inbox = args.out / "inbox"
    results = args.out / "results"
    partials = args.out / "operator_checkpoints"
    inbox.mkdir(exist_ok=True)
    results.mkdir(exist_ok=True)
    partials.mkdir(exist_ok=True)
    rows = parse_rows(args.fit)
    if len(rows) != 1024:
        raise ValueError(f"Expected a locked 1,024-passage corpus, found {len(rows)}")
    cohort = rows[args.shard::args.nshards]
    metadata = {key: str(value) for key, value in vars(args).items() if key != "prepare_only"}
    metadata["fit_sha256"] = digest(args.fit)
    metadata["code_sha256"] = digest(Path(__file__))
    metadata["derivative_sha256"] = digest(Path(__file__).with_name("d2_operator.py"))
    metadata["direct_sha256"] = digest(Path(__file__).with_name("d2_direct.py"))
    metadata["block_sha256"] = digest(Path(__file__).with_name("d2_block.py"))
    lock = args.out / "WORKER_LOCK.json"
    if lock.exists() and json.loads(lock.read_text()) != metadata:
        raise ValueError("Changing configuration would invalidate existing derivative jobs")
    save_json(lock, metadata)
    torch.set_num_threads(4)
    torch.manual_seed(26112620)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    model, tok = model_load(args)
    with sdpa_kernel(SDPBackend.MATH):
        records = states_for(args, model, tok, cohort)
        direct = args.out / "DIRECT_FISHER.pt"
        base_statistics(model, records, direct)
        save_json(args.out / "READY.json", dict(corpus=metadata["fit_sha256"], n=len(records),
                                               direct_sha256=digest(direct), lock_sha256=digest(lock)))
        print("READY", args.shard, len(records), flush=True)
        if args.prepare_only:
            return
        while not (inbox / "STOP").exists():
            available = [path for path in sorted(inbox.glob("*.pt")) if not (results / path.name).exists()]
            if not available:
                time.sleep(2)
                continue
            for path in available:
                request = load(path)
                request_sha = digest(path)
                result = apply_request(args, model, records, request, partials/path.name, request_sha)
                result["request_sha256"] = request_sha
                save_pt(results / path.name, result)
                print("WROTE", path.name, result["n"], flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--model-sha256", required=True)
    parser.add_argument("--fit", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--shard", type=int, required=True)
    parser.add_argument("--nshards", type=int, default=3)
    parser.add_argument("--chunk", type=int, default=8)
    parser.add_argument("--head-chunk", type=int, default=32)
    parser.add_argument("--direction-block", type=int, default=1)
    parser.add_argument("--prepare-only", action="store_true")
    run(parser.parse_args())


if __name__ == "__main__":
    main()

