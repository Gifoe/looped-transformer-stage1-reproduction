#!/usr/bin/env bash
set -euo pipefail
root=/root/ouro-v3-controllability-20261126
cd /root/ouro-external-data-joint-training-20261124
source external_env.sh
cd "$root"
export OPENBLAS_NUM_THREADS=4 OMP_NUM_THREADS=4
export PYTHONPATH="$root/stage2_d2:$root/stage1_e0/code:$root/tools:/root/ouro-loop-aware-functional-identification-20261125:$PYTHONPATH"
work="$root/stage2_d2"
o="$work/orientation"
"$py" - "$work" <<'CHECK_ORIENT'
from pathlib import Path
import json,sys
from d2_worker import digest
from gpu_dispatch import canonical_hash
w=Path(sys.argv[1])
pack=json.loads((w/"DOWNSTREAM_orientation.json").read_text())
assert len(pack["jobs"])==8
for job in pack["jobs"]:
    marker=json.loads(Path(job["done_marker"]).read_text())
    if canonical_hash(job)!=marker["config_sha256"] or set(marker["artifact_sha256"])!=set(job["artifacts"]):
        raise ValueError("Orientation run did not use the frozen no-label data")
    for name,sha in marker["artifact_sha256"].items():
        if digest(Path(name))!=sha: raise ValueError(f"Archived orientation changed: {name}")
CHECK_ORIENT
"$py" -u "$work/d2_freeze.py" --subspaces "$work/spectral/FISHER_SUBSPACES.pt"     --orientations "$o/pmi_0.1_rank16" "$o/pmi_0.3_rank16" "$o/pmi_1.0_rank16" "$o/nll_0.3_rank16" "$o/entropy_0.3_rank16"     --sensitivity "$o/pmi_0.3_rank8" "$o/pmi_0.3_rank32" --out "$work"
"$py" -u "$work/d2_audit_report.py" --work "$work" --phase baselines
"$py" -u "$work/d2_audit_report.py" --work "$work" --phase dynamics
"$py" -u "$work/d2_audit_report.py" --work "$work" --phase coverage      --t1 /root/ouro-functional-controllability-20261123/results/weights/rank1_t1.pt      --t1-sha256 91d4919308bf9060ce0c44e4046e4851e7e59f65b9692c77045535f96534efd2

