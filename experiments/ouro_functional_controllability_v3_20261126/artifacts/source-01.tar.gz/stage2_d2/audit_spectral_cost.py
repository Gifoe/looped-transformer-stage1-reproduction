"""Seal observed per-device timing for the custom D2 Fisher operator dispatcher."""
import argparse
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import json

from d2_worker import digest, load, save_json


def stamp(t):
    return datetime.fromtimestamp(t,tz=timezone.utc).isoformat()


def for_card(stage,logical,physical):
    home=stage/"exchange"/f"gpu_{logical}"
    inbox=home/"inbox"
    finished=home/"results"
    rows=[]
    gauge=stage/"logs"/f"D2_GPU_{logical}_OBSERVED.tsv"
    if gauge.is_file():
        with gauge.open(encoding="utf-8") as records:
            labels=records.readline().strip().split("\t")
            for line in records:
                raw=dict(zip(labels,line.strip().split("\t"),strict=True))
                rows.append((datetime.fromisoformat(raw["utc"]).timestamp(),int(raw["memory_used_mib"]),
                             int(raw["util_percent"])))
    summary=[]
    for result in sorted(finished.glob("*.pt")):
        request=inbox/result.name
        started=request.stat().st_mtime
        ended=result.stat().st_mtime
        wire=digest(request)
        data=load(request)
        answer=load(result)
        if wire!=answer["request_sha256"] or result.stem!=f"{data['kind']}_{wire}" or ended<started:
            raise ValueError(f"Local Fisher transport record violated immutability at {result}")
        costs=[(mem,util) for timestamp,mem,util in rows if started<=timestamp<=ended]
        item= dict(kind=data["kind"],logical_slot=logical,physical_card=physical,
                   normalization=data["normalized"],request_sha256=wire,result_sha256=digest(result),
                   rows=answer["n"],directions=int(data["vectors"].shape[1]) if "vectors" in data else None,
                   incidence_time_utc=stamp(started),completed_utc=stamp(ended),
                   request_to_result_wall_seconds=ended-started,sensor_readings=len(costs),
                   sampled_peak_mib=max((mem for mem,_ in costs),default=None),
                   sampled_peak_gpu_utilization=max((util for _,util in costs),default=None))
        summary.append(item)
    if len(summary)!=29:
        raise ValueError(f"Expected 29 independent sealed D2 operator calls; found {len(summary)}")
    counts=Counter(row["kind"] for row in summary)
    if counts!=dict(direct=1,loop=21,isolation=6,compression=1):
        raise ValueError(f"Unexpected operator family counts: {counts}")
    return dict(logical_card=logical,physical_card=physical,request_count=len(summary),
                response_seconds_sum=sum(x["request_to_result_wall_seconds"] for x in summary),
                telemetry_sha256=digest(gauge) if gauge.is_file() else None,artifacts=summary)


def main(args):
    spectral=args.stage/"spectral/D2_SPECTRAL_AUDIT.json"
    if len(json.loads(spectral.read_text())["results"])!=6:
        raise ValueError("The D2 spectral stage has not closed")
    devices=[(0,0)] if args.host=="old" else [(1,0),(2,1)]
    total=dict(host=args.host,spectral_audit_sha256=digest(spectral),
               measurement="Local request arrival to atomic result write. Includes transport handoff and any local queueing. Sampled power statistics are incomplete for early calls.",
               slots=[for_card(args.stage,gpu,local) for gpu,local in devices])
    path=args.stage/f"D2_SPECTRAL_DEVICE_COST_{args.host}.json"
    save_json(path,total)
    print("D2_SPECTRAL_MEASURED_COST",args.host,digest(path),
         {x["logical_card"]:round(x["response_seconds_sum"]/3600,3) for x in total["slots"]},flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage",type=Path,required=True)
    parser.add_argument("--host",required=True,choices=("old","dual"))
    main(parser.parse_args())
