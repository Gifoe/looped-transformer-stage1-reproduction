"""Learn a no-task-label Rank-1 direction inside a frozen Fisher write subspace."""

import argparse
from hashlib import sha256
from pathlib import Path

import torch
from torch import nn
from transformers import AutoModelForCausalLM, AutoTokenizer
import transformers

from d2_worker import digest, load, parse_rows, save_json, save_pt


class RankOne(nn.Module):
    def __init__(self, basis, seed, cap=0.45):
        super().__init__()
        self.register_buffer("basis", basis.float())
        generator = torch.Generator().manual_seed(seed)
        axis = torch.randn(basis.shape[1], generator=generator)
        self.axis = nn.Parameter(axis / axis.norm())
        read = torch.randn(basis.shape[0], generator=generator)
        self.read = nn.Parameter(.02 * read / read.norm())
        self.cap = cap

    def write(self):
        return self.basis @ self.axis

    def inject(self, hidden, predict):
        work = hidden.float()
        intended = (work @ self.read)[..., None] * self.write()
        source_norm = work.norm(dim=-1, keepdim=True)
        update_norm = intended.norm(dim=-1, keepdim=True).clamp_min(1e-12)
        scale = (self.cap * source_norm / update_norm).clamp(max=1.0)
        return (work + intended * scale * predict[..., None]).to(hidden.dtype)

    @torch.no_grad()
    def keep_scale(self):
        norm = self.axis.norm() * self.read.norm()
        self.read.mul_((4.5 / norm.clamp_min(1e-12)).clamp(max=1.0))


def tokens(source, tokenizer):
    ids = source.get("input_ids")
    if ids is None:
        ids = tokenizer.encode(source["text"], add_special_tokens=False)
    if not 256 <= len(ids) <= 384:
        raise ValueError(f"Unexpected source token count for {source['id']}")
    return ids


def split_corpus(path, tokenizer):
    items = []
    for row in parse_rows(path):
        ids = tokens(row, tokenizer)
        boundary = 3 * len(ids) // 4
        items.append((str(row["id"]), str(row.get("document_id", row["id"])), ids[:boundary], ids[boundary:]))
    return items


def alternate_contexts(rows, seed):
    order = sorted(range(len(rows)), key=lambda i: sha256(f"{seed}:{rows[i][0]}".encode()).hexdigest())
    shuffled = {}
    for start, position in enumerate(order):
        for offset in range(1, len(order)):
            choice = order[(start+offset) % len(order)]
            if rows[position][1] != rows[choice][1] and rows[position][2] != rows[choice][2]:
                shuffled[position] = rows[choice][2]
                break
        else:
            raise ValueError("The text corpus has no valid distinct alternate contexts")
    return shuffled


def log_probabilities_batch(model, contexts, suffixes, net=None):
    core = model.model
    context_length = len(contexts[0])
    width = context_length + len(suffixes[0])
    if not all(len(context)==context_length and len(context)+len(suffix)==width
               for context,suffix in zip(contexts,suffixes,strict=True)):
        raise ValueError("An unpadded batch needs matching context and continuation lengths")
    device = next(core.parameters()).device
    ids = torch.tensor([context + suffix for context,suffix in zip(contexts,suffixes,strict=True)],
                       dtype=torch.long, device=device)
    positions = torch.arange(context_length-1, width-1, device=device)
    targets = ids[:, positions+1]
    mask = torch.zeros_like(ids, dtype=torch.bool)
    mask[:, positions] = True
    counter = 0

    def receive(_, args):
        nonlocal counter
        counter += 1
        if counter == 3:
            return (net.inject(args[0], mask), *args[1:])
        return None

    handle = core.norm.register_forward_pre_hook(receive) if net is not None else None
    try:
        out, all_states, _ = core(input_ids=ids, use_cache=False)
    finally:
        if handle is not None:
            handle.remove()
    if len(all_states) != 4 or (net is not None and counter != 4):
        raise ValueError("The frozen output did not traverse the four-step recurrent path")
    logits = model.lm_head(out.last_hidden_state[:, positions])
    return logits.float().log_softmax(-1), targets


def expected_terms_batch(model, real, swapped, suffix, net, needs_pmi):
    with torch.no_grad():
        base, _ = log_probabilities_batch(model, real, suffix)
        if needs_pmi:
            null, _ = log_probabilities_batch(model, swapped, suffix)
    active, gold = log_probabilities_batch(model, real, suffix, net)
    picked = active.gather(-1, gold[...,None]).squeeze(-1).mean(-1)
    selected_base = base.gather(-1, gold[...,None]).squeeze(-1).mean(-1)
    probability = active.exp()
    kl = (probability * (active - base)).sum(-1).mean(-1)
    entropy = -(probability * active).sum(-1).mean(-1)
    pmi = torch.zeros_like(picked)
    if needs_pmi:
        counterfactual, _ = log_probabilities_batch(model, swapped, suffix, net)
        contrast = (counterfactual - null).gather(-1, gold[...,None]).squeeze(-1).mean(-1)
        pmi = picked - selected_base - contrast
    return dict(nll=-picked, delta_nll=selected_base-picked, entropy=entropy, kl=kl, net_pmi=pmi)


def log_probabilities(model,context,suffix,net=None):
    """Preserve the one-context scoring interface for other study stages."""
    log_prob,targets=log_probabilities_batch(model,[context],[suffix],net)
    return log_prob[0],targets[0]


def expected_terms(model,real,swapped,suffix,net,needs_pmi):
    terms=expected_terms_batch(model,[real],[swapped],[suffix],net,needs_pmi)
    return {name:values[0] for name,values in terms.items()}


def same_lengths(corpus, alternate, indices, microbatch):
    """Group only untreated, equal-length sequences, without introducing attention padding."""
    groups={}
    for index in indices:
        _,_,real,suffix=corpus[index]
        swapped=alternate[index]
        groups.setdefault((len(real),len(swapped),len(suffix)),[]).append(
            (index,real,swapped,suffix))
    for triples in groups.values():
        for start in range(0,len(triples),microbatch):
            yield tuple(zip(*triples[start:start+microbatch],strict=True))


def train(args):
    train_microbatch=getattr(args,"train_microbatch",1)
    audit_microbatch=getattr(args,"audit_microbatch",1)
    if not 1<=train_microbatch<=args.effective_batch or not 1<=audit_microbatch<=8:
        raise ValueError("Unsupported inference microbatch")
    args.out.mkdir(parents=True, exist_ok=True)
    lock = args.out / "CONFIG.json"
    config = {name: str(value) for name, value in vars(args).items()}
    config.update(train_microbatch=str(train_microbatch),audit_microbatch=str(audit_microbatch))
    config["basis_sha256"] = digest(args.subspaces)
    config["fit_sha256"] = digest(args.fit)
    config["audit_sha256"] = digest(args.audit)
    if config["fit_sha256"] == config["audit_sha256"]:
        raise ValueError("Fit and audit must be independent text files")
    if digest(args.model / "model.safetensors") != args.model_sha256:
        raise ValueError("Frozen Base SHA-256 changed")
    if lock.exists():
        import json
        if json.loads(lock.read_text()) != config:
            raise ValueError("Orientation training arguments changed after freeze")
    save_json(lock, config)
    transformers.utils.import_utils._torchvision_available = False
    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True, local_files_only=True)
    model = AutoModelForCausalLM.from_pretrained(args.model, torch_dtype=torch.bfloat16,
                attn_implementation="sdpa", local_files_only=True, trust_remote_code=True).to("cuda").eval().requires_grad_(False)
    model.model.total_ut_steps = 4
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.manual_seed(args.seed)
    basis = load(args.subspaces)["U_FR"][:, :args.rank]
    fit = split_corpus(args.fit, tokenizer)
    valid = split_corpus(args.audit, tokenizer)
    if len(fit) != 1024 or len(valid) != 512 or {r[1] for r in fit} & {r[1] for r in valid}:
        raise ValueError("Source documents are incomplete or shared between fit and audit")
    alternate_fit = alternate_contexts(fit, args.seed)
    alternate_audit = alternate_contexts(valid, args.seed+1)
    net = RankOne(basis, args.seed).cuda()
    optim = torch.optim.AdamW(net.parameters(), lr=args.lr, weight_decay=.01)
    rng = torch.Generator().manual_seed(args.seed)
    order = torch.randperm(len(fit), generator=rng).tolist()
    if args.steps * args.effective_batch != len(fit):
        raise ValueError("The predeclared sweep must cover the fit set once")
    progress = args.out / "resume.pt"
    begin = 0
    if progress.exists():
        state = load(progress)
        if state["config_sha256"] != digest(lock):
            raise ValueError("Cannot reuse orientation state under a changed lock")
        net.load_state_dict(state["network"])
        optim.load_state_dict(state["optimizer"])
        begin = state["updates"]
        torch.cuda.synchronize()
    for step in range(begin, args.steps):
        optim.zero_grad(set_to_none=True)
        start = step * args.effective_batch
        logical_batch=order[start:start+args.effective_batch]
        for _,contexts,foils,suffixes in same_lengths(fit,alternate_fit,logical_batch,train_microbatch):
            use_pmi = args.objective == "pmi"
            signals = expected_terms_batch(model,contexts,foils,suffixes,net,use_pmi)
            task = -signals["net_pmi"] if use_pmi else signals[args.objective]
            loss = (task + args.beta * signals["kl"]).sum() / args.effective_batch
            loss.backward()
        norm = torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
        if not norm.isfinite().item():
            raise ValueError("Non-finite orientation optimizer step")
        optim.step()
        net.keep_scale()
        if step % 16 == 15 or step+1 == args.steps:
            save_pt(progress, dict(network=net.state_dict(), optimizer=optim.state_dict(), updates=step+1,
                                   config_sha256=digest(lock)))
            print("ORIENTATION_TRAIN", args.objective, args.beta, step+1, args.steps, flush=True)
    with torch.no_grad():
        by_index={}
        for ids,contexts,foils,suffixes in same_lengths(valid,alternate_audit,range(len(valid)),audit_microbatch):
            terms = expected_terms_batch(model,contexts,foils,suffixes,net,True)
            for row,index in enumerate(ids):
                by_index[index]=dict(id=valid[index][0], **{name: float(val[row]) for name,val in terms.items()})
        measured=[by_index[index] for index in range(len(valid))]
        u, w = net.write().cpu(), net.read.cpu()
    output = args.out / "controller.pt"
    save_pt(output, dict(form="rank1", state={"out.weight": u[:, None], "encode.weight": w[None, :]},
                         meta=dict(parameters=len(u)+len(w), source="unlabeled", objective=args.objective, cap=.45)))
    save_json(args.out / "AUDIT.json", dict(rows=measured, objective=args.objective, beta=args.beta,
        weights_sha256=digest(output), mean={name: sum(row[name] for row in measured) / len(measured)
                                             for name in measured[0] if name != "id"}))
    print("ORIENTATION_DONE", args.objective, args.beta, digest(output), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for label in ("model", "fit", "audit", "subspaces", "out"):
        parser.add_argument(f"--{label}", type=Path, required=True)
    parser.add_argument("--model-sha256", required=True)
    parser.add_argument("--objective", choices=("pmi", "nll", "entropy"), required=True)
    parser.add_argument("--beta", type=float, required=True)
    parser.add_argument("--rank", type=int, default=16)
    parser.add_argument("--steps", type=int, default=256)
    parser.add_argument("--effective-batch", type=int, default=4)
    parser.add_argument("--train-microbatch",type=int,default=1)
    parser.add_argument("--audit-microbatch",type=int,default=1)
    parser.add_argument("--lr", type=float, default=.001)
    parser.add_argument("--seed", type=int, default=26112624)
    train(parser.parse_args())


if __name__ == "__main__":
    main()
