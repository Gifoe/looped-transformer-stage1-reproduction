"""Verify the complete fixed primary development panel without waiting for the historical panel."""
import json
from pathlib import Path

import numpy as np

from d2_score_pairing import BASE_TASKS, binary, compare, macro_bootstrap, read, score_rows
from d2_worker import digest, save_json


study=Path.cwd()
work=study/"stage2_d2"
pin=work/"D2_SUBSPACE_LOCK.json"
freeze=read(pin)
name=f"{freeze['chosen']['objective']}_{freeze['chosen']['beta']}"
weight=freeze["sources"][name]["weight_sha256"]
experiment=work/"no_label_dev/U1_PMI"
control_files={}
controlled={}
for task in BASE_TASKS:
    receipt=experiment/f"{task}.receipt.json"
    record=read(receipt)
    identity=record["identity"]
    if identity["checkpoint_sha256"]!=weight or identity["arm"]!="U1_PMI":
        raise ValueError(f"External prediction file did not use the frozen PMI checkpoint: {task}")
    controlled[task]=score_rows(experiment,task,record["predictions"])
    control_files[task]=digest(receipt)
anchors={}
for arm in ("native","t1"):
    where=study/"stage1_e0/e0_external_dev"/arm
    stamp=read(where/"DEVELOPMENT.json")
    diffs=[]
    comparisons={}
    averages={}
    controls={}
    for task,metric in BASE_TASKS.items():
        ref=score_rows(where,task,stamp["predictions"][task])
        result,change=compare(controlled[task],ref,task,metric)
        diffs.append(change)
        comparisons[task]=result
        averages[task]=float(binary(ref,metric).mean())
        controls[task]=float(binary(controlled[task],metric).mean())
    anchors[arm]=dict(absolute_reference_macro=100*float(np.mean(list(averages.values()))),
                      absolute_pmi_macro=100*float(np.mean(list(controls.values()))),
                      paired_macro=macro_bootstrap(diffs,261126909),pairings=comparisons,
                      reference_task_accuracy=averages,pmi_task_accuracy=controls,
                      reference_score_sha256=digest(where/"DEVELOPMENT.json"))
out=work/"D2_U1_PRIMARY_PAIRED_AUDIT.json"
save_json(out,dict(arm="U1_PMI",external_development_only=True,historical_panel_required_separately=True,
                  lock_sha256=digest(pin),frozen_deployment_checkpoint_sha256=weight,
                  prediction_receipt_sha256=control_files,reference_analyses=anchors))
print("D2_U1_PRIMARY_PAIRED_AUDIT",digest(out),flush=True)
for arm,row in anchors.items():
    print(arm,row["absolute_pmi_macro"],row["absolute_reference_macro"],json.dumps(row["paired_macro"]),flush=True)
    print("MMLU-PRO",json.dumps(row["pairings"]["mmlu_pro_val"]["legal_transitions"]),flush=True)
