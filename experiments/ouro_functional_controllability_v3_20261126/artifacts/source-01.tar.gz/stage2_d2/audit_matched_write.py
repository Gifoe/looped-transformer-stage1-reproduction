"""Separate write-direction effects at the matched norm and read map of D2 U4."""
import json
from pathlib import Path

import torch

from d2_score_pairing import BASE_TASKS, compare, macro_bootstrap, read, score_rows
from d2_worker import digest,load,save_json


work=Path("stage2_d2")
names=("ufr1_mean","jacobian_right1","exit_gate","natural_displacement","random")
controls={}
observations={}
common_read=None
for arm in names:
    path=work/"baselines"/arm/"controller.pt"
    payload=load(path)
    u=payload["state"]["out.weight"].double().flatten()
    w=payload["state"]["encode.weight"].double().flatten()
    if common_read is None:
        common_read=w
    if not torch.equal(common_read,w) or abs(float(u.norm()*w.norm())-1)>1e-6:
        raise ValueError(f"U4 does not isolate a common read map at equal dose: {arm}")
    if payload["meta"]["cap"]!=.45:
        raise ValueError("The controls must use the same relative RMS limiter")
    controls[arm]=dict(checkpoint_sha256=digest(path),operator_spectral_norm=float(u.norm()*w.norm()),
                       output_axis_norm=float(u.norm()),read_axis_norm=float(w.norm()),cap=.45)
    folder=work/"no_label_dev"/arm
    summary=read(folder/"DEVELOPMENT.json")
    if summary["checkpoint_sha256"]!=controls[arm]["checkpoint_sha256"]:
        raise ValueError("U4 development predictions were produced with a different controller")
    observations[arm]={task:score_rows(folder,task,summary["predictions"][task]) for task in BASE_TASKS}
ref=observations["random"]
context={}
for arm in names[:-1]:
    diffs=[]
    result={}
    for task,key in BASE_TASKS.items():
        result[task],difference=compare(observations[arm][task],ref[task],task,key)
        diffs.append(difference)
    candidate=[delta for task,delta in zip(BASE_TASKS,diffs,strict=True) if task!="mmlu_pro_val"]
    context[arm]=dict(macro=macro_bootstrap(diffs,261126911),
                      fixed_input_candidate_only_macro=macro_bootstrap(candidate,261126911),tasks=result)
out=work/"D2_MATCHED_WRITE_DIRECTION.json"
save_json(out,dict(development_only=True,n_methods=len(names),reference="random",
                  source_paired_score_sha256=digest(work/"D2_ZERO_LABEL_PAIRED.json"),
                  checkpoint_evidence=controls,
                  causal_condition="The arms use identical read axes, write-vector norms, masks, and limiter. A shared input prefix yields the same pre-final-loop receiving state and relative RMS dose. Autoregressive prefixes can diverge after intervention; the candidate-only panel always uses fixed paired inputs.",
                  common_dose_formula="min(abs(w @ h) / norm(h), 0.45)",
                  paired_only_write_direction_changed=context))
print("D2_MATCHED_WRITE_DIRECTION",digest(out),flush=True)
for name,item in context.items():
    print(name,json.dumps(item["macro"]),json.dumps(item["fixed_input_candidate_only_macro"]),flush=True)
