from hashlib import file_digest
from pathlib import Path
import json
import numpy as np

stage=Path("stage2_d2")
data=stage/"transients"
def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream,"sha256").hexdigest()
def load(path):
    return json.loads(path.read_text())
report=load(data/"D2_TRANSIENT_AUDIT.json")
rows=[load(data/f"row_{r:03d}.json") for r in range(64)]
ids=[r["id"] for r in rows]
assert ids==report["chosen_ids"] and len(set(ids))==64
lock=digest(data/"TRANSIENT_LOCK.json")
assert all(r["protocol_sha256"]==lock for r in rows)
rng=np.random.default_rng(261126902)
draw=rng.integers(64,size=(10000,64))
time_points={}
for depth in range(4,9):
    key=str(depth)
    time_points[key]={}
    for measure in ("state_amplification","symmetric_dose_kl"):
        measured={label:np.array([entry["curves"][label][key][measure] for entry in rows]) for label in ("fisher","pca","random")}
        stats={}
        for control in ("pca","random"):
            margin=measured["fisher"]-measured[control]
            stats[control]=dict(mean_paired_delta=float(margin.mean()),n_fisher_larger=int((margin>0).sum()),
                                 mean_paired_delta_ci95=np.quantile(margin[draw].mean(axis=1),(.025,.975)).tolist())
        time_points[key][measure]=dict(pairing=stats,mean={n:float(v.mean()) for n,v in measured.items()},
                                      median={n:float(np.median(v)) for n,v in measured.items()})
path=stage/"D2_PHYSICAL_TRANSIENT_PAIRED_AUDIT.json"
output=dict(scope="Physical no-label perturbation in K4, traced through native K8 on held-out text",
            hypotheses_not_merged=["state amplification","Fisher sensitivity","nonnormality","application accuracy"],
            dose=report["dose"],n=64,transient_runner_receipt_sha256=digest(data/"D2_TRANSIENT_COMPLETE.json"),
            cohort_sha256={str(i):digest(data/f"row_{i:03d}.json") for i in range(64)},
            curves=time_points,internal_alignment=report["diagnostics"],bootstrap_replicates=10000)
temp=path.with_suffix(".partial")
temp.write_text(json.dumps(output,indent=2,sort_keys=True)+"\n")
temp.replace(path)
print("D2_PHYSICAL_PAIRED_AUDIT",digest(path))
print(json.dumps({k:{p:v["state_amplification"]["pairing"][p] for p in ("random","pca")}
                   for k,v in time_points.items()}))
