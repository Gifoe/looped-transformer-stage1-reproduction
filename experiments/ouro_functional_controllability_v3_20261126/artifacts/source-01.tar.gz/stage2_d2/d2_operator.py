"""Matrix-free Fisher-Rao derivatives at the Ouro recurrent boundary."""

from dataclasses import dataclass

import torch
from torch.func import jvp


@dataclass
class Boundary:
    pre_loop: torch.Tensor
    post_loop: torch.Tensor
    mask: torch.Tensor
    positions: torch.Tensor
    rotary: tuple[torch.Tensor, torch.Tensor]


def capture(model, tokens, depth=4):
    """Get the native states just before the two closing RMSNorm calls."""
    if tokens.ndim != 2 or tokens.shape[0] != 1:
        raise ValueError("Pass one unpadded token sequence to the derivative audit")
    core = model.model
    if core.has_sliding_layers:
        raise ValueError("This audit needs the matching native sliding mask for this revision")
    width = tokens.shape[1]
    steps = torch.arange(width, device=tokens.device)
    positions = steps.unsqueeze(0)
    mask = (steps[:, None] >= steps[None, :])[None, None, :, :]
    boundaries = []

    def remember(_layer, args):
        boundaries.append(args[0].detach())
        return None

    original_depth = core.total_ut_steps
    core.total_ut_steps = depth
    hook = core.norm.register_forward_pre_hook(remember)
    try:
        with torch.no_grad():
            core(input_ids=tokens, attention_mask={"full_attention": mask}, use_cache=False)
            rotary = core.rotary_emb(boundaries[-2], positions)
    finally:
        hook.remove()
        core.total_ut_steps = original_depth
    if len(boundaries) != depth:
        raise ValueError("The native model executed a different number of loops")
    return Boundary(boundaries[-2], boundaries[-1], mask, positions, rotary)


def one_loop(model, boundary, state, depth=4):
    """Match the physical interval between the pre-loop and post-loop states."""
    core = model.model
    state = core.norm(state)
    for layer in core.layers[:core.config.num_hidden_layers]:
        state = layer(state, attention_mask=boundary.mask, position_ids=boundary.positions,
                      past_key_value=None, use_cache=False, cache_position=boundary.positions[0],
                      position_embeddings=boundary.rotary, current_ut=depth - 1)
    return state


def readout(model, state):
    return model.lm_head(model.model.norm(state)).float()


def write_scales(state, normalize):
    if not normalize:
        return torch.ones_like(state[..., :1])
    lengths = state.float().norm(dim=-1, keepdim=True)
    return (lengths / lengths.mean(dim=-2, keepdim=True).clamp_min(1e-12)).to(state.dtype)


def categorical_fisher_product(logits, tangent):
    probabilities = logits.softmax(dim=-1)
    center = (probabilities * tangent).sum(dim=-1, keepdim=True)
    return probabilities * (tangent - center)


def readout_fisher_product(decode, state, tangent, chunk_size):
    """Apply the exact full-vocabulary readout Fisher, with token chunking."""
    n = state.shape[-2]
    results = []
    for start in range(0, n, chunk_size):
        stop = start + chunk_size
        inputs = state[..., start:stop, :].detach().requires_grad_(True)
        displacement = tangent[..., start:stop, :].detach()
        logits, change = jvp(decode, (inputs,), (displacement,))
        with torch.no_grad():
            pullback = categorical_fisher_product(logits, change) / n
        product, = torch.autograd.grad(logits, inputs, grad_outputs=pullback)
        results.append(product.detach())
    return torch.cat(results, dim=-2)


def fisher_matvec(transform, decode, received, scale, direction, positions=None, chunk_size=32):
    """Compute Gv using a shared write followed by exact JVP and VJP."""
    shifted = torch.zeros_like(direction).requires_grad_(True)

    def response(write):
        state = transform(received + scale * write)
        return state if positions is None else state.index_select(-2, positions)

    state, tangent = jvp(response, (shifted,), (direction,))
    pullback = readout_fisher_product(decode, state, tangent, chunk_size)
    product, = torch.autograd.grad(state, shifted, grad_outputs=pullback)
    return product.detach()


def ouro_products(model, boundary, direction, normalized=True, positions=None, isolated=False, depth=4):
    """Return exact direct and loop-mediated Fisher products for one sequence."""
    width = boundary.pre_loop.shape[-2]
    scale = write_scales(boundary.pre_loop, normalized)

    def following_layers(state):
        return one_loop(model, boundary, state, depth)

    def decode(state):
        return readout(model, state)

    def identity(state):
        return state

    direct = fisher_matvec(identity, decode, boundary.post_loop, scale, direction, positions)
    if not isolated:
        loop = fisher_matvec(following_layers, decode, boundary.pre_loop, scale, direction, positions)
        return direct, loop

    if positions is None or len(positions) == 0:
        raise ValueError("Isolated propagation needs predeclared, matched positions")
    loop = torch.zeros_like(direction)
    for position in positions:
        location = position.reshape(1)
        keep = (torch.arange(width, device=direction.device) == position)[None, :, None]
        loop += fisher_matvec(following_layers, decode, boundary.pre_loop, scale * keep,
                              direction, location)
    return direct, loop / len(positions)


def compression_product(transform, state, alpha, basis, v):
    """Compute Q^T S^+ J S Qv for the shared-write subspace S."""
    physical = basis @ v
    expanded = alpha * physical
    _, moved = jvp(transform, (state,), (expanded,))
    compressed = (moved * alpha).sum(dim=(-3, -2)) / alpha.square().sum()
    return basis.mT @ compressed
