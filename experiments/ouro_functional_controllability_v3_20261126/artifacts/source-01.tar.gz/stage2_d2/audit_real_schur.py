"""Verify Henrici departure with a real Schur factorization of the frozen projection."""
import json
from pathlib import Path

import numpy as np
from scipy.linalg import rsf2csf, schur

from d2_worker import digest, load, save_json


stage=Path("stage2_d2/spectral")
source=stage/"FISHER_SUBSPACES.pt"
proof=stage/"D2_SPECTRAL_AUDIT.json"
reported=json.loads(proof.read_text())
if reported["subspaces_sha256"]!=digest(source):
    raise ValueError("Changed compressed Jacobian payload")
matrix=load(source)["M_F"].double().numpy()
if matrix.shape!=(32,32) or not np.isfinite(matrix).all():
    raise ValueError("The 32-dimensional projection is not complete")
triangular,rotation=schur(matrix,output="real")
complex_triangular,_=rsf2csf(triangular,rotation)
eigenvalues=np.diag(complex_triangular)
matrix_norm=float(np.linalg.norm(matrix,ord="fro"))
departure=np.sqrt(max(0.,matrix_norm**2-float(np.sum(np.abs(eigenvalues)**2))))/matrix_norm
known=reported["projected_dynamics"]
orthogonality=float(np.linalg.norm(rotation.T@rotation-np.eye(32)))
reconstruction=float(np.linalg.norm(rotation@triangular@rotation.T-matrix)/matrix_norm)
check=float(abs(departure-known["dep_f"]))
if max(orthogonality,reconstruction,check)>1e-10:
    raise ValueError("The independent real Schur decomposition disagrees with the complex form")
matrix_sing=np.linalg.svd(matrix,compute_uv=False)
eigen_spectral_radius=float(np.max(np.abs(eigenvalues)))
audit=dict(spectral_audit_sha256=digest(proof),compressed_jacobian_source_sha256=digest(source),
            dimension=32,operator="Q^T S^+ J_F S Q (matched 64 no-label texts)",
            factorization="SciPy real Schur with explicit complex conversion of 2x2 blocks",
            eigenvalues=[[float(v.real),float(v.imag)] for v in eigenvalues],
            orthogonality_F=orthogonality,reconstruction_relative_F=reconstruction,
            dep_F=departure,departure_discrepancy_from_complex_form=check,
            singular_over_spectral_radius=float(matrix_sing[0])/eigen_spectral_radius,
            real_schur_T=triangular.tolist(),real_schur_Z=rotation.tolist())
file=stage.parent/"D2_REAL_SCHUR_AUDIT.json"
save_json(file,audit)
print("REAL_SCHUR_VERIFIED",digest(file),departure,reconstruction,orthogonality,flush=True)
