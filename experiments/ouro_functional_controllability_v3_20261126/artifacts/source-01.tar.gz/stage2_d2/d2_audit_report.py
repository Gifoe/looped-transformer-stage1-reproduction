"""Close D2 ablations and audit historical coverage after the no-label freeze."""

import argparse
from hashlib import sha256
from math import acos, degrees, sqrt
import json
from pathlib import Path

import numpy as np
import torch

from d2_worker import digest, load, parse_rows, save_json, save_pt


BASE_TASKS = {"sciq_val":"acc_norm","arc_easy_val":"acc_norm","cosmosqa_val":"acc_norm",
              "mmlu_val":"acc","mmlu_pro_val":"correct"}


def frozen(work):
    reference=work/"D2_REF_OPERATOR.pt"
    lock=work/"D2_SUBSPACE_LOCK.json"
    info=json.loads(lock.read_text())
    if info["controller_sha256"]!=digest(reference):
        raise ValueError("The reference lock and checkpoint disagree")
    return load(reference),info


def unit(vector):
    vector=vector.flatten().double().cpu()
    if vector.norm()<=0 or not vector.isfinite().all():
        raise ValueError("The no-label control has an invalid axis")
    return vector/vector.norm()


def baselines(work):
    _,lock=frozen(work)
    source=work/"spectral"/"FISHER_SUBSPACES.pt"
    if digest(source)!=lock["subspace_sha256"]:
        raise ValueError("The spectral source no longer matches the no-label freeze")
    data=load(source)
    model=load(work/"transients"/"INTERNAL_DIRECTIONS.pt")
    basis=torch.linalg.qr(torch.cat((data["U_FR"][:,:16],data["U_PCA"][:,:16]),1),mode="reduced").Q
    _,_,vh=torch.linalg.svd(data["M_F"])
    generator=torch.Generator().manual_seed(26112625)
    draw=torch.randn(basis.shape[0],generator=generator)
    pool=dict(ufr1_mean=data["U_FR"][:,0],jacobian_right1=basis@vh[0],
              exit_gate=model["exit_gate"],natural_displacement=model["natural_displacement"],random=draw)
    w=unit(data["mean"])
    result={}
    for name,direction in pool.items():
        target=work/"baselines"/name/"controller.pt"
        u=unit(direction)
        # Fix the otherwise arbitrary singular/PCA vector sign against the mean state.
        if torch.dot(u,w)<0:
            u=-u
        meta=dict(name=name,source="frozen no-label directions",read="unit mean pre-loop state",
                  cap=.45,operator_norm=1.,spectral_sha256=digest(source),orientation_sha256=lock["controller_sha256"])
        if not target.exists():
            target.parent.mkdir(parents=True,exist_ok=True)
            save_pt(target,dict(form="rank1",state={"out.weight":u.float()[:,None],"encode.weight":w.float()[None,:]},meta=meta))
        existing=load(target)
        if existing["meta"]!=meta or not torch.equal(existing["state"]["out.weight"].flatten(),u.float()):
            raise ValueError(f"A previously frozen comparator differs: {name}")
        result[name]=dict(weight_sha256=digest(target),meta=meta)
    save_json(work/"D2_U4_BENCHMARK_LOCK.json",result)


def coverage(work,t1,expected):
    reference,lock=frozen(work)
    if digest(t1)!=expected:
        raise ValueError("T1 must be the independently frozen historical checkpoint")
    checkpoint=load(t1)
    state=checkpoint.get("state",checkpoint.get("state_dict",checkpoint))
    u,w=unit(state["out.weight"]),unit(state["encode.weight"])
    a,b=unit(reference["u_A0"]),unit(reference["w_A0"])
    rng=torch.Generator().manual_seed(26112627)
    random=torch.linalg.qr(torch.randn(len(u),32,generator=rng,dtype=torch.float64),mode="reduced").Q
    dims=(1,2,4,8,16,32)
    measured={}
    for name,basis in (("ufr",reference["U_FR_32"]),("pca",reference["U_PCA"]),("random",random)):
        projection=(basis.double().mT@u).square()
        measured[name]={str(k):float(projection[:k].sum()) for k in dims}
    measured["random_theory"]={str(k):k/len(u) for k in dims}
    cos_u,cos_w=float(a@u),float(b@w)
    value=dict(lock_sha256=digest(work/"D2_SUBSPACE_LOCK.json"),t1_sha256=expected,coverage=measured,
               cosine=dict(write=cos_u,read=cos_w,operator=cos_u*cos_w),selection_feedback=False)
    save_json(work/"D2_T1_COVERAGE_AUDIT.json",value)


def dynamics(work):
    spectral=work/"spectral"/"D2_SPECTRAL_AUDIT.json"
    transient=work/"transients"/"D2_TRANSIENT_AUDIT.json"
    solutions=json.loads(spectral.read_text())
    native=json.loads(transient.read_text())
    modes=solutions["results"]
    full,isolated=modes["paired_full"]["eigenvalues"][0],modes["paired_isolated"]["eigenvalues"][0]
    principal={}
    full_basis=load(spectral.with_name("spectrum_paired_full.pt"))["U"]
    iso_basis=load(spectral.with_name("spectrum_paired_isolated.pt"))["U"]
    for rank in (1,4,8,16,32):
        overlap=torch.linalg.svdvals(full_basis[:,:rank].mT@iso_basis[:,:rank]).clamp(0,1)
        principal[str(rank)]=(torch.acos(overlap)*180/torch.pi).tolist()
    projection=solutions["projected_dynamics"]
    internal=native["diagnostics"]
    angles={name:degrees(acos(sqrt(min(1.0,max(0.0,float(energy)))))) for name,energy in internal.items()}
    report=dict(dep_F=projection["dep_f"],sv_alignment=projection["singular_alignment"],
                projected=projection,transient_curve=native["measured"],internal_alignment=internal,
                internal_principal_angles_degrees=angles,
                full_vs_isolated_mu1={"full":full,"isolated":isolated,"ratio":full/isolated,
                                     "principal_angles_degrees":principal},
                cohort={"native":len(native["chosen_ids"]),"paired_fisher":64,"paired_positions_per_input":4},
                source_sha256={"native":digest(transient),"projected":digest(spectral)})
    save_json(work/"D2_NONNORMALITY_AUDIT.json",report)


def heldout_bootstrap(direct, mediated, penalty, documents, repeats=10000, seed=261126903):
    """Resample WikiText documents while retaining paired rays and the fitted regularizer."""
    groups={name:i for i,name in enumerate(dict.fromkeys(documents))}
    inverse=np.asarray([groups[name] for name in documents])
    counts=np.bincount(inverse)
    direct_sums=np.zeros((len(groups),direct.shape[1]))
    mediated_sums=np.zeros_like(direct_sums)
    np.add.at(direct_sums,inverse,direct.numpy())
    np.add.at(mediated_sums,inverse,mediated.numpy())
    rng=np.random.default_rng(seed)
    contrasts=[]
    for start in range(0,repeats,128):
        draws=min(128,repeats-start)
        resamples=rng.multinomial(len(groups),np.full(len(groups),1./len(groups)),size=draws)
        ratios=(resamples@mediated_sums)/((resamples@direct_sums)+penalty*(resamples@counts)[:,None])
        fisher=np.median(ratios[:,:16],axis=1)
        pca=np.median(ratios[:,32:48],axis=1)
        random=np.median(ratios[:,48:64],axis=1)
        contrasts.append(np.stack((fisher,fisher-pca,fisher-random),axis=1))
    intervals=np.quantile(np.concatenate(contrasts),(.025,.975),axis=0).T
    return dict(cluster_unit="document",n_documents=len(groups),replicates=repeats,
                ci95={name:bound.tolist() for name,bound in zip(
                    ("fisher_top16_median","fisher_minus_pca_top16_median","fisher_minus_random_top16_median"),
                    intervals,strict=True)})


def rayleigh(work,audit):
    rows=parse_rows(audit)
    expected=[row["id"] for row in rows]
    audit_sha=digest(audit)
    parts=[]
    for slot in range(3):
        shard=load(work/"heldout_rayleigh"/f"shard_{slot}"/"HELDOUT_RAYLEIGH.pt")
        if shard["ids"]!=expected[slot::3] or shard["audit_sha256"]!=audit_sha:
            raise ValueError(f"Incorrect held-out shard: {slot}")
        parts.append(shard)
    total=sum(p["n"] for p in parts)
    if total!=512 or any(p["rank_groups"]!=[32,16,16] for p in parts):
        raise ValueError("Incomplete held-out rayleigh experiment")
    spectra=load(work/"spectral"/"spectrum_main.pt")
    direct_fitted=0.
    # Use the same fitted normalization as the generalized eigensolver.
    for slot in range(3):
        initial=load(work/"exchange"/f"gpu_{slot}"/"DIRECT_FISHER.pt")
        direct_fitted+=float(initial["direct_normalized"].trace())*initial["n_examples"]/1024
    penalty=.1*direct_fitted/len(spectra["axes"])
    direct=torch.cat([p["direct"] for p in parts])
    mediated=torch.cat([p["mediated"] for p in parts])
    fitted=mediated.mean(0)/(direct.mean(0)+penalty)
    row_ratio=mediated/(direct+penalty)
    by_groups={}
    for label,first,last in (("fisher",0,32),("pca",32,48),("random",48,64)):
        by_groups[label]=dict(regularized_ratios=fitted[first:last].tolist(),
            direct_mean=direct[:,first:last].mean(0).tolist(),
            mediated_mean=mediated[:,first:last].mean(0).tolist(),
            sample_ratio_std=row_ratio[:,first:last].std(0).tolist())
    document_order=[str(row.get("document_id",row["id"])) for slot in range(3) for row in rows[slot::3]]
    intervals=heldout_bootstrap(direct,mediated,penalty,document_order)
    save_json(work/"D2_HELDOUT_RAYLEIGH.json",dict(n=total,lambda_fitted=penalty,groups=by_groups,
             paired_document_bootstrap=intervals,fit_eigenvalues=spectra["values"].tolist(),audit_sha256=audit_sha))


def panel_mean(data):
    return sum(data[task][metric] for task,metric in BASE_TASKS.items())/len(BASE_TASKS)


def summarize_scores(work,e0):
    references={}
    for name in ("native","t1","t2","mixed"):
        p=e0/"e0_external_dev"/name/"DEVELOPMENT.json"
        references[name]=json.loads(p.read_text())
    external={name:panel_mean(value["metrics"]) for name,value in references.items()}
    historical={name:sum(v["value"] for v in value["historical"]["metrics"].values())/
                     len(value["historical"]["metrics"]) for name,value in references.items()}
    rows={}
    for p in sorted((work/"no_label_dev").glob("*/DEVELOPMENT.json")):
        value=json.loads(p.read_text())
        key=p.parent.name
        score=panel_mean(value["metrics"])
        old=sum(v["value"] for v in value["historical"]["metrics"].values())/len(value["historical"]["metrics"])
        rows[key]=dict(external=score,external_pp_vs_native=100*(score-external["native"]),historical=old,
                       historical_pp_vs_native=100*(old-historical["native"]),
                       external_tasks=value["metrics"],historical_tasks=value["historical"]["metrics"],
                       receipt_sha256=digest(p))
    expected={"U1_PMI","U2_NLL","U3_Entropy","ufr1_mean","jacobian_right1","exit_gate","natural_displacement","random"}
    if set(rows)!=expected:
        raise ValueError("The no-label score panel was not complete")
    save_json(work/"D2_ZERO_LABEL_EVAL.json",
              dict(arms=rows,reference_external=external,reference_historical=historical))


def summarize_sample(work,e0):
    from d2_sample_efficiency import METHODS, SIZES, SEEDS
    native=e0/"e0_external_dev"/"native"/"DEVELOPMENT.json"
    baseline=panel_mean(json.loads(native.read_text())["metrics"])
    result={}
    means={}
    receipt_dir=work/"downstream_receipts"
    for method in METHODS:
        means[method]={}
        for n in SIZES:
            rows=[]
            subsets=[]
            for seed in SEEDS:
                name=f"{method}.{n}.{seed}"
                marker=receipt_dir/f"d2.sample.{name}.json"
                receipt=json.loads(marker.read_text())
                run=work/"sample_efficiency"/name
                train=run/"TRAIN.json"
                dev=run/"dev"/"DEVELOPMENT.json"
                contents=json.loads(train.read_text())
                score=json.loads(dev.read_text())
                if any(digest(p)!=receipt["artifact_sha256"].get(str(p)) for p in (train,dev,run/"controller.pt")):
                    raise ValueError(f"A sample efficiency run was incomplete: {name}")
                if int(contents["n"])!=n or contents["seed"]!=seed or score["weight_sha256"]!=contents["checkpoint_sha256"]:
                    raise ValueError(f"Training and evaluation identity mismatch: {name}")
                rows.append(dict(seed=seed,score=panel_mean(score["metrics"]),benchmark=score["metrics"],
                                 token_loops=contents["padded_token_loops"],sha256=digest(dev)))
                subset_digest=sha256(json.dumps(contents["ids"]).encode()).hexdigest()
                subsets.append(subset_digest)
                if method!="Full_Cold":
                    ref=work/"sample_efficiency"/f"Full_Cold.{n}.{seed}"/"TRAIN.json"
                    if contents["ids"]!=json.loads(ref.read_text())["ids"]:
                        raise ValueError("Controller methods used different cohorts")
            scores=torch.tensor([row["score"] for row in rows],dtype=torch.float64)
            means[method][n]=float(scores.mean())
            result[f"{method}.{n}"]=dict(mean=float(scores.mean()),std=float(scores.std()),seeds=rows,
                                         subset_sha256=subsets)
    matched={}
    for method in METHODS:
        curve=[]
        for n in SIZES:
            score=means[method][n]
            qualifying=[k for k in SIZES if means["Full_Cold"][k]>=score]
            match=min(qualifying) if qualifying else None
            curve.append(dict(n=n,cold_n=match,ratio=match/n if match else None,
                              lower_bound=None if match else max(SIZES)/n))
        matched[method]=curve
    save_json(work/"D2_SAMPLE_EFFICIENCY.json",dict(n_arms=105,steps=280,native=baseline,
              groups=result,matched_cold_sample_ratio=matched,
              ratio_definition="smallest declared cold N with mean score >= the candidate at its N"))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work",type=Path,required=True)
    parser.add_argument("--phase",required=True,choices=("baselines","coverage","dynamics","rayleigh","score","sample"))
    parser.add_argument("--t1",type=Path)
    parser.add_argument("--t1-sha256")
    parser.add_argument("--audit",type=Path)
    parser.add_argument("--e0",type=Path)
    args=parser.parse_args()
    functions={"baselines":(baselines,()),"coverage":(coverage,(args.t1,args.t1_sha256)),
            "dynamics":(dynamics,()),"rayleigh":(rayleigh,(args.audit,)),
            "score":(summarize_scores,(args.e0,)),"sample":(summarize_sample,(args.e0,))}
    action,more=functions[args.phase]
    action(args.work,*more)
    print("D2_SUMMARY_COMPLETE",args.phase,flush=True)


if __name__=="__main__":
    main()

