#!/usr/bin/env bash
set -euo pipefail
dispatch_host=$1
dispatch_part=$2
v3_root=/root/ouro-v3-controllability-20261126
cd /root/ouro-external-data-joint-training-20261124
source external_env.sh
cd "$v3_root"
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4
export PYTHONPATH="$v3_root/stage2_d2:$v3_root/stage1_e0/code:$v3_root/tools:/root/ouro-loop-aware-functional-identification-20261125:$PYTHONPATH"
case "$dispatch_host:$dispatch_part" in
  old:pilot) v3_plan=stage2_d2/DOWNSTREAM_FROZEN_EVALUATION_RECOVERY_PILOT.json ;;
  old:full|dual:full) v3_plan=stage2_d2/DOWNSTREAM_FROZEN_EVALUATION_RECOVERY.json ;;
  *) exit 2 ;;
esac
test -s stage2_d2/D2_SUBSPACE_LOCK.json
test -s stage2_d2/D2_SAMPLE_RECOVERY.json
exec "$py" -u tools/gpu_dispatch.py --root "$v3_root" --host "$dispatch_host" --manifest "$v3_root/$v3_plan"
