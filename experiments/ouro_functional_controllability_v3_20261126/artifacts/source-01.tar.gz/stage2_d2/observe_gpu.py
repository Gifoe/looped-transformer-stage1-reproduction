"""Sample GPU device counters for the sharded exact Fisher computation."""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import subprocess
import time


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--slot",type=int,required=True)
    parser.add_argument("--device",type=int,required=True)
    parser.add_argument("--work",type=Path,required=True)
    a=parser.parse_args()
    output=a.work/"logs"/f"D2_GPU_{a.slot}_OBSERVED.tsv"
    inbox=a.work/"exchange"/f"gpu_{a.slot}"/"inbox"
    results=inbox.parent/"results"
    header="utc\tlogical_gpu\tphysical_gpu\tpending_count\tmemory_used_mib\tmemory_total_mib\tutil_percent\tpower_watts\n"
    with output.open("a",encoding="utf-8",buffering=1) as target:
        if output.stat().st_size==0:
            target.write(header)
        while not (inbox/"STOP").is_file():
            command=["nvidia-smi","-i",str(a.device),
                     "--query-gpu=memory.used,memory.total,utilization.gpu,power.draw",
                     "--format=csv,noheader,nounits"]
            snapshot=subprocess.run(command,capture_output=True,text=True,timeout=8,check=True)
            metrics=[attr.strip() for attr in snapshot.stdout.strip().split(",")]
            if len(metrics)!=4:
                raise ValueError("Invalid device stats reply")
            queued=sum(1 for path in inbox.glob("*.pt") if not (results/path.name).is_file())
            now=datetime.now(timezone.utc).isoformat()
            target.write("\t".join((now,str(a.slot),str(a.device),str(queued),*metrics))+"\n")
            time.sleep(15)


if __name__=="__main__":
    main()

