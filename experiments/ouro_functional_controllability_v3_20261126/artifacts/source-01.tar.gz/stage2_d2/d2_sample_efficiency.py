"""Train one declared sample-efficiency arm while the full Ouro base is frozen."""

import argparse
from hashlib import sha256
import json
from pathlib import Path

import torch
from torch import nn

import minimal
from e0_reuse import BASE_SHA, DEPTHS, RECIPE, score_rows, streams
from d2_worker import digest, load, save_json, save_pt


METHODS = ("Full_Cold","UFR16_Proj","U1_PMI_Warm","PCA16_Proj","Rand16_Proj")
SIZES = (8,16,32,64,128,256,1013)
SEEDS = (26112631,26112632,26112633)


class ProjectedRankOne(nn.Module):
    kind = "linear"

    def __init__(self, subspace, cold):
        super().__init__()
        self.register_buffer("subspace", subspace.float())
        self.coords = nn.Parameter(torch.zeros(subspace.shape[1]))
        self.read = nn.Parameter(cold.encode.weight.detach().clone().flatten())

    def delta(self, h, previous=None):
        write = self.subspace @ self.coords
        x = h.float()
        proposed = (x @ self.read)[..., None] * write
        relative = .45 * x.norm(dim=-1, keepdim=True) / proposed.norm(dim=-1, keepdim=True).clamp_min(1e-12)
        return proposed * relative.clamp(max=1.)

    def deployed(self):
        return {"encode.weight": self.read.detach().cpu()[None,:],
                "out.weight": (self.subspace @ self.coords).detach().cpu()[:,None]}


def anchor_module(root, method, seed):
    torch.manual_seed(seed)
    original = minimal.Minimal("linear", 1, .45)
    if method == "Full_Cold":
        return original
    basis = load(root)
    if method == "U1_PMI_Warm":
        original.load_state_dict(basis["state"])
        return original
    if method == "UFR16_Proj":
        subspace = basis["U_FR_32"][:, :16]
    elif method == "PCA16_Proj":
        subspace = basis["U_PCA"][:, :16]
    else:
        rng=torch.Generator().manual_seed(2*seed+26112632)
        subspace=torch.linalg.qr(torch.randn(2048,16,generator=rng,dtype=torch.float64)).Q
    return ProjectedRankOne(subspace, original)


def arm(args):
    alpha=json.loads(args.reference.with_name("D2_SUBSPACE_LOCK.json").read_text(encoding="utf-8"))
    if alpha["controller_sha256"] != digest(args.reference):
        raise ValueError("The zero-label reference must be frozen before supervised training")
    config=json.loads(args.e0_config.read_text(encoding="utf-8"))
    approved=Path(config["approved_env_manifest"])
    if digest(approved) != config["approved_env_sha256"]:
        raise ValueError("The supervised data preflight cannot change")
    entry=config["pools"]["arc_challenge"]
    source=Path(entry["path"])
    if digest(source) != entry["sha256"]:
        raise ValueError("ARC training input changed")
    data=minimal.load_jsonl(source)
    if len(data)!=1013:
        raise ValueError("This sample curve uses the frozen decontaminated 1,013-row ARC pool")
    ordered=sorted(data, key=lambda row:sha256(f"{args.seed}:{row['sample_id']}".encode()).hexdigest())
    selected=ordered[:args.samples]
    ids=[row["sample_id"] for row in selected]
    if len(set(ids))!=args.samples:
        raise ValueError("The selected supervised training cohort was not unique")
    args.out.mkdir(parents=True,exist_ok=True)
    stamp=dict(method=args.method,n=args.samples,seed=args.seed,ids=ids,steps=args.steps,recipe=RECIPE,
               source_sha256=digest(source),e0_config_sha256=digest(args.e0_config),
               d2_reference_sha256=digest(args.reference),runner_sha256=digest(Path(__file__)))
    lock=args.out/"FIT_LOCK.json"
    if lock.exists() and json.loads(lock.read_text())!=stamp:
        raise ValueError("An existing sample efficiency arm has a different training allocation")
    save_json(lock,stamp)
    final=args.out/"TRAIN.json"
    if final.exists():
        existing=json.loads(final.read_text())
        if digest(args.out/"controller.pt") != existing["checkpoint_sha256"]:
            raise ValueError("Completed output was changed")
        return
    archive,model,tokenizer,context = minimal.runtime(Path(config["archive"]),Path(config["previous"]),Path(config["model"]))
    if context["model_sha256"] != BASE_SHA or any(p.requires_grad for p in model.parameters()):
        raise ValueError("The fitted model must keep the same frozen Ouro backbone")
    net=anchor_module(args.reference,args.method,args.seed).to(model.device).requires_grad_(True)
    opt=torch.optim.AdamW(net.parameters(),lr=RECIPE["learning_rate"],weight_decay=RECIPE["weight_decay"])
    stream=streams(selected,args.seed,"D2_ARC_SAMPLE_EFFICIENCY")
    done,work=0,0
    checkpoint=args.out/"resume.pt"
    if checkpoint.exists():
        saved=load(checkpoint)
        if saved["fit_sha256"]!=digest(lock):
            raise ValueError("The training snapshot belongs to a different arm")
        net.load_state_dict(saved["network"])
        opt.load_state_dict(saved["optimizer"])
        done,work=saved["completed"],saved["padded_token_loops"]
        for _ in range(done*RECIPE["effective_batch"]): next(stream)
    for step in range(done,args.steps):
        batch=[next(stream) for _ in range(RECIPE["effective_batch"])]
        depth=DEPTHS[step%len(DEPTHS)]
        opt.zero_grad(set_to_none=True)
        with torch.enable_grad():
            objective, _, _, cost=score_rows(archive,model,tokenizer,net,batch,depth,"rank")
            objective.backward()
        magnitude = torch.nn.utils.clip_grad_norm_(net.parameters(),RECIPE["clip"])
        if not magnitude.isfinite().item():
            raise ValueError("Non-finite sample efficiency optimizer step")
        opt.step()
        work += cost
        if step%70 == 69 or step+1==args.steps:
            save_pt(checkpoint,dict(network=net.state_dict(),optimizer=opt.state_dict(),
                 completed=step+1,padded_token_loops=work,fit_sha256=digest(lock)))
            print("D2_SAMPLE_TRAIN",args.method,args.samples,args.seed,step+1,args.steps,flush=True)
    weights=(net.deployed() if isinstance(net,ProjectedRankOne)
             else {name:value.detach().cpu() for name,value in net.state_dict().items()})
    location=args.out/"controller.pt"
    trainable=sum(p.numel() for p in net.parameters())
    save_pt(location,dict(form="rank1",state=weights,meta={"trainable":trainable,"fit_sha256":digest(lock)}))
    save_json(final,dict(**stamp,trainable_parameters=trainable,
                        inference_parameters=4096,padded_token_loops=work, checkpoint_sha256=digest(location)))
    print("D2_SAMPLE_ARM_READY",args.method,args.samples,args.seed,digest(location),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("reference","e0-config","out"):
        parser.add_argument(f"--{name}",type=Path,required=True)
    parser.add_argument("--method",choices=METHODS,required=True)
    parser.add_argument("--samples",type=int,choices=SIZES,required=True)
    parser.add_argument("--seed",type=int,choices=SEEDS,required=True)
    parser.add_argument("--steps",type=int,default=280)
    arm(parser.parse_args())


if __name__=="__main__":
    main()

