"""Measure native deep-loop transient responses on independent unlabelled text."""

import argparse
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path

import torch
from torch.nn.attention import SDPBackend, sdpa_kernel

from d2_operator import readout, write_scales
from d2_worker import digest, load, model_load, parse_rows, save_json, save_pt, token_ids


def trajectory(model, tokens, axis=None, epsilon=0.0, depth=8):
    core = model.model
    count = 0
    targets = {}

    def norm(_, args):
        nonlocal count
        count += 1
        raw = args[0]
        if count == 3 and axis is not None:
            raw = raw + epsilon * write_scales(raw, normalize=True) * axis
        if count >= 3:
            targets[count] = raw.detach()
        return (raw,) if raw is not args[0] else None

    native_depth = core.total_ut_steps
    core.total_ut_steps = depth
    handle = core.norm.register_forward_pre_hook(norm)
    try:
        _, loops, _ = core(input_ids=tokens, use_cache=False)
        if count != depth or len(loops) != depth:
            raise ValueError("The true recurrent run did not traverse the requested loop budget")
    finally:
        handle.remove()
        core.total_ut_steps = native_depth
    return targets


def head_divergence(model, state, reference, head_chunk=24):
    total = 0.0
    n = state.shape[-2]
    for start in range(0, n, head_chunk):
        part = state[:, start:start+head_chunk]
        base = reference[:, start:start+head_chunk]
        left = readout(model, part).double().log_softmax(-1)
        right = readout(model, base).double().log_softmax(-1)
        total += float((left.exp() * (left-right)).sum())
    return max(0.0, total/n)


def projection(axis, basis):
    vector = axis.float()
    return float((basis.mT @ vector).square().sum() / vector.square().sum().clamp_min(1e-20))


def summarize(records):
    groups = defaultdict(list)
    for item in records:
        for name, changes in item["curves"].items():
            for depth, measurement in changes.items():
                groups[name, depth].append(measurement)
    result = defaultdict(dict)
    for (name, depth), data in groups.items():
        result[name][depth] = {key: sum(row[key] for row in data) / len(data) for key in data[0]}
    return result


def relevant_axes_sha256(data):
    stamp=sha256()
    for name in ("U_FR","U_PCA"):
        values=data[name][:,:16].contiguous().cpu()
        stamp.update(f"{name}:{values.shape}:{values.dtype}\n".encode())
        stamp.update(values.numpy().tobytes())
    return stamp.hexdigest()


def run(args):
    args.out.mkdir(parents=True, exist_ok=True)
    data = load(args.subspaces)
    spec = dict(source_sha256=digest(args.audit), subspace_axes_sha256=relevant_axes_sha256(data),
                model_sha256=args.model_sha256,runner_sha256=digest(Path(__file__)),rows=args.count,
                dose=args.dose,depth_boundaries=[3,4,5,6,7,8],seed=26112625)
    lock = args.out / "TRANSIENT_LOCK.json"
    if lock.exists() and json.loads(lock.read_text()) != spec:
        raise ValueError("The existing held-out transient cohort cannot change")
    save_json(lock, spec)
    done=args.out/"D2_TRANSIENT_COMPLETE.json"
    outputs=(args.out/"D2_TRANSIENT_AUDIT.json",args.out/"INTERNAL_DIRECTIONS.pt")
    if done.exists():
        receipt=json.loads(done.read_text())
        if receipt["protocol_sha256"]!=digest(lock) or receipt["artifacts"]!={p.name:digest(p) for p in outputs}:
            raise ValueError("Completed transient results were prepared from different axes or modified")
        print("D2_NATIVE_TRANSIENTS_REUSED",args.count,flush=True)
        return
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32 = False
    native, tok = model_load(args)
    source = parse_rows(args.audit)
    if len(source) != 512 or not 0 < args.count <= len(source):
        raise ValueError("Expected the locked 512-record unlabelled audit pool")
    source = sorted(source, key=lambda row: sha256(f"{spec['seed']}:{row['id']}".encode()).hexdigest())[:args.count]
    ufr = data["U_FR"].float().cuda()[:, :16]
    pca = data["U_PCA"].float().cuda()[:, :16]
    rng = torch.Generator().manual_seed(spec["seed"])
    normal = torch.randn(ufr.shape[0], generator=rng).cuda()
    directions = {"fisher": ufr[:, 0], "pca": pca[:, 0], "random": normal/normal.norm()}
    head = native.model.early_exit_gate
    gate = getattr(head, "weight", None)
    align = dict(gate_ufr16=projection(gate.flatten(), ufr),gate_pca16=projection(gate.flatten(),pca)) \
            if gate is not None and gate.numel() == ufr.shape[0] else {}
    n = 0
    delta_sum = torch.zeros(ufr.shape[0], dtype=torch.float64, device="cuda")
    delta_gram = torch.zeros((ufr.shape[0],ufr.shape[0]), dtype=torch.float64, device="cuda")
    records = []
    with torch.no_grad(), sdpa_kernel(SDPBackend.MATH):
        for index, row in enumerate(source):
            input_ids = token_ids(row, tok)
            ref = trajectory(native,input_ids)
            displacement = (ref[4]-ref[3]).reshape(-1,ufr.shape[0])
            delta_sum += displacement.sum(0, dtype=torch.float64)
            delta_gram += (displacement.mT @ displacement).double()
            n += len(displacement)
            path = args.out / f"row_{index:03d}.json"
            if path.exists():
                record = json.loads(path.read_text())
                if record["id"] != row["id"] or record["protocol_sha256"] != digest(lock):
                    raise ValueError("The saved held-out transient does not match")
                records.append(record)
                continue
            response = {}
            for name, direction in directions.items():
                plus = trajectory(native,input_ids,direction,args.dose)
                minus = trajectory(native,input_ids,direction,-args.dose)
                initial = (plus[3]-minus[3]).norm().clamp_min(1e-20)
                response[name] = {str(depth): dict(
                    state_amplification=float((plus[depth]-minus[depth]).norm()/initial),
                    symmetric_dose_kl=.5*(head_divergence(native,plus[depth],ref[depth]) +
                                          head_divergence(native,minus[depth],ref[depth])))
                         for depth in range(4,9)}
            record = dict(id=row["id"], curves=response, protocol_sha256=digest(lock))
            save_json(path,record)
            records.append(record)
            print("TRANSIENT_SEQUENCE",len(records),args.count,flush=True)
    variance = delta_gram/n - torch.outer(delta_sum/n,delta_sum/n)
    _, axes = torch.linalg.eigh((variance+variance.mT)/2)
    if gate is None or gate.numel() != ufr.shape[0]:
        raise ValueError("The published Ouro exit gate no longer has one hidden-space axis")
    save_pt(args.out/"INTERNAL_DIRECTIONS.pt", dict(exit_gate=gate.detach().flatten().cpu(),
               natural_displacement=axes[:,-1].detach().cpu()))
    align["native_displacement_ufr16"] = projection(axes[:,-1],ufr)
    align["native_displacement_pca16"] = projection(axes[:,-1],pca)
    report = dict(spec, chosen_ids=[item["id"] for item in records], diagnostics=align, measured=summarize(records))
    save_json(args.out/"D2_TRANSIENT_AUDIT.json",report)
    save_json(done,dict(protocol_sha256=digest(lock),artifacts={p.name:digest(p) for p in outputs}))
    print("D2_NATIVE_TRANSIENTS_COMPLETE",len(records),flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("model","subspaces","audit","out"):
        parser.add_argument(f"--{name}", required=True, type=Path)
    parser.add_argument("--model-sha256", required=True)
    parser.add_argument("--count", type=int, default=64)
    parser.add_argument("--dose", type=float, default=1e-3)
    run(parser.parse_args())


if __name__ == "__main__":
    main()

