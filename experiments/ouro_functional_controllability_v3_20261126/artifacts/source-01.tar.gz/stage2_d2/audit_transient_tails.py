from hashlib import file_digest
from pathlib import Path
import json
import numpy as np

root=Path("stage2_d2")
raw=root/"transients"
base=root/"D2_PHYSICAL_TRANSIENT_PAIRED_AUDIT.json"
def sha(p):
    with p.open("rb") as stream:
        return file_digest(stream,"sha256").hexdigest()
witness=json.loads(base.read_text())
rows=[]
for index in range(64):
    p=raw/f"row_{index:03d}.json"
    assert sha(p)==witness["cohort_sha256"][str(index)]
    rows.append(json.loads(p.read_text()))
robust={}
for depth in map(str,range(4,9)):
    robust[depth]={}
    for metric in ("state_amplification","symmetric_dose_kl"):
        current={}
        for control in ("pca","random"):
            a=np.array([line["curves"]["fisher"][depth][metric] for line in rows])
            b=np.array([line["curves"][control][depth][metric] for line in rows])
            differences=a-b
            sample=int(differences.argmax())
            total=differences.sum()
            current[control]={"median_of_paired_differences":float(np.median(differences)),
                              "n_paired_differences_positive":int((differences>0).sum()),
                              "n_paired_differences_zero":int((differences==0).sum()),
                              "q90_of_paired_differences":float(np.quantile(differences,.9)),
                              "largest_differential_row":rows[sample]["id"],
                              "largest_differential_fraction_of_total":float(differences[sample]/total) if total>0 else None}
        robust[depth][metric]=current
out=dict(base_physical_audit_sha256=sha(base),n=len(rows),per_depth=robust,
         probability_metric="Average of signed-dose KL(P_perturbed || P_native) with the native run fixed.",
         summaries="Paired medians and largest signed contribution. These describe the response distribution and leave the preregistered H2.2 gate unchanged.")
dest=root/"D2_PHYSICAL_TAIL_DIAGNOSTIC.json"
tmp=dest.with_suffix(".partial")
tmp.write_text(json.dumps(out,indent=2,sort_keys=True)+"\n")
tmp.replace(dest)
print("D2_TAIL_VALIDATED",sha(dest),json.dumps(robust["6"]))
