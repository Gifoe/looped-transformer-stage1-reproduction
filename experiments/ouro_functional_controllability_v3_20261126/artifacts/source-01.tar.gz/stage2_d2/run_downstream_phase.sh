#!/usr/bin/env bash
set -euo pipefail
host=$1
phase=$2
root=/root/ouro-v3-controllability-20261126
cd /root/ouro-external-data-joint-training-20261124
source external_env.sh
cd "$root"
export OMP_NUM_THREADS=4
export OPENBLAS_NUM_THREADS=4
export PYTHONPATH="$root/stage2_d2:$root/stage1_e0/code:$root/tools:/root/ouro-loop-aware-functional-identification-20261125:$PYTHONPATH"
test -s stage1_e0/E0_VERDICT.json
test -s stage2_d2/spectral/D2_SPECTRAL_AUDIT.json
case "$phase" in
  orientation|audit|score|sample) ;;
  *) exit 2;;
esac
manifest="$root/stage2_d2/DOWNSTREAM_$phase.json"
"$py" -u stage2_d2/d2_downstream.py --root "$root" --phase "$phase" --out "$manifest"
exec "$py" -u tools/gpu_dispatch.py --root "$root" --host "$host" --manifest "$manifest"
