"""Compile preregistered D2 downstream jobs from verified, immutable receipts."""

import argparse
import json
import sys
from pathlib import Path

from d2_sample_efficiency import METHODS, SEEDS, SIZES
from d2_worker import digest, save_json

HOSTS = {
    "0": {"host": "old", "local_index": 0},
    "1": {"host": "dual", "local_index": 0},
    "2": {"host": "dual", "local_index": 1},
}
BASE = "58872a72616c736595b8b7662079c5b12c5a162ec16eae94f21c348dfa9885af"
ORIENT = (("pmi", "0.1", 16), ("pmi", "0.3", 16), ("pmi", "1.0", 16),
          ("nll", "0.3", 16), ("entropy", "0.3", 16),
          ("pmi", "0.3", 8), ("pmi", "0.3", 32))
CONTROL_NAMES = ("ufr1_mean", "jacobian_right1", "exit_gate", "natural_displacement", "random")
RUNNER = Path(__file__).resolve()


def config_key(path):
    return json.loads(path.read_text(encoding="utf-8"))


def orientation_name(objective, beta, rank):
    return f"{objective}_{beta}_rank{rank}"


def sample_arms(work):
    for seed in SEEDS:
        for n in SIZES:
            for method in METHODS:
                name = f"{method}.{n}.{seed}"
                yield name, work / "sample_efficiency" / name, method, n, seed


def plan(root, phase):
    work = root / "stage2_d2"
    env = root / "stage0_env" / "ENV_MANIFEST.json"
    config = root / "stage1_e0" / "E0_CONFIG.json"
    model = Path(config_key(config)["model"])
    subspaces = work / "spectral" / "FISHER_SUBSPACES.pt"
    audit = work / "spectral" / "D2_SPECTRAL_AUDIT.json"
    if config_key(audit)["subspaces_sha256"] != digest(subspaces):
        raise ValueError("Cannot configure downstream work before the spectra are closed")
    paired = [("--model", model), ("--model-sha256", BASE), ("--subspaces", subspaces)]
    fit = root / "stage0_env" / "UNLABELED_CORPUS" / "fit_unlabeled.jsonl"
    audit_corpus = fit.with_name("audit_unlabeled.jsonl")
    reference = work / "D2_REF_OPERATOR.pt"
    lock = work / "D2_SUBSPACE_LOCK.json"
    if phase in {"score", "sample"} and config_key(lock)["controller_sha256"] != digest(reference):
        raise ValueError("The unlabelled reference must be frozen before reading QA data")
    jobs = []

    def add(name, module, args, outputs, depends, seconds, slot=None):
        entry = dict(job_id=name, cmd=[str(sys.executable), "-u", str(module)] +
                     [str(x) for kv in args for x in kv], artifacts=[str(p) for p in outputs],
                     log_path=str(work / "downstream_logs" / f"{name}.log"),
                     done_marker=str(work / "downstream_receipts" / f"{name}.json"),
                     estimated_seconds=seconds,
                     input_sha256={str(p):digest(p) for p in {RUNNER, module, env, config, *depends}})
        if slot is not None:
            entry["preferred_gpu"] = str(slot)
        jobs.append(entry)

    if phase == "orientation":
        for objective, beta, width in ORIENT:
            name = orientation_name(objective,beta,width)
            target = work / "orientation" / name
            add(f"d2.orient.{name}", work/"d2_orient.py",
                paired+[("--fit",fit),("--audit",audit_corpus),("--objective",objective),("--beta",beta),
                        ("--rank",width),("--out",target)],
                [target/"controller.pt",target/"AUDIT.json",target/"CONFIG.json"],[subspaces,fit,audit_corpus],
                460 if objective == "pmi" else 300)
        target = work / "transients"
        add("d2.transients",work/"d2_transients.py",paired+[("--audit",audit_corpus),("--out",target)],
            [target/"D2_TRANSIENT_AUDIT.json",target/"INTERNAL_DIRECTIONS.pt"],
            [subspaces,audit_corpus],240,"0")
    elif phase == "sample":
        for name, target, method, n, seed in sample_arms(work):
            add(f"d2.sample.{name}",work/"run_sample_arm.py",
                [("--reference",reference),("--e0-config",config),("--out",target),
                 ("--method",method),("--samples",n),("--seed",seed),("--steps",280)],
                [target/"controller.pt",target/"TRAIN.json",target/"dev"/"DEVELOPMENT.json"],
                [reference,lock,work/"d2_sample_efficiency.py",root/"tools"/"score_shared_dev.py"],230)
    elif phase == "score":
        selections=config_key(lock)["chosen"]
        arms={
            "U1_PMI":work/"orientation"/orientation_name("pmi",str(selections["beta"]),16)/"controller.pt",
            "U2_NLL":work/"orientation"/"nll_0.3_rank16"/"controller.pt",
            "U3_Entropy":work/"orientation"/"entropy_0.3_rank16"/"controller.pt",
        }
        arms.update({key:work/"baselines"/key/"controller.pt" for key in CONTROL_NAMES})
        for name, weight in arms.items():
            target=work/"no_label_dev"/name
            add(f"d2.no_label.{name}",work/"d2_dual_panel.py",
                [("--config",config),("--out",target),("--arm",name),
                 ("--weight",weight),("--weight-sha256",digest(weight))],
                [target/"DEVELOPMENT.json"],
                [reference,lock,weight,root/"stage1_e0"/"code"/"e0_external_dev.py"],420)
    else:
        spectrum_lock=subspaces.with_name("SPECTRAL_PROTOCOL.json")
        eigensol=subspaces.with_name("spectrum_main.pt")
        for slot in range(3):
            target=work/"heldout_rayleigh"/f"shard_{slot}"
            add(f"d2.rayleigh.{slot}",work/"heldout_rayleigh.py",
                paired+[("--audit",audit_corpus),("--out",target),("--environment",env),
                ("--spectrum-lock",spectrum_lock),("--eigenvectors",eigensol),("--block",32),("--shard",slot)],
                [target/"HELDOUT_RAYLEIGH.pt"],
                [subspaces,audit_corpus,spectrum_lock,eigensol],950,slot)
    if len(jobs) != len({row["job_id"] for row in jobs}):
        raise ValueError("Duplicate D2 job")
    loads = {slot:0. for slot in HOSTS}
    scale = {"0": 1.55, "1": 1., "2": 1.}
    for job in sorted(jobs,key=lambda row:-row["estimated_seconds"]):
        slot = job.get("preferred_gpu")
        if slot is None:
            slot = min(HOSTS,key=lambda x:loads[x]+scale[x]*job["estimated_seconds"])
            job["preferred_gpu"] = slot
        loads[slot] += scale[slot]*job["estimated_seconds"]
    return dict(devices=HOSTS,jobs=jobs,phase=phase)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",required=True,type=Path)
    parser.add_argument("--phase",choices=("orientation","audit","score","sample"),required=True)
    parser.add_argument("--out",required=True,type=Path)
    args=parser.parse_args()
    spec=plan(args.root.resolve(),args.phase)
    if args.out.exists() and config_key(args.out)!=spec:
        raise ValueError("Existing D2 downstream dispatch cannot be replaced")
    save_json(args.out,spec)
    print("D2_DOWNSTREAM_PLAN",args.phase,len(spec["jobs"]),digest(args.out),flush=True)


if __name__=="__main__":
    main()

