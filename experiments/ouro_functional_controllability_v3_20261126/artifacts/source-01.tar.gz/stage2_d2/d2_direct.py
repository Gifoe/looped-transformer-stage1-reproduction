"""Exact streaming direct Fisher for a full-vocabulary RMSNorm-linear readout."""

import torch


class DirectFisher:
    """Accumulate G0 without calling an operator on each hidden basis vector."""

    def __init__(self, embedding, gain, epsilon, bias=None):
        self.rows = (embedding.detach() * gain.detach()).contiguous()
        self.epsilon = epsilon
        self.bias = None if bias is None else bias.detach()
        self.width = self.rows.shape[1]
        self.mass = self.rows.new_zeros(self.rows.shape[0], dtype=torch.float64)
        self.correction = self.rows.new_zeros((self.width, self.width), dtype=torch.float64)
        self.examples = 0

    @torch.no_grad()
    def add(self, hidden, alpha, chunk_size=48):
        hidden = hidden.reshape(-1, self.width)
        alpha = alpha.reshape(-1)
        if len(hidden) != len(alpha) or not len(hidden):
            raise ValueError("One scale is required per receiver position")
        for start in range(0, len(hidden), chunk_size):
            h = hidden[start:start+chunk_size].to(self.rows.dtype)
            a = alpha[start:start+chunk_size].to(self.rows.dtype)
            square = h.square().mean(1, keepdim=True) + self.epsilon
            inner = h @ self.rows.mT
            logits = inner * square.rsqrt()
            if self.bias is not None:
                logits += self.bias
            probabilities = logits.softmax(dim=-1)
            weight = a.square() / square.squeeze(-1) / len(hidden)
            self.mass += (weight[:, None] * probabilities).sum(0, dtype=torch.float64)

            mean = (probabilities @ self.rows).double()
            center = (probabilities * inner).sum(dim=1, keepdim=True)
            slope = ((probabilities * (inner - center)) @ self.rows).double()
            h = h.double()
            weight = weight.double()
            curvature = square.squeeze(-1).double().reciprocal() / self.width
            correction = h.mT @ ((weight * curvature)[:, None] * slope)
            tail = weight * curvature.square() * (h * slope).sum(1)
            self.correction += h.mT @ (tail[:, None] * h) - correction - correction.mT
            self.correction -= mean.mT @ (weight[:, None] * mean)
        self.examples += 1

    @torch.no_grad()
    def matrix(self):
        if self.examples == 0:
            raise ValueError("No positions were accumulated for the direct Fisher")
        weighted = self.mass.sqrt()[:, None] * self.rows.double()
        matrix = (weighted.mT @ weighted + self.correction) / self.examples
        return (matrix + matrix.mT) / 2
