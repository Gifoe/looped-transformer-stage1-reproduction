"""Report each empirical D2 hypothesis from its independent locked evidence."""
import argparse
import json
from pathlib import Path

from d2_worker import digest, load, save_json


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def close(root):
    required={
       "lock":"D2_SUBSPACE_LOCK.json","spectrum":"spectral/D2_SPECTRAL_AUDIT.json",
       "heldout":"D2_HELDOUT_RAYLEIGH.json","normality":"D2_NONNORMALITY_AUDIT.json",
       "coverage":"D2_T1_COVERAGE_AUDIT.json","score":"D2_ZERO_LABEL_EVAL.json",
       "sample":"D2_SAMPLE_EFFICIENCY.json","detail":"D2_FOLLOWUP_DETAIL.json",
       "physical_pairing":"D2_PHYSICAL_TRANSIENT_PAIRED_AUDIT.json",
       "physical_tails":"D2_PHYSICAL_TAIL_DIAGNOSTIC.json",
       "real_schur":"D2_REAL_SCHUR_AUDIT.json","spectral_cost":"D2_SPECTRAL_COST_SUMMARY.json",
       "pmi_mechanism":"D2_PMI_DECOMPOSITION.json",
       "zero_label_pairing":"D2_ZERO_LABEL_PAIRED.json","historical_pmi_generation":"D2_PMI_HISTORICAL_GENERATION.json",
       "matched_write_direction":"D2_MATCHED_WRITE_DIRECTION.json",
    }
    items={key:read(root/path) for key,path in required.items()}
    reference=root/"D2_REF_OPERATOR.pt"
    if items["lock"]["controller_sha256"]!=digest(reference) or items["heldout"]["n"]!=512:
        raise ValueError("Stage 2 requires the frozen reference and complete independent audit")
    response=items["heldout"]["groups"]
    paired=items["normality"]["full_vs_isolated_mu1"]
    e=items["spectrum"]["results"]["main"]
    if max(e["residuals"])>1e-3 or len(e["eigenvalues"])!=32:
        raise ValueError("The full-space generalized residuals are uncertified")
    import statistics
    held={key:statistics.median(value["regularized_ratios"][:16]) for key,value in response.items()}
    held_direct={key:statistics.median(value["direct_mean"][:16]) for key,value in response.items()}
    held_mediated={key:statistics.median(value["mediated_mean"][:16]) for key,value in response.items()}
    h21=held["fisher"]>max(1.,held["pca"],held["random"])
    normality=items["normality"]
    projected=normality["projected"]
    radius=max(abs(complex(*x)) for x in projected["eigenvalues"])
    spectral_gain=projected["singular_values"][0]/max(radius,1e-30)
    schur=items["real_schur"]
    spec_sha=digest(root/required["spectrum"])
    if (schur["spectral_audit_sha256"]!=spec_sha or items["spectral_cost"]["spectral_audit_sha256"]!=spec_sha
        or abs(schur["dep_F"]-normality["dep_F"])>1e-10
        or abs(schur["singular_over_spectral_radius"]-spectral_gain)>1e-10):
        raise ValueError("Real Schur verification and device cost must match the frozen fitted projection")
    actual=normality["transient_curve"]
    actual_advantage={k:actual["fisher"][str(k)]["state_amplification"]-
                          max(actual["pca"][str(k)]["state_amplification"],
                              actual["random"][str(k)]["state_amplification"])
                       for k in range(4,9)}
    h22=normality["dep_F"]>1e-3 and spectral_gain>1.01 and any(gain>0 for gain in actual_advantage.values())
    physical=items["physical_pairing"]
    if (physical["n"]!=64 or physical["transient_runner_receipt_sha256"]!=digest(root/"transients"/"D2_TRANSIENT_COMPLETE.json")
        or any(abs(physical["curves"][str(k)]["state_amplification"]["mean"]["fisher"]
                   -actual["fisher"][str(k)]["state_amplification"])>1e-12 for k in range(4,9))):
        raise ValueError("The physical paired audit differs from the complete powered transient run")
    physical_k6=physical["curves"]["6"]["state_amplification"]
    ci6=physical_k6["pairing"]["random"]["mean_paired_delta_ci95"]
    tail=items["physical_tails"]
    if tail["base_physical_audit_sha256"]!=digest(root/required["physical_pairing"]):
        raise ValueError("Tail statistics must bind the measured finite responses")
    k6_kl=tail["per_depth"]["6"]["symmetric_dose_kl"]["random"]
    score=items["score"]
    external=score["reference_external"]
    pmi=score["arms"]["U1_PMI"]["external"]
    zero_best=max(score["arms"],key=lambda arm:score["arms"][arm]["external"])
    zero_best_row=score["arms"][zero_best]
    zero_best_pair=items["zero_label_pairing"]["arms"][zero_best]["pairing"]
    zero_best_summary=dict(method=zero_best,external=zero_best_row["external"],
                           comparisons={base:zero_best_pair[base]["macro"] for base in ("native","t1")})
    pairing=items["zero_label_pairing"]["arms"]["U1_PMI"]["pairing"]
    ci_d2_native=pairing["native"]["macro"]["ci95_pp"]
    ci_d2_t1=pairing["t1"]["macro"]["ci95_pp"]
    decomposition=items["pmi_mechanism"]
    if decomposition["frozen_lock_sha256"]!=digest(root/required["lock"]):
        raise ValueError("Unlabelled PMI attribution must use the same frozen controller")
    pmi_terms=decomposition["variants"][decomposition["selected"]]["metrics"]
    true_score=pmi_terms["natural_context_delta_logp"]
    foil_score=pmi_terms["shuffled_context_delta_logp"]
    controls=items["matched_write_direction"]
    if controls["source_paired_score_sha256"]!=digest(root/required["zero_label_pairing"]):
        raise ValueError("Equal-dose direction contrasts must use these same paired outcomes")
    matched_direction={name:data["fixed_input_candidate_only_macro"]
                       for name,data in controls["paired_only_write_direction_changed"].items()}
    generation=items["historical_pmi_generation"]
    if generation["frozen_controller_lock_sha256"]!=digest(root/required["lock"]):
        raise ValueError("Historical free generation must bind the same no-label checkpoint")
    historical_generated={name:{arm:details["metrics"]["correct"] for arm,details in item["arms"].items()}
                          for name,item in generation["datasets"].items()}
    sample=items["sample"]
    small=sample["matched_cold_sample_ratio"]
    efficient={key:sorted(((x["ratio"],x["n"]) for x in rows if x["ratio"] is not None and x["n"]<=256),reverse=True)
               for key,rows in small.items()}
    deltas={key:100*(pmi-ref) for key,ref in external.items()}
    h23=dict(zero_label_better_than_native=deltas["native"]>0,
             zero_label_better_than_historical_t1=deltas["t1"]>0,unlabelled_pmi_terms=pmi_terms,
             paired_external_ci95_pp={"native":ci_d2_native,"t1":ci_d2_t1},
             strongest_observed_zero_label=zero_best_summary,
             historical_free_generation_correctness=historical_generated,
             fixed_input_direction_contrast_vs_random=matched_direction,
             anchored_sample_saving={key:(value[0] if value else None) for key,value in efficient.items()})
    stamp=dict(h21=dict(support=h21,heldout_top16_medians=held,max_residual=max(e["residuals"]),full_vs_isolated=paired,
                        heldout_top16_direct_medians=held_direct,heldout_top16_mediated_medians=held_mediated,
                        paired_document_bootstrap=items["heldout"]["paired_document_bootstrap"]),
               h22=dict(support=h22,dep_F=normality["dep_F"],leading_singular_over_spectral_radius=spectral_gain,
                        native_fisher_advantage=actual_advantage,k6_paired_physical_response=physical_k6),
               h23=h23,primary_external_delta_pp=deltas,files_sha256={p:digest(root/p) for p in required.values()})
    save_json(root/"D2_VERDICT.json",stamp)
    lines=["# D2 内禀控制子空间","",
           "## H2.1 循环介导的输出敏感性","",
           f"全序列共享归一写入的第一广义特征值为 {e['eigenvalues'][0]:.4f}，32 根特征对的最大数值残差为 {max(e['residuals']):.3g}。",
           f"512 段独立语料上，Fisher、PCA 和随机方向的前 16 项中位数分别为 {held['fisher']:.4f}、{held['pca']:.4f}、{held['random']:.4f}。当前数据{'支持' if h21 else '未支持'}方向敏感性判据。",
           f"对单位写入方向，Fisher、PCA、随机的直接读出敏感度中位数为 {held_direct['fisher']:.3g}、"
           f"{held_direct['pca']:.3g}、{held_direct['random']:.3g}，经原生末轮为 {held_mediated['fisher']:.3g}、"
           f"{held_mediated['pca']:.3g}、{held_mediated['random']:.3g}。",
           f"匹配输入和观察位置的首根谱值为全序列 {paired['full']:.4f}、孤立写入 {paired['isolated']:.4f}。","",
           "## H2.2 投影动力学与物理多轮响应","",
           f"实 Schur 分解下，投影算子的 Henrici 偏离度为 {schur['dep_F']:.4f}，最大奇异值与谱半径之比为 {spectral_gain:.4f}。",
           f"预先指定的 Fisher 方向在 K4–K8 中有 {sum(x>0 for x in actual_advantage.values())} 个深度超过两种方向对照。",
           f"64 段独立文本上，K6 的 Fisher、PCA 和随机方向平均状态放大为 {physical_k6['mean']['fisher']:.2f}、"
           f"{physical_k6['mean']['pca']:.2f} 和 {physical_k6['mean']['random']:.2f} 倍。Fisher 减随机方向的"
           f"平均差值为 {physical_k6['pairing']['random']['mean_paired_delta']:.2f} 倍，配对 95% CI [{ci6[0]:.2f}, {ci6[1]:.2f}]。",
           f"K6 的 Fisher 减随机方向 KL 差中位数为 {k6_kl['median_of_paired_differences']:.3g}。"
           f"单段文本贡献 KL 总差值的 {100*k6_kl['largest_differential_fraction_of_total']:.1f}%。",
           "Schur 审计描述的是指定投影。多轮有限扰动检验补充原生模型的传播证据。","",
           "## H2.3 零标签控制与监督样本效率","",
           f"零标签 PMI 控制器的五任务开发均分为 {100*pmi:.2f}%。相对 Native 改变 {deltas['native']:+.2f} 个百分点，相对历史 T1 改变 {deltas['t1']:+.2f} 个百分点。",
           f"对 Native 和 T1 的开发均分配对 95% CI 分别为 [{ci_d2_native[0]:+.2f}, {ci_d2_native[1]:+.2f}]"
           f" 与 [{ci_d2_t1[0]:+.2f}, {ci_d2_t1[1]:+.2f}] 个百分点。",
           f"冻结定向提高了真实与打乱上下文的对数概率差 {pmi_terms['difference_of_deltas']['mean']:+.2f} nats/token。"
           f"真实与打乱上下文各自变化为 {true_score['mean']:+.2f} 和 {foil_score['mean']:+.2f} nats/token。"
           f"真实上下文有 {true_score['n_negative']}/{decomposition['n_segments']} 段的目标对数概率下降。",
           f"原历史开发协议下，PMI 控制器的 ARC-C、CommonsenseQA、GSM8K 和 SQuAD 自由生成正确率为 "
           f"{100*historical_generated['arc_challenge__content']['pmi']:.2f}%、{100*historical_generated['csqa__content']['pmi']:.2f}%、"
           f"{100*historical_generated['gsm8k__gsm_process']['pmi']:.2f}% 和 {100*historical_generated['squad__span']['pmi']:.2f}%。",
           f"四个固定候选输入任务采用同一读入轴和相同写入剂量。相对随机写入方向，首个 Fisher 方向和"
           f"投影 Jacobian 主右奇异方向的均分分别改变 {matched_direction['ufr1_mean']['delta_pp']:+.2f} 和"
           f" {matched_direction['jacobian_right1']['delta_pp']:+.2f} 个百分点。",
           f"覆盖率与样本效率分别来自冻结后独立审计和 {sample['n_arms']} 个匹配训练臂。样本节省倍数按达到该开发分数的最小已测冷启动样本量计算。"]
    n_values=(8,16,32,64,128,256,1013)
    methods=("Full_Cold","UFR16_Proj","U1_PMI_Warm","PCA16_Proj","Rand16_Proj")
    lines.extend(["",f"八个零标签候选中，{zero_best} 的开发五任务均分最高，为 {zero_best_row['external']*100:.2f}%。"
                f"相对原生变化 {zero_best_pair['native']['macro']['delta_pp']:+.2f} 个百分点，"
                f"逐题配对 95% 区间 [{zero_best_pair['native']['macro']['ci95_pp'][0]:+.2f}, "
                f"{zero_best_pair['native']['macro']['ci95_pp'][1]:+.2f}]。该区间描述已观测最高分臂。",
                "", "| 方法 | "+" | ".join(map(str,n_values))+" |",
                "| --- | "+" | ".join(["---:"]*len(n_values))+" |"])
    for method in methods:
        points=[sample["groups"][f"{method}.{n}"] for n in n_values]
        cells=[f"{100*point['mean']:.2f} ± {100*point['std']:.2f}" for point in points]
        lines.append("| "+" | ".join([method,*cells])+" |")
    lines.extend(["", "表格为开发五任务等权准确率，单位为百分数，± 后为三个种子的样本标准差。",
                  "样本节省比采用离散训练规模的开发均值，2×、4×、8×逐点结果见 D2_FOLLOWUP_DETAIL.json。"])
    lines+=["","## 实测计算开销","",
            f"谱与投影共 87 个设备回执。按每张卡的本地请求至结果落盘区间取并集，累积 {items['spectral_cost']['device_hours']:.2f} GPU 小时。"
            "该口径包括区间内调度开销。后续定向、验证和监督曲线另有执行回执。"]
    path=root/"D2_REPORT.md"
    temp=path.with_suffix(".partial")
    temp.write_text("\n".join(lines)+"\n",encoding="utf-8")
    temp.replace(path)
    print("D2_STAGE_CLOSED",digest(root/"D2_VERDICT.json"),flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root",type=Path,required=True)
    close(p.parse_args().root)

