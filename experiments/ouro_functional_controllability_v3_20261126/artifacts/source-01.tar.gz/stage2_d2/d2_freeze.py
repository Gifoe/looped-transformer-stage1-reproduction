"""Freeze the no-label reference using the declared held-out text panel."""

import argparse
import json
from pathlib import Path

import torch

from d2_worker import digest, load, save_json, save_pt


def choose(args):
    measured, identity = {}, None
    for path in args.orientations:
        audit = path / "AUDIT.json"
        config = path / "CONFIG.json"
        weight = path / "controller.pt"
        result = json.loads(audit.read_text())
        settings = json.loads(config.read_text())
        checks = (settings["basis_sha256"], settings["fit_sha256"], settings["audit_sha256"])
        if checks[0] != digest(args.subspaces) or (identity is not None and checks != identity):
            raise ValueError("Orientation candidates did not use the same model-independent corpus and subspace")
        if len({str(row["id"]) for row in result["rows"]}) != 512 or len(result["rows"]) != 512:
            raise ValueError("An unlabelled validation population was incomplete")
        if result["weights_sha256"] != digest(weight):
            raise ValueError("Orientation controller receipt changed")
        name = (result["objective"], float(result["beta"]))
        if name in measured:
            raise ValueError(f"Duplicate orientation control: {name}")
        identity = checks
        measured[name] = dict(mean=result["mean"], weight=weight,
                              weight_sha256=digest(weight), audit_sha256=digest(audit), config_sha256=digest(config))

    primary = {key: row for key, row in measured.items() if key[0] == "pmi"}
    if set(primary) != {("pmi", 0.1), ("pmi", 0.3), ("pmi", 1.0)}:
        raise ValueError("All three no-label PMI choices must be evaluated before freezing")
    for control in ("entropy", "nll"):
        if sum(key[0] == control for key in measured) != 1:
            raise ValueError(f"A required unlabelled control was missing: {control}")
    chosen = max(primary, key=lambda key: (primary[key]["mean"]["net_pmi"], -primary[key]["mean"]["kl"], -key[1]))
    sensitivity={}
    for path in args.sensitivity:
        config=path/"CONFIG.json"
        audit=path/"AUDIT.json"
        weight=path/"controller.pt"
        settings=json.loads(config.read_text())
        measured_rank=int(settings["rank"])
        result=json.loads(audit.read_text())
        checks=(settings["basis_sha256"],settings["fit_sha256"],settings["audit_sha256"])
        if (checks!=identity or measured_rank not in (8,32) or str(measured_rank) in sensitivity
                or result["objective"]!="pmi" or float(result["beta"])!=0.3
                or result["weights_sha256"]!=digest(weight)
                or len({str(row["id"]) for row in result["rows"]})!=512 or len(result["rows"])!=512):
            raise ValueError("The unlabelled sensitivity check departed from its frozen inputs")
        sensitivity[str(measured_rank)]=dict(mean=result["mean"],config_sha256=digest(config),
                                            weights_sha256=digest(weight),audit_sha256=digest(audit))
    if set(sensitivity)!={"8","32"}:
        raise ValueError("Both preregistered unlabelled rank sensitivity checks are required")
    data = load(args.subspaces)
    net = load(measured[chosen]["weight"])["state"]
    u, w = net["out.weight"].flatten(), net["encode.weight"].flatten()
    basis = data["U_FR"][:, :16].to(u.dtype)
    error = (u - basis @ (basis.mT @ u)).norm() / u.norm().clamp_min(1e-30)
    if (error > 1e-5 or u.norm()*w.norm() > 4.50001) or not (u.isfinite().all() and w.isfinite().all()):
        raise ValueError("The chosen unlabelled write does not satisfy its subspace or dose bound")

    args.out.mkdir(parents=True, exist_ok=True)
    target = args.out / "D2_REF_OPERATOR.pt"
    lock = args.out / "D2_SUBSPACE_LOCK.json"
    report = dict(criterion="maximize held-out unlabelled net PMI, then minimize KL",
                  chosen=dict(objective=chosen[0], beta=chosen[1]),
                  subspace_sha256=identity[0], fit_sha256=identity[1], audit_sha256=identity[2],
                  restricted_write_relative_error=float(error),rank_sensitivity=sensitivity,
                  sources={f"{objective}_{beta}": {k: v for k, v in values.items() if k != "weight"}
                           for (objective, beta), values in measured.items()})
    if lock.exists():
        existing = json.loads(lock.read_text())
        if report != {k:v for k,v in existing.items() if k != "controller_sha256"} or existing["controller_sha256"] != digest(target):
            raise ValueError("The frozen no-label D2 reference cannot be changed")
        return
    controls = {f"{objective}_{beta}": load(record["weight"])["state"]
                for (objective, beta), record in measured.items()}
    save_pt(target, dict(U_FR_32=data["U_FR"], mu_32=data["mu"], U_PCA=data["U_PCA"], u_A0=u, w_A0=w,
                         state=net, no_label_controls=controls))
    save_json(lock, dict(**report, controller_sha256=digest(target)))
    print("D2_REFERENCE_FROZEN", chosen, digest(target), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--subspaces", type=Path, required=True)
    parser.add_argument("--orientations", type=Path, nargs="+", required=True)
    parser.add_argument("--sensitivity", required=True, type=Path, nargs=2)
    parser.add_argument("--out", type=Path, required=True)
    choose(parser.parse_args())


if __name__ == "__main__":
    main()
