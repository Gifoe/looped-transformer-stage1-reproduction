"""Exact block Fisher products with a shared primal and cached output probabilities."""

import torch
from torch.func import jvp, vjp, vmap


class RMSFisherReadout:
    def __init__(self, weight, gain, epsilon, bias=None):
        self.weight = (weight.detach() * gain.detach()).contiguous()
        self.epsilon = epsilon
        self.bias = None if bias is None else bias.detach()

    @torch.no_grad()
    def bind(self, state):
        width = state.shape[-1]
        h = state.reshape(-1, width)
        square = h.square().mean(-1, keepdim=True) + self.epsilon
        inv = square.rsqrt()
        factor = square.reciprocal() / width
        raw = (h @ self.weight.mT) * inv
        if self.bias is not None:
            raw = raw + self.bias
        probability = raw.softmax(dim=-1)
        return h, inv, factor, probability

    @torch.no_grad()
    def apply(self, cache, delta, head_chunk):
        h, inv, factor, p = cache
        size = delta.shape[0]
        width = h.shape[1]
        direction = delta.reshape(size, -1, width)
        trace = []
        for start in range(0, len(h), head_chunk):
            stop = start + head_chunk
            x, inv_r, c, prob = h[start:stop], inv[start:stop], factor[start:stop], p[start:stop]
            d = direction[:, start:stop]
            tangent = (d - x * (x*d).sum(-1, keepdim=True)*c) * inv_r
            logits = tangent @ self.weight.mT
            centered = (prob * logits).sum(-1, keepdim=True)
            gradient = (prob * (logits - centered)) @ self.weight
            pullback = (gradient - x * (x*gradient).sum(-1, keepdim=True)*c) * inv_r / len(h)
            trace.append(pullback)
        return torch.cat(trace, dim=1).reshape(delta.shape)


def fisher_blocks(transform, readout, received, scales, directions, positions=None, block=2, head_chunk=32):
    """Apply the full exact Fisher to [width, directions] in bounded batches."""
    zero = torch.zeros_like(directions[:, 0])

    def responds(shift):
        h = transform(received + scales * shift)
        return h if positions is None else h.index_select(-2, positions)

    base, transpose = vjp(responds, zero)
    reference = readout.bind(base)
    columns = []
    for index in range(0, directions.shape[1], block):
        batch = directions[:, index:index+block].mT.contiguous()
        tangents = vmap(lambda v: jvp(responds, (zero,), (v,))[1])(batch)
        cotangent = readout.apply(reference, tangents, head_chunk)
        moved = vmap(lambda row: transpose(row)[0])(cotangent)
        columns.append(moved.mT.detach())
    return torch.cat(columns, dim=1)
