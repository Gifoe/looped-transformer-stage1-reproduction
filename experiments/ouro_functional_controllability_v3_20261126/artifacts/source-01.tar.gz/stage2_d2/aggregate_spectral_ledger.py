import csv
from datetime import datetime
from hashlib import file_digest
import json
from pathlib import Path

stage=Path("stage2_d2")
sources=[stage/f"D2_SPECTRAL_DEVICE_COST_{owner}.json" for owner in ("old","dual")]
def digest(p):
    with p.open("rb") as data:
        return file_digest(data,"sha256").hexdigest()
evidence=[json.loads(x.read_text()) for x in sources]
assert len({x["spectral_audit_sha256"] for x in evidence})==1
slots=[slot for report in evidence for slot in report["slots"]]
assert [slot["logical_card"] for slot in slots]==[0,1,2]
rows=[]
stats={}
for slot in slots:
    rows.extend(slot["artifacts"])
    raw_intervals=sorted(tuple(datetime.fromisoformat(row[key]).timestamp()
            for key in ("incidence_time_utc","completed_utc")) for row in slot["artifacts"])
    intervals=[]
    for start,end in raw_intervals:
        if intervals and start<=intervals[-1][1]:
            intervals[-1]=(intervals[-1][0],max(end,intervals[-1][1]))
        else:
            intervals.append((start,end))
    seconds=sum(end-start for start,end in intervals)
    covered=[x["sampled_peak_mib"] for x in slot["artifacts"] if x["sampled_peak_mib"] is not None]
    stats[str(slot["logical_card"])]=dict(request_envelope_seconds=seconds,
                per_job_response_seconds_sum=slot["response_seconds_sum"],
                max_quantized_observed_memory_mib=max(covered,default=None),
                jobs_with_memory_samples=len(covered),total_jobs=slot["request_count"])
assert len(rows)==87
target=stage/"D2_SPECTRAL_GPU_LEDGER.tsv"
with target.with_suffix(".partial").open("w",encoding="utf-8",newline="") as stream:
    output=csv.DictWriter(stream,rows[0].keys(),delimiter="\t")
    output.writeheader()
    output.writerows(rows)
target.with_suffix(".partial").replace(target)
summary=stage/"D2_SPECTRAL_COST_SUMMARY.json"
data=dict(spectral_audit_sha256=evidence[0]["spectral_audit_sha256"],
          exp_cost_measurement="Union of local request-to-result intervals per GPU; includes in-interval dispatch overhead. Additional device phases are recorded separately.",
          device_hours=sum(x["request_envelope_seconds"] for x in stats.values())/3600,
          sources={p.name:digest(p) for p in sources},ledger_sha256=digest(target),devices=stats)
summary.with_suffix(".partial").write_text(json.dumps(data,sort_keys=True,indent=2)+"\n")
summary.with_suffix(".partial").replace(summary)
print("D2_SPECTRAL_GPU_COST_AGGREGATED",digest(summary),data["device_hours"],stats,flush=True)
