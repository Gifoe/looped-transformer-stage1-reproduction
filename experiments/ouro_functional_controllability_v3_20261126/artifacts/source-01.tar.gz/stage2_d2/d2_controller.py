"""Coordinate sharded no-label operators and certified generalized spectra."""

import argparse
from hashlib import sha256
import io
import json
from pathlib import Path
import time

import numpy as np
from scipy.linalg import schur
import torch

from d2_spectrum import spectrum, spectrum_family
from d2_worker import digest, load, parse_rows, save_json, save_pt


def wait_paths(paths, timeout):
    deadline = time.monotonic() + timeout
    while missing := [path for path in paths if not path.exists()]:
        if time.monotonic() >= deadline:
            raise TimeoutError(f"Timed out waiting for: {missing}")
        time.sleep(2)


class Exchange:
    def __init__(self, work, timeout, cards=3):
        self.work = work
        self.timeout = timeout
        self.cards = tuple(range(cards))
        self.inbox = work / "requests"
        self.inbox.mkdir(parents=True, exist_ok=True)

    def initial(self, corpus):
        paths = [self.work / f"gpu_{card}" / "DIRECT_FISHER.pt" for card in self.cards]
        crews = [self.work / f"gpu_{card}" / "READY.json" for card in self.cards]
        wait_paths(paths + crews, self.timeout)
        local = []
        for path, crew in zip(paths, crews, strict=True):
            stamp = json.loads(crew.read_text())
            part = load(path)
            if (stamp["corpus"] != corpus or digest(path) != stamp["direct_sha256"]
                    or stamp["n"] != part["n_examples"]):
                raise ValueError(f"The initial Fisher receipt disagrees with its shard at {crew}")
            local.append(part)
        examples = sum(part["n_examples"] for part in local)
        n = sum(part["n_positions"] for part in local)
        if examples != 1024 or not n:
            raise ValueError("The spectral worker pool did not cover the full declared text set")
        direct = {}
        for scale in ("normalized", "constant"):
            key = f"direct_{scale}"
            direct[scale] = sum(part[key] * part["n_examples"] for part in local) / examples
        mean = sum(part["conduct_sum"] for part in local) / n
        variance = sum(part["conduct_moment"] for part in local) / n - torch.outer(mean, mean)
        return direct, mean, variance

    def operator(self, kind, expected, normalized, vectors=None, ids=None, positions=0, basis=None):
        packet = dict(kind=kind, normalized=normalized, selected_positions=positions, ids=ids)
        if vectors is not None:
            packet["vectors"] = vectors.contiguous().cpu()
        if basis is not None:
            packet["basis"] = basis.contiguous().cpu()
        stream = io.BytesIO()
        torch.save(packet, stream)
        payload = stream.getvalue()
        check = sha256(payload).hexdigest()
        filename = f"{kind}_{check}.pt"
        path = self.inbox / filename
        if path.exists():
            if digest(path) != check:
                raise ValueError(f"Operator request changed at {path}")
        else:
            temporary = path.with_suffix(".partial")
            temporary.write_bytes(payload)
            temporary.replace(path)
        print("OPERATOR_REQUEST", kind, check, expected, flush=True)
        answers = [self.work / f"gpu_{card}" / "results" / filename for card in self.cards]
        wait_paths(answers, self.timeout)
        pieces = [load(path) for path in answers]
        n = sum(item["n"] for item in pieces)
        if n != expected or any(item["request_sha256"] != check for item in pieces):
            raise ValueError("An operator response used a different direction or corpus")
        out = sum(item["sum"] for item in pieces) / n
        if not out.isfinite().all():
            raise ValueError("A measured matrix product contained non-finite values")
        return out


def fit_one(exchange, direct, scale, gamma, rank, args, ids=None, positions=0, kind="loop"):
    count = 1024 if ids is None else len(ids)
    loop = lambda v: exchange.operator(kind, count, scale, v, ids=ids, positions=positions)
    return spectrum(loop, lambda v: direct @ v, direct.shape[0], float(direct.trace()), gamma,
                    rank=rank, iterations=args.iterations, residual_tolerance=args.residual,
                    normalizer_matrix=direct)


def transient_audit(exchange, bases, pca, ids=None):
    ufr = bases[:, :16]
    q = torch.linalg.qr(torch.cat((ufr, pca[:, :16]), dim=1), mode="reduced").Q
    width = q.shape[1]
    total = 1024 if ids is None else len(ids)
    matrix = exchange.operator("compression", total, True, torch.eye(width, dtype=q.dtype), ids=ids, basis=q)
    tr, _ = schur(matrix.numpy(), output="complex")
    eigenvalues, vec = np.linalg.eig(matrix.numpy())
    den = float(matrix.norm())
    dep = max(0.0, den ** 2 - float(np.abs(np.diag(tr)) @ np.abs(np.diag(tr)))) ** 0.5 / max(den, 1e-30)
    left, s, right_t = torch.linalg.svd(matrix)
    alignment = (left * right_t.mT).sum(0).abs().tolist()
    random = torch.Generator().manual_seed(26112625)
    columns = dict(fisher=ufr[:, 0], pca=pca[:, 0], random=q @ torch.randn(width, generator=random, dtype=q.dtype))
    curve = {}
    for name, direction in columns.items():
        initial = q.mT @ direction
        curve[name] = {str(k): float((torch.linalg.matrix_power(matrix, k) @ initial).norm() / initial.norm())
                       for k in (1, 2, 3, 4, 6, 8)}
    kappa = float(np.linalg.cond(vec))
    return dict(matrix=matrix, normality=dict(dep_f=dep, singular_values=s.tolist(), singular_alignment=alignment,
                eigenvalues=[[float(z.real), float(z.imag)] for z in eigenvalues],
                eigenvector_condition=kappa if np.isfinite(kappa) else None, projected_transient_curve=curve))


def run(args):
    if not 0 < args.subset <= 1024 or args.positions <= 0:
        raise ValueError("Open-loop position comparisons need a declared nonempty subset")
    args.out.mkdir(parents=True, exist_ok=True)
    exchange = Exchange(args.exchange, args.timeout)
    rows = parse_rows(args.fit)
    key = digest(args.fit)
    direct, mean, cov = exchange.initial(key)
    pca_values, axes = torch.linalg.eigh((cov + cov.mT) / 2)
    pca = axes.flip(1)[:, :32]
    selected = sorted((str(row["id"]) for row in rows),
                      key=lambda item: sha256(f"26112623:{item}".encode()).hexdigest())[:args.subset]

    parameters = dict(fit_sha256=key, rank=args.rank, iterations=args.iterations, residual=args.residual,
                      gamma=(.01, .1, 1.), constant_scale_gamma=.1, isolated_ids=selected,
                      isolated_positions=args.positions)
    lock = args.out / "SPECTRAL_PROTOCOL.json"
    if lock.exists() and json.loads(lock.read_text()) != json.loads(json.dumps(parameters)):
        raise ValueError("Existing spectral experiments cannot use a different configuration")
    save_json(lock, parameters)
    normalized = (("main", .1), ("normalized_reg_small", .01), ("normalized_reg_large", 1.))
    names = {gamma: args.out / f"spectrum_{name}.pt" for name, gamma in normalized}
    if not all(path.exists() for path in names.values()):
        operator = lambda v: exchange.operator("loop", 1024, True, v)
        matrix = direct["normalized"]
        solutions = spectrum_family(operator, lambda v: matrix @ v, matrix.shape[0], float(matrix.trace()),
                                 tuple(names), rank=args.rank, iterations=args.iterations,
                                 residual_tolerance=args.residual, normalizer_matrix=matrix)
        for gamma, measured in solutions.items():
            if not names[gamma].exists():
                save_pt(names[gamma], dict(values=measured.values, axes=measured.eigenvectors,
                        U=measured.orthonormal_basis, residuals=measured.residuals, cg_iterations=list(measured.cg_iterations)))
    configs = [(name, direct["normalized"], True, gamma, None, 0, "loop") for name, gamma in normalized]
    configs.append(("constant", direct["constant"], False, .1, None, 0, "loop"))
    matching = exchange.operator("direct", len(selected), True, ids=selected, positions=args.positions)
    configs.extend([("paired_full", matching, True, .1, selected, args.positions, "loop"),
                    ("paired_isolated", matching, True, .1, selected, args.positions, "isolation")])
    receipts = {}
    for name, matrix, scale, gamma, ids, positions, kind in configs:
        output = args.out / f"spectrum_{name}.pt"
        if not output.exists():
            measured = fit_one(exchange, matrix, scale, gamma, args.rank, args, ids, positions, kind)
            save_pt(output, dict(values=measured.values, axes=measured.eigenvectors, U=measured.orthonormal_basis,
                                 residuals=measured.residuals, cg_iterations=list(measured.cg_iterations)))
        part = load(output)
        receipts[name] = dict(sha256=digest(output), numerical_normalizer="dense_cholesky_on_analytic_G0",
                              eigenvalues=part["values"].tolist(),
                              residuals=part["residuals"].tolist(), cg_iterations=part["cg_iterations"])
    main = load(args.out / "spectrum_main.pt")
    audit = transient_audit(exchange, main["U"], pca, selected)
    save_pt(args.out / "FISHER_SUBSPACES.pt", dict(U_FR=main["U"], mu=main["values"], U_PCA=pca,
                                                 lambda_PCA=pca_values.flip(0)[:32], mean=mean, M_F=audit["matrix"]))
    save_json(args.out / "D2_SPECTRAL_AUDIT.json", dict(results=receipts, projected_dynamics=audit["normality"],
        subspaces_sha256=digest(args.out/"FISHER_SUBSPACES.pt"), protocol_sha256=digest(lock)))
    print("SPECTRAL_AUDIT_DONE", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("fit", "exchange", "out"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument("--timeout", type=int, default=21600)
    parser.add_argument("--rank", type=int, default=32)
    parser.add_argument("--iterations", type=int, default=6)
    parser.add_argument("--residual", type=float, default=1e-3)
    parser.add_argument("--subset", type=int, default=64)
    parser.add_argument("--positions", type=int, default=4)
    run(parser.parse_args())


if __name__ == "__main__":
    main()
