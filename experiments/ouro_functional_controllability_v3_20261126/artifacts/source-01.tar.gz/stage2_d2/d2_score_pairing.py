"""Pair every frozen zero-label D2 arm against Native and T1 on the development panel."""
import argparse
import json
from pathlib import Path

import numpy as np

from d1_stats import paired
from d2_audit_report import BASE_TASKS
from d2_worker import digest, save_json
from gpu_dispatch import canonical_hash


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def score_rows(directory,task,record):
    source=directory/f"{task}.jsonl"
    if digest(source)!=record["sha256"]:
        raise ValueError(f"Development prediction file changed: {source}")
    with source.open(encoding="utf-8") as stream:
        rows=[json.loads(line) for line in stream if line.strip()]
    if len(rows)!=record["rows"] or len({x["id"] for x in rows})!=len(rows):
        raise ValueError(f"Missing or repeated development questions: {source}")
    return rows


def binary(rows,key):
    return np.asarray([row["metrics"][key] for row in rows],dtype=bool)


def macro_bootstrap(difference,seed):
    random=np.random.default_rng(seed)
    distribution=[]
    for values in difference:
        fractions=np.asarray([np.mean(values==v) for v in (-1,0,1)])
        count=random.multinomial(len(values),fractions,size=10000)
        distribution.append((count[:,2]-count[:,0])/len(values))
    sample=np.mean(np.stack(distribution),axis=0)
    return dict(delta_pp=100*float(np.mean([v.mean() for v in difference])),
                ci95_pp=(100*np.quantile(sample,(.025,.975))).tolist())


def compare(control,reference,task,primary):
    b=reference
    a=control
    if [(r["id"],r["gold"]) for r in a]!=[(r["id"],r["gold"]) for r in b]:
        raise ValueError(f"The underlying question order or labels differ: {task}")
    before=binary(b,primary)
    after=binary(a,primary)
    summary=paired(before,after,seed=261126907)
    if task=="mmlu_pro_val":
        bp,ap=binary(b,"parseable"),binary(a,"parseable")
        summary["parseable"]=paired(bp,ap,seed=261126908)
        summary["legal_transitions"]={}
        for name,subset in (("both_legal",bp&ap),("lost_legal",bp&~ap),
                            ("gained_legal",~bp&ap),("neither_legal",~bp&~ap)):
            summary["legal_transitions"][name]=dict(n=int(subset.sum()),
                changes_correct=int(after[subset].sum()-before[subset].sum()),
                correct_before=int(before[subset].sum()),correct_after=int(after[subset].sum()))
    return summary,after.astype(np.int8)-before.astype(np.int8)


def main(work,e0):
    plan=read(work/"DOWNSTREAM_score.json")
    jobs=plan["jobs"]
    if len(jobs)!=8:
        raise ValueError("Exactly the eight preregistered no-label result arms are required")
    anchors={name:e0/"e0_external_dev"/name for name in ("native","t1")}
    inputs={}
    for name,folder in anchors.items():
        stamp=read(folder/"DEVELOPMENT.json")
        inputs[name]={task:score_rows(folder,task,stamp["predictions"][task]) for task in BASE_TASKS}
    results={}
    for job in jobs:
        receipt=read(Path(job["done_marker"]))
        output=Path(job["artifacts"][0])
        sha=digest(output)
        if receipt["config_sha256"]!=canonical_hash(job) or receipt["artifact_sha256"]!={str(output):sha}:
            raise ValueError(f"The raw predictions do not bind the preregistered D2 job: {job['job_id']}")
        arm=job["job_id"].rsplit(".",1)[1]
        data=read(output)
        candidate={task:score_rows(output.parent,task,data["predictions"][task]) for task in BASE_TASKS}
        matched={}
        for name,base in inputs.items():
            task_values={}
            differences=[]
            for task,metric in BASE_TASKS.items():
                task_values[task],margin=compare(candidate[task],base[task],task,metric)
                differences.append(margin)
            matched[name]=dict(tasks=task_values,macro=macro_bootstrap(differences,261126909))
        results[arm]=dict(pairing=matched,score_sha256=sha)
    out=work/"D2_ZERO_LABEL_PAIRED.json"
    save_json(out,dict(arms=results,population="fixed five-task complete common development panel",
                       primary="U1_PMI against Native and historical T1",
                       bootstrap_replicates=10000,comparison_scope_not_official_test=True,
                       dispatch_sha256=digest(work/"DOWNSTREAM_score.json")))
    print("D2_ZERO_LABEL_PAIRED_COMPLETE",digest(out),flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--work",required=True,type=Path)
    p.add_argument("--e0",required=True,type=Path)
    a=p.parse_args()
    main(a.work,a.e0)
