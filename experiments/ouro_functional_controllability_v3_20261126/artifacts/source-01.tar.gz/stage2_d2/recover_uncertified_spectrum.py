"""Resume only a numerical non-convergence using the same exact operator packets."""
import argparse
import functools
import json
from pathlib import Path
import sys

import d2_controller as controller
from d2_worker import digest, save_json


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--original-log",type=Path,required=True)
    p.add_argument("--audit",type=Path,required=True)
    p.add_argument("--refinement",type=int,default=24)
    args,flags=p.parse_known_args()
    if not 6<args.refinement<=30:
        p.error("Only a bounded increase in the convergence budget is allowed")
    log=args.original_log.read_text()
    if "Uncertified generalized Fisher spectrum: max residuals" not in log:
        raise ValueError("Automatic recovery applies only after the original residual criterion fails")
    marker=dict(original_log_sha256=digest(args.original_log),
                replacement_runner_sha256=digest(Path(__file__)),
                original_required_residual=1e-3,extension=args.refinement,
                original_data_or_operators_changed=False)
    if args.audit.exists() and json.loads(args.audit.read_text())!=marker:
        raise ValueError("The same resume cannot amend the existing continuation")
    save_json(args.audit,marker)
    original=controller.spectrum
    family=controller.spectrum_family
    controller.spectrum=functools.partial(original,refinement=args.refinement)
    controller.spectrum_family=functools.partial(family,refinement=args.refinement)
    sys.argv=[sys.argv[0],*flags]
    print("D2_SAME_OPERATOR_NUMERICAL_CONTINUATION",args.refinement,flush=True)
    controller.main()


if __name__=="__main__":
    main()

