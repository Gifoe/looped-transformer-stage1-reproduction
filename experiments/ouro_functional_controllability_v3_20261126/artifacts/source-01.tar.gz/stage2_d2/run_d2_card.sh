#!/usr/bin/env bash
set -eo pipefail
mode=$1
logical=$2
physical=$3
joint=/root/ouro-external-data-joint-training-20261124
root=/root/ouro-v3-controllability-20261126
cd "$joint"
source external_env.sh
cd "$root"
export CUDA_VISIBLE_DEVICES="$physical"
export OMP_NUM_THREADS=4
mkdir -p stage2_d2/logs stage2_d2/exchange locks
exec 8>"$root/locks/gpu_$logical.lock"
flock 8
if [[ "$mode" == serve ]]; then
    "$py" - "$logical" <<'E0_SLOT_GATE'
import json
from pathlib import Path
import sys
sys.path.insert(0,"tools")
from gpu_dispatch import canonical_hash, plan_jobs
logical=sys.argv[1]
placement=json.loads(Path("stage1_e0/DEVELOPMENT_DISPATCH.json").read_text())
pending=[]
for spec in plan_jobs(placement["jobs"],placement["devices"])[logical]:
    marker=Path(spec["done_marker"])
    if not marker.exists():
        pending.append(spec["job_id"])
        continue
    receipt=json.loads(marker.read_text())
    if (receipt["job_id"]!=spec["job_id"] or receipt["config_sha256"]!=canonical_hash(spec)
        or receipt["artifact_sha256"].keys()!=set(spec["artifacts"])):
        raise ValueError(f"Incomplete E0 evaluation receipt: {marker}")
if pending:
    raise SystemExit("Waiting E0 evaluation tasks must keep this GPU: "+", ".join(pending))
print("D2_E0_LOCAL_RELEASE_VERIFIED",logical,flush=True)
E0_SLOT_GATE
fi
checkpoint=58872a72616c736595b8b7662079c5b12c5a162ec16eae94f21c348dfa9885af
profile="stage2_d2/logs/PROFILE_$logical.json"
larger="stage2_d2/logs/PROFILE_LARGE_$logical.json"
if [[ ! -s "$profile" && ! -s "$larger" ]]; then
    "$py" -u stage2_d2/profile_large_blocks.py --model "$model" --model-sha256 "$checkpoint" \
       --length 384 --vectors 32 --blocks 4 8 16 32 --out "$larger"
fi
if [[ -s "$larger" ]]; then profile="$larger"; fi
size=$("$py" - "$profile" <<'PROFILE_READ'
import json
from pathlib import Path
import sys
profile=json.loads(Path(sys.argv[1]).read_text())
assert profile["synthetic"] and profile["tokens"]==384
print(int(profile["chosen_block"]))
PROFILE_READ
)
common=(--model "$model" --model-sha256 "$checkpoint" --fit stage0_env/UNLABELED_CORPUS/fit_unlabeled.jsonl \
        --out "stage2_d2/exchange/gpu_$logical" --shard "$logical" --nshards 3 --direction-block "$size")
if [[ "$mode" == prepare ]]; then common+=(--prepare-only); elif [[ "$mode" != serve ]]; then exit 2; fi
"$py" -u stage2_d2/d2_worker.py "${common[@]}"

