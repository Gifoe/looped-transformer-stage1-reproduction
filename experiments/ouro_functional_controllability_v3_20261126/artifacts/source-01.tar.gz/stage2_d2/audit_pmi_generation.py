"""Audit whether the frozen PMI arm still produces usable free-form answers."""
import json
from collections import Counter
from pathlib import Path

from d1_stats import paired
from d2_score_pairing import read,score_rows
from d2_worker import digest,save_json


root=Path("stage2_d2")
e0=Path("stage1_e0/e0_external_dev")
folders={"pmi":root/"no_label_dev/U1_PMI","native":e0/"native","t1":e0/"t1"}
tasks=("arc_challenge__content","csqa__content","squad__span","gsm8k__gsm_process")
reports={}
for task in tasks:
    panels={}
    metrics={}
    input_hash={}
    for name,folder in folders.items():
        manifest=read(folder/"DEVELOPMENT.json")["historical"]["predictions"][task]
        rows=score_rows(folder/"historical",task,manifest)
        panels[name]=rows
        prediction_counts=Counter(str(row["prediction"]).strip().casefold() for row in rows)
        measures={key:sum(float(row["metrics"][key]) for row in rows)/len(rows)
                  for key in ("correct","valid","strict") if all(key in row["metrics"] for row in rows)}
        tokens=[row["generated_tokens"] for row in rows]
        if not all(isinstance(value,(int,list)) for value in tokens):
            raise ValueError(f"Unsupported generation token record for {task}/{name}")
        token_cost=sum(len(value) if isinstance(value,list) else value for value in tokens)/len(rows)
        metrics[name]=dict(n=len(rows),metrics=measures,stop_reasons=dict(Counter(row["stop"] for row in rows)),
                           average_generated_tokens=token_cost,unique_casefolded_prediction_count=len(prediction_counts),
                           maximum_frequency_of_one_prediction=max(prediction_counts.values()))
        input_hash[name]=manifest["sha256"]
    pmi=panels["pmi"]
    matched={}
    for name in ("native","t1"):
        base=panels[name]
        if [(x["id"],x.get("label")) for x in pmi]!=[(x["id"],x.get("label")) for x in base]:
            raise ValueError(f"The matched historical generation identities differ: {task}/{name}")
        matched[name]=paired([r["metrics"]["correct"] for r in base],[r["metrics"]["correct"] for r in pmi])
    reports[task]=dict(arms=metrics,paired_correctness=matched,prediction_files_sha256=input_hash)
output=root/"D2_PMI_HISTORICAL_GENERATION.json"
save_json(output,dict(development_only=True,source_arms=list(folders),datasets=reports,
                      frozen_controller_lock_sha256=digest(root/"D2_SUBSPACE_LOCK.json")))
print("D2_PMI_HISTORICAL_GENERATION",digest(output),flush=True)
for task,entries in reports.items():
    print(task,{key:value["metrics"] for key,value in entries["arms"].items()},flush=True)
