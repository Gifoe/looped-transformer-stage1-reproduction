"""Measure orientation microbatch equivalence on the frozen Ouro GPU with synthetic tokens."""
import argparse
import time
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM
import transformers

from d2_orient import RankOne, expected_terms, expected_terms_batch
from d2_worker import digest,load,save_json


def main(args):
    want="58872a72616c736595b8b7662079c5b12c5a162ec16eae94f21c348dfa9885af"
    if digest(args.model/"model.safetensors")!=want:
        raise ValueError("The smoke test must use the sealed base")
    transformers.utils.import_utils._torchvision_available=False
    model=AutoModelForCausalLM.from_pretrained(args.model,torch_dtype=torch.bfloat16,attn_implementation="sdpa",
               local_files_only=True,trust_remote_code=True).to("cuda").eval().requires_grad_(False)
    model.model.total_ut_steps=4
    torch.backends.cuda.matmul.allow_tf32=False
    basis=load(args.axes)["U_FR"][:,:16]
    sample=torch.randint(100,15000,(2,320),generator=torch.Generator().manual_seed(261126904)).tolist()
    raw=[x[:240] for x in sample]
    foil=list(reversed(raw))
    truth=[x[240:] for x in sample]
    def run(batched):
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        start=time.perf_counter()
        write=RankOne(basis,26112624).cuda()
        if batched:
            s=expected_terms_batch(model,raw,foil,truth,write,True)
            ((-s["net_pmi"]+.3*s["kl"]).sum()/2).backward()
            sample_terms=s
        else:
            one=[expected_terms(model,raw[i],foil[i],truth[i],write,True) for i in range(2)]
            for state in one:
                ((-state["net_pmi"]+.3*state["kl"])/2).backward()
            sample_terms={name:torch.stack([state[name].detach() for state in one]) for name in one[0]}
        torch.cuda.synchronize()
        elapsed=time.perf_counter()-start
        return dict(terms={k:v.detach().cpu() for k,v in sample_terms.items()},
                    gradient=[v.grad.detach().cpu() for v in write.parameters()],
                    seconds=elapsed,peak_mib=torch.cuda.max_memory_allocated()/1024**2)
    run(True)
    serial=run(False)
    grouped=run(True)
    terms=max(float((serial["terms"][k]-grouped["terms"][k]).abs().max()) for k in serial["terms"])
    grad=[float((one-two).norm()/one.norm().clamp_min(1e-20)) for one,two in zip(serial["gradient"],grouped["gradient"],strict=True)]
    meta=dict(scope="synthetic vocabulary IDs, exact frozen Ouro, no fitted direction or QA data outputs",
              model_sha256=want,orientation_runner_sha256=digest(Path(__file__).with_name("d2_orient.py")),
              axes_sha256=digest(args.axes),n=2,tokens=320,training_dose=.45,max_abs_term_delta=terms,
              relative_grad_delta_per_parameter=grad,
              wall_seconds={name:rec["seconds"] for name,rec in (("serial",serial),("batched",grouped))},
              peak_allocated_mib={name:rec["peak_mib"] for name,rec in (("serial",serial),("batched",grouped))})
    save_json(args.out,meta)
    print("D2_REAL_GPU_ORIENTATION_SMOKE",digest(args.out),meta,flush=True)

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    for name in ("model","axes","out"):
        p.add_argument("--"+name,type=Path,required=True)
    main(p.parse_args())
