"""Decompose the frozen no-label PMI improvement into real and shuffled context effects."""
import json
from pathlib import Path

import numpy as np

from d2_worker import digest,parse_rows,save_json


work=Path("stage2_d2")
lock=work/"D2_SUBSPACE_LOCK.json"
frozen=json.loads(lock.read_text())
corpus=Path("stage0_env/UNLABELED_CORPUS/audit_unlabeled.jsonl")
if digest(corpus)!=frozen["audit_sha256"]:
    raise ValueError("The description must stay on the locked continuous-text audit")
texts=parse_rows(corpus)
ids=[r["id"] for r in texts]
documents={r["document_id"]:i for i,r in enumerate(
    {r["document_id"]:r for r in texts}.values())}
group=np.array([documents[r["document_id"]] for r in texts])
size=np.bincount(group)
if len(ids)!=512 or len(set(ids))!=512:
    raise ValueError("Incorrect no-label audit size")
rng=np.random.default_rng(261126906)
draws=rng.multinomial(len(size),np.full(len(size),1./len(size)),size=10000)
denominator=draws@size
effects={}
for key,stamp in frozen["sources"].items():
    ob,beta=key.split("_")
    path=work/"orientation"/f"{ob}_{beta}_rank16"/"AUDIT.json"
    if digest(path)!=stamp["audit_sha256"]:
        raise ValueError(f"Orientation receipt changed: {key}")
    item=json.loads(path.read_text())
    if [r["id"] for r in item["rows"]]!=ids:
        raise ValueError(f"Orientation audit was not paired: {key}")
    true=-np.array([row["delta_nll"] for row in item["rows"]])
    pmi=np.array([row["net_pmi"] for row in item["rows"]])
    controls=np.array([row["kl"] for row in item["rows"]])
    shuffled=true-pmi
    signal=np.stack((true,shuffled,pmi,controls),axis=1)
    by_doc=np.zeros((len(size),4))
    np.add.at(by_doc,group,signal)
    samples=(draws@by_doc)/denominator[:,None]
    labels=("natural_context_delta_logp","shuffled_context_delta_logp","difference_of_deltas","real_prediction_kl")
    report={}
    for index,metric in enumerate(labels):
        column=signal[:,index]
        report[metric]=dict(mean=float(column.mean()),median=float(np.median(column)),
                            n_positive=int((column>0).sum()),n_negative=int((column<0).sum()),
                            percentile_document_bootstrap_ci95=np.quantile(samples[:,index],(.025,.975)).tolist())
    effects[key]=dict(metrics=report,source_sha256=digest(path))
chosen=f"{frozen['chosen']['objective']}_{frozen['chosen']['beta']}"
out=work/"D2_PMI_DECOMPOSITION.json"
save_json(out,dict(n_segments=len(texts),n_documents=len(size),scope="unlabelled audit used for beta selection; intervals are conditional descriptions of frozen variants",
                  paired_estimand="Delta(log P) for real context minus Delta(log P) for shuffled context, nats per continuation token",
                  frozen_lock_sha256=digest(lock),selected=chosen,variants=effects,no_change_to_frozen_anchor=True))
print("D2_PMI_DECOMPOSITION",digest(out),json.dumps(effects[chosen]["metrics"]),flush=True)
