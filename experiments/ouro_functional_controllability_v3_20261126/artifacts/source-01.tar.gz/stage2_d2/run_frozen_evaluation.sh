#!/usr/bin/env bash
set -euo pipefail
host=$1
root=/root/ouro-v3-controllability-20261126
cd /root/ouro-external-data-joint-training-20261124
source external_env.sh
cd "$root"
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4
export PYTHONPATH="$root/stage2_d2:$root/stage1_e0/code:$root/tools:/root/ouro-loop-aware-functional-identification-20261125:$PYTHONPATH"
work="$root/stage2_d2"
case "$host" in old|dual) ;; *) exit 2;; esac
for phase in audit score sample; do
    "$py" -u "$work/d2_downstream.py" --root "$root" --phase "$phase" --out "$work/DOWNSTREAM_$phase.json"
done
"$py" - "$work" <<'D2_MERGE'
import json
from pathlib import Path
import sys
from d2_worker import save_json
root=Path(sys.argv[1])
parts=[json.loads((root/f"DOWNSTREAM_{phase}.json").read_text()) for phase in ("audit","score","sample")]
devices=parts[0]["devices"]
assert all(x["devices"]==devices for x in parts)
jobs=[job for part in parts for job in part["jobs"]]
assert len(jobs)==116 and len({x["job_id"] for x in jobs})==116
final=root/"DOWNSTREAM_FROZEN_EVALUATION.json"
spec={"devices":devices,"jobs":jobs}
if final.exists() and json.loads(final.read_text())!=spec:
    raise ValueError("The D2 followup plan is immutable")
if not final.exists():
    save_json(final,spec)
D2_MERGE
exec "$py" -u tools/gpu_dispatch.py --root "$root" --host "$host" --manifest "$work/DOWNSTREAM_FROZEN_EVALUATION.json"

