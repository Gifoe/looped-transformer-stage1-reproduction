"""Repair only D2 supervised sample identifiers and archive empty failed attempts."""
import argparse
from hashlib import sha256
import json
from pathlib import Path

from d2_worker import digest,save_json
from gpu_dispatch import canonical_hash


def read(path):
    return json.loads(path.read_text())


def main(root,host):
    work=root/"stage2_d2"
    original=work/"DOWNSTREAM_FROZEN_EVALUATION.json"
    fit_plan=work/"DOWNSTREAM_sample.json"
    phase=read(original)
    prior=read(fit_plan)
    if len(phase["jobs"])!=116 or len(prior["jobs"])!=105:
        raise ValueError("The pre-existing D2 design must be preserved")
    active=work/"d2_sample_efficiency.py"
    archive=active.with_name("d2_sample_efficiency.before_sample_id_fix.py")
    if not archive.exists():
        code=active.read_text()
        if code.count("row['id']")!=1 or code.count('row["id"]')!=1:
            raise ValueError("The expected two legacy ID accesses were not found")
        archive.write_bytes(active.read_bytes())
        fixed=code.replace("row['id']","row['sample_id']").replace('row["id"]','row["sample_id"]')
        replacement=active.with_suffix(".incoming")
        compile(fixed,str(active),"exec")
        replacement.write_text(fixed)
        replacement.replace(active)
    old,new=digest(archive),digest(active)
    if old==new:
        raise ValueError("The sample runner did not change")
    cfg=read(root/"stage1_e0/E0_CONFIG.json")
    declared=cfg["pools"]["arc_challenge"]
    source=Path(declared["path"])
    if digest(source)!=declared["sha256"]:
        raise ValueError("The frozen ARC sample population changed")
    with source.open() as reader:
        ids=[json.loads(line)["sample_id"] for line in reader if line.strip()]
    if len(ids)!=1013 or len(set(ids))!=1013:
        raise ValueError("The frozen sample split no longer has its 1,013 distinct items")
    prefixes={}
    for seed in (26112631,26112632,26112633):
        order=sorted(ids,key=lambda key:sha256(f"{seed}:{key}".encode()).hexdigest())
        prefixes[str(seed)]={str(n):sha256(json.dumps(order[:n],ensure_ascii=False).encode()).hexdigest()
                            for n in (8,16,32,64,128,256,1013)}
    edited=[]
    before={job["job_id"]:job for job in phase["jobs"]}
    prior_sample={job["job_id"]:job for job in prior["jobs"]}
    for job in phase["jobs"]:
        if job["job_id"] not in prior_sample:
            edited.append(job)
            continue
        if prior_sample[job["job_id"]]!=job or job["input_sha256"].get(str(active))!=old:
            raise ValueError("A supervised job differs from the original frozen design")
        edited.append(dict(job,input_sha256=dict(job["input_sha256"],**{str(active):new})))
    target=work/"DOWNSTREAM_FROZEN_EVALUATION_RECOVERY.json"
    packet=dict(phase,jobs=edited)
    if target.exists() and read(target)!=packet:
        raise ValueError("The recovered experiment manifest is immutable")
    save_json(target,packet)
    artifacts=work/"sample_efficiency"
    lock_archive=work/"recovery"/"pre_id_fix_job_configs"
    lock_archive.mkdir(parents=True,exist_ok=True)
    moved=[]
    for job in edited:
        label=job["job_id"]
        if label not in prior_sample: continue
        record=root/"locks"/f"{label}.config.json"
        if not record.exists(): continue
        current=read(record)["config_sha256"]
        if current==canonical_hash(job): continue
        if current!=canonical_hash(before[label]):
            raise ValueError(f"Unrecognized prior job identity: {label}")
        if Path(job["done_marker"]).exists():
            raise ValueError(f"Protect a completed job: {label}")
        folder=artifacts/label.removeprefix("d2.sample.")
        if folder.exists() and any(p.is_file() for p in folder.rglob("*")):
            raise ValueError(f"Protect existing training data for {label}")
        backup=lock_archive/record.name
        if backup.exists():
            raise ValueError(f"Prior recovery archive unexpectedly exists: {label}")
        recorded=digest(record)
        record.replace(backup)
        moved.append({"job_id":label,"old_config_sha256":recorded})
    audit=work/"D2_SAMPLE_RECOVERY.json"
    save_json(audit,dict(original_manifest_sha256=digest(original),replacement_manifest_sha256=digest(target),
             corrected_training_module=str(active),prior_runner_sha256=old,replacement_runner_sha256=new,
             unchanged_jobs=11,changed_only_runner_digest_jobs=105,frozen_source_sha256=digest(source),
             sample_identifiers="sample_id",same_training_sequences_steps_and_devices=True,n=1013,nested_prefix_sha256=prefixes))
    save_json(work/f"D2_SAMPLE_RECOVERY_{host}_ATTEMPTS.json",dict(host=host,archived_empty_job_configs=moved,receipt_sha256=digest(audit)))
    pilot=next(j for j in edited if j["preferred_gpu"]=="0" and j["job_id"].startswith("d2.sample.Full_Cold."))
    save_json(work/"DOWNSTREAM_FROZEN_EVALUATION_RECOVERY_PILOT.json",dict(devices=packet["devices"],jobs=[pilot]))
    print("D2_SAMPLE_RECOVERED_PLAN",host,digest(target),"prior_configs",len(moved),"pilot",pilot["job_id"],flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root",type=Path,required=True)
    p.add_argument("--host",choices=("old","dual"),required=True)
    a=p.parse_args()
    main(a.root,a.host)
