"""Validate exact block Fisher products on the locked model before large operators."""

import argparse
from pathlib import Path
import time

import torch
from torch.nn.attention import SDPBackend, sdpa_kernel

from d2_block import RMSFisherReadout, fisher_blocks
from d2_operator import capture, fisher_matvec, one_loop, readout, write_scales
from d2_worker import model_load, save_json


def run(args):
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    model, tokenizer = model_load(args)
    example = "A deterministic synthetic sentence for the CUDA environment derivative probe."
    parts = tokenizer.encode(example, add_special_tokens=False)
    filled = (parts * (1 + args.length//len(parts)))[:args.length]
    ids = torch.tensor([filled], dtype=torch.long, device="cuda")
    rng = torch.Generator(device="cuda").manual_seed(26112620)
    vectors = torch.randn(model.config.hidden_size, args.vectors, device="cuda", generator=rng)
    vectors = vectors / vectors.norm(dim=0)
    norm = model.model.norm
    results = {}
    with sdpa_kernel(SDPBackend.MATH):
        receiver = capture(model, ids)
        def physical(h):
            return one_loop(model, receiver, h)
        def head(h):
            return readout(model, h)
        alpha = write_scales(receiver.pre_loop, normalize=True)
        fisher_matvec(physical, head, receiver.pre_loop, alpha, vectors[:, 0])
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        start = time.perf_counter()
        reference = torch.stack([fisher_matvec(physical, head, receiver.pre_loop, alpha, vector)
                           for vector in vectors.T], dim=1)
        torch.cuda.synchronize()
        results["single"] = dict(wall_seconds=time.perf_counter()-start, peak_bytes=torch.cuda.max_memory_allocated())
        decoded = RMSFisherReadout(model.lm_head.weight, norm.weight, norm.variance_epsilon, model.lm_head.bias)
        for blocks in args.blocks:
            vals = []
            try:
                fisher_blocks(physical, decoded, receiver.pre_loop, alpha, vectors[:, :2], block=2)
                for _ in range(2):
                    torch.cuda.synchronize()
                    torch.cuda.reset_peak_memory_stats()
                    start = time.perf_counter()
                    study = fisher_blocks(physical, decoded, receiver.pre_loop, alpha, vectors, block=blocks)
                    torch.cuda.synchronize()
                    delta = ((reference-study).norm(dim=0) / reference.norm(dim=0).clamp_min(1e-20)).max()
                    vals.append(dict(wall_seconds=time.perf_counter()-start,
                                     peak_bytes=torch.cuda.max_memory_allocated(), relative_error=float(delta)))
                results[str(blocks)] = {"runs": vals}
            except (torch.cuda.OutOfMemoryError, RuntimeError) as error:
                results[str(blocks)] = {"error": str(error)[:500]}
                torch.cuda.empty_cache()
    eligible = {"1": results["single"]["wall_seconds"]}
    for key, result in results.items():
        if "runs" in result and max(row["relative_error"] for row in result["runs"]) <= 1e-3:
            if max(row["peak_bytes"] for row in result["runs"]) < 20 * 2**30:
                eligible[key] = min(row["wall_seconds"] for row in result["runs"])
    chosen = min(eligible, key=eligible.get)
    info = dict(tokens=args.length, directions=args.vectors, precision="float32", device=torch.cuda.get_device_name(),
                synthetic=True, variants=results, chosen_block=int(chosen))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    save_json(args.out, info)
    print("D2_BLOCK_PROBE", info, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True, type=Path)
    parser.add_argument("--model-sha256", required=True)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--length", type=int, default=320)
    parser.add_argument("--vectors", type=int, default=4)
    parser.add_argument("--blocks", type=int, nargs="+", default=(2,4))
    run(parser.parse_args())


if __name__ == "__main__":
    main()

