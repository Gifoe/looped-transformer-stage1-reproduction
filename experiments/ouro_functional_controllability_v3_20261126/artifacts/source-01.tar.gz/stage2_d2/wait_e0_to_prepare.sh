#!/usr/bin/env bash
set -eo pipefail
slot=$1
physical=$2
mark=$3
fit_pid=$4
cd /root/ouro-v3-controllability-20261126
while [[ ! -s "$mark" ]]; do
    if ! ps -p "$fit_pid" -o stat= | grep -q '^[DRSTI]'; then
        printf 'Previous E0 worker stopped without %s\n' "$mark" >&2
        exit 4
    fi
    sleep 5
done
printf 'D2_PREPARE_ENTER %s %s\n' "$slot" "$(date -Is)"
bash stage2_d2/run_d2_card.sh prepare "$slot" "$physical"
printf 'D2_PREPARE_DONE %s %s\n' "$slot" "$(date -Is)"
