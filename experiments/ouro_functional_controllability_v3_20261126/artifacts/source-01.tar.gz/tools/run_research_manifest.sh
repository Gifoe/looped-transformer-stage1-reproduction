#!/usr/bin/env bash
set -euo pipefail
stage=$1
host=$2
manifest=$3
root=/root/ouro-v3-controllability-20261126
joint=/root/ouro-external-data-joint-training-20261124
ident=/root/ouro-loop-aware-functional-identification-20261125
transfer=/root/ouro-cross-model-functional-controllability-20261125
feedback=/root/ouro-minimal-functional-feedback-20261123
cd "$joint"
source external_env.sh
cd "$root"
manifest=$(realpath -- "$manifest")
case "$manifest" in "$root"/*) ;; *) exit 2;; esac
case "$host" in old|dual) ;; *) exit 2;; esac
test -s stage0_env/ENV_MANIFEST.json
test -s stage1_e0/E0_VERDICT.json
test -s stage2_d2/D2_SUBSPACE_LOCK.json
case "$stage" in
   d1) [[ "$manifest" == "$root/stage3_d1/"* ]]; test -s stage2_d2/D2_VERDICT.json ;;
   d3) [[ "$manifest" == "$root/stage4_d3/"* ]] ;;
   d6) [[ "$manifest" == "$root/stage5_d6/"* ]] ;;
   d45)
       [[ "$manifest" == "$root/stage6_d45/"* ]]
       test -s stage3_d1/D1_PROTOCOL_VERDICT.json
       test -s stage4_d3/D3_VERDICT.json
       ;;
   *) exit 2 ;;
esac
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4
export PYTHONPATH="$root/stage1_e0/code:$root/stage2_d2:$root/stage3_d1:$root/stage4_d3:$root/stage5_d6:$root/stage6_d45:$root/tools:$ident:$transfer:$feedback:$feedback/generation_followup:/root/ouro-unified-rank1-20261123:$PYTHONPATH"
exec "$py" -u tools/gpu_dispatch.py --root "$root" --host "$host" --manifest "$manifest"

