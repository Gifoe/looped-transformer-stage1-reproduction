#!/usr/bin/env python3
"""Dispatch a frozen research manifest locally on the selected cluster host."""

import argparse
import concurrent.futures
import csv
from datetime import datetime, timezone
import fcntl
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import time


LEDGER_FIELDS = ("timestamp_start", "timestamp_end", "wall_sec", "gpu_id", "job_id",
                 "exit_code", "done_marker", "sha256", "peak_device_mib")


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def canonical_hash(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def within(root, name):
    path = (root / name).resolve()
    if not path.is_relative_to(root) or path == root:
        raise ValueError(f"Artifact escapes the study directory: {name}")
    return path


def write_marker(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as temp:
        json.dump(value, temp, ensure_ascii=False, sort_keys=True, indent=2)
        temp.write("\n")
        temp.flush()
        os.fsync(temp.fileno())
    os.replace(temp.name, path)


def append_ledger(root, row):
    path = root / "GPU_LEDGER.tsv"
    with path.open("a+", encoding="utf-8", newline="") as stream:
        fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
        stream.seek(0, os.SEEK_END)
        writer = csv.writer(stream, delimiter="\t")
        if stream.tell() == 0:
            writer.writerow(LEDGER_FIELDS)
        writer.writerow(row)


def plan_jobs(jobs, devices):
    queues = {card: [] for card in devices}
    loads = {card: 0.0 for card in devices}
    identifiers = set()
    marker_paths = set()
    for job in jobs:
        name = job["job_id"]
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", name) or name in identifiers:
            raise ValueError(f"Invalid or duplicate job id: {name}")
        identifiers.add(name)
        marker = job["done_marker"]
        if marker in marker_paths:
            raise ValueError(f"Multiple jobs write the same completion marker: {marker}")
        marker_paths.add(marker)
        duration = float(job.get("estimated_seconds", 1.0))
        chosen = job.get("preferred_gpu")
        if chosen is None:
            chosen = min(devices, key=lambda card: (loads[card], card))
        else:
            chosen = str(chosen)
        if chosen not in devices:
            raise ValueError(f"Unknown preferred GPU {chosen} for {name}")
        if not isinstance(job["cmd"], list) or not job["cmd"] or not all(isinstance(arg, str) for arg in job["cmd"]):
            raise TypeError(f"cmd must be an argument list for {name}")
        if duration <= 0:
            raise ValueError(f"Estimated duration must be positive for {name}")
        overrides = job.get("env_overrides", {})
        if "CUDA_VISIBLE_DEVICES" in overrides:
            raise ValueError(f"{name} attempted to override the assigned GPU")
        loads[chosen] += duration
        queues[chosen].append(job)
    return queues


def peak_candidate(device):
    try:
        probe = subprocess.run(["nvidia-smi", "-i", str(device), "--query-gpu=memory.used",
                                "--format=csv,noheader,nounits"], check=False, capture_output=True,
                               text=True, timeout=3)
        if probe.returncode == 0:
            return int(probe.stdout.strip())
    except (OSError, subprocess.TimeoutExpired, ValueError):
        pass
    return None


def run_job(root, job, card, device, cuda_metrics):
    marker = within(root, job["done_marker"])
    artifacts = {name: within(root, name) for name in job.get("artifacts", ())}
    request_hash = canonical_hash(job)
    request_path = root / "locks" / f"{job['job_id']}.config.json"
    if request_path.exists() and read(request_path)["config_sha256"] != request_hash:
        raise ValueError(f"Refusing to resume a changed job configuration: {job['job_id']}")
    for name, expected in job.get("input_sha256", {}).items():
        if digest(within(root, name)) != expected:
            raise ValueError(f"Input {name} changed for {job['job_id']}")
    if marker.exists():
        receipt = read(marker)
        if receipt["config_sha256"] != request_hash:
            raise ValueError(f"Configuration drift for {job['job_id']} at {marker}")
        if receipt["artifact_sha256"] != {name: digest(path) for name, path in artifacts.items()}:
            raise ValueError(f"Previously completed artifacts changed for {job['job_id']}")
        print("REUSED", card, job["job_id"], flush=True)
        return

    if not request_path.exists():
        write_marker(request_path, dict(config_sha256=request_hash))
    output = within(root, job["log_path"])
    output.parent.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.update(job.get("env_overrides", {}))
    env["CUDA_VISIBLE_DEVICES"] = str(device)
    env["OURO_V3_LOGICAL_GPU"] = card
    env["OURO_V3_ROOT"] = str(root)
    start = utc()
    begin = time.monotonic()
    peak = None
    code = -1
    try:
        with output.open("a", encoding="utf-8", buffering=1) as log:
            log.write(f"\n[{start}] {job['job_id']} config_sha256={request_hash} logical_gpu={card}\n")
            print("START", card, job["job_id"], flush=True)
            with subprocess.Popen(job["cmd"], cwd=root, env=env, stdin=subprocess.DEVNULL,
                                  stdout=log, stderr=subprocess.STDOUT) as worker:
                while worker.poll() is None:
                    used = peak_candidate(device) if cuda_metrics else None
                    if used is not None:
                        peak = used if peak is None else max(peak, used)
                    try:
                        worker.wait(timeout=1.0)
                    except subprocess.TimeoutExpired:
                        continue
                if worker.returncode:
                    code = worker.returncode
                    raise subprocess.CalledProcessError(code, job["cmd"])
        elapsed = time.monotonic() - begin
        checks = {name: digest(path) for name, path in artifacts.items()}
        write_marker(marker, dict(job_id=job["job_id"], config_sha256=request_hash, artifact_sha256=checks,
                                  logical_gpu=card, physical_gpu=device, started_utc=start, ended_utc=utc(),
                                  wall_seconds=elapsed, peak_device_mib=peak))
        code = 0
        print("DONE", card, job["job_id"], f"{elapsed:.2f}s", flush=True)
    finally:
        stamp = digest(marker) if code == 0 else ""
        append_ledger(root, (start, utc(), f"{time.monotonic()-begin:.3f}", card, job["job_id"], code,
                             str(marker.relative_to(root)), stamp, "" if peak is None else peak))


def run_card(root, card, device, jobs, cuda_metrics):
    lock = root / "locks" / f"gpu_{card}.lock"
    lock.parent.mkdir(parents=True, exist_ok=True)
    failures = []
    with lock.open("a") as stream:
        fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
        for job in jobs:
            try:
                run_job(root, job, card, device, cuda_metrics)
            except (subprocess.CalledProcessError, OSError, ValueError) as error:
                print("FAILED", card, job["job_id"], error, flush=True)
                failures.append(job["job_id"])
    return failures


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--host", required=True)
    parser.add_argument("--disable-device-metrics", action="store_true")
    parser.add_argument("--plan", action="store_true")
    args = parser.parse_args()
    setup = read(args.manifest)
    devices = setup["devices"]
    queues = plan_jobs(setup["jobs"], devices)
    local = {card: spec["local_index"] for card, spec in devices.items() if spec["host"] == args.host}
    if not local:
        raise ValueError(f"No GPUs match host {args.host}")
    if args.plan:
        for card, queue in queues.items():
            print(card, devices[card]["host"], " ".join(job["job_id"] for job in queue))
        return 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(local)) as workers:
        tasks = [workers.submit(run_card, args.root.resolve(), card, device, queues[card],
                                not args.disable_device_metrics) for card, device in local.items()]
        return int(any([future.result() for future in tasks]))


if __name__ == "__main__":
    raise SystemExit(main())
