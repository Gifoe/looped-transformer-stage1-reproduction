"""Merge per-host execution ledgers and known GPU intervals without double counting."""

import argparse
import csv
from collections import defaultdict
from dataclasses import asdict, dataclass
from datetime import datetime
from hashlib import file_digest
import json
from pathlib import Path
import re
from tempfile import NamedTemporaryFile


HOST_CARDS = {"old": {"0"}, "dual": {"1", "2"}}
DIGEST = re.compile(r"^[0-9a-f]{64}$")


@dataclass(frozen=True)
class Interval:
    stage: str
    kind: str
    host: str
    gpu: str
    job: str
    start_utc: str
    end_utc: str
    measured_seconds: float
    peak_mib: int | None
    exit_code: int
    receipt: str
    receipt_sha256: str


def sha(path):
    with path.open("rb") as source:
        return file_digest(source, "sha256").hexdigest()


def timestamp(value):
    result = datetime.fromisoformat(value)
    if result.tzinfo is None:
        raise ValueError(f"Expected a timezone-qualified measurement instant: {value}")
    return result


def optional_int(value):
    return int(value) if value else None


def read_dispatch(host, path):
    with path.open(encoding="utf-8", newline="") as source:
        return [
            Interval(r["job_id"].split(".", 1)[0], "dispatcher", host, r["gpu_id"], r["job_id"],
                     r["timestamp_start"], r["timestamp_end"], float(r["wall_sec"]),
                     optional_int(r["peak_device_mib"]), int(r["exit_code"]), r["done_marker"], r["sha256"])
            for r in csv.DictReader(source, delimiter="\t")
        ]


def host_for(slot):
    return next(host for host, cards in HOST_CARDS.items() if slot in cards)


def read_spectral(path):
    with path.open(encoding="utf-8", newline="") as source:
        return [
            Interval("d2", "spectral_request_envelope", host_for(r["logical_slot"]),
                     r["logical_slot"], r["kind"] + "." + r["request_sha256"],
                     r["incidence_time_utc"], r["completed_utc"], float(r["request_to_result_wall_seconds"]),
                     optional_int(r["sampled_peak_mib"]), 0, path.name, r["result_sha256"])
            for r in csv.DictReader(source, delimiter="\t")
        ]


def physical(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    return Interval("d2", "manual_prefetch", "old", "0", "d2.physical_transient", data["start_utc"],
                    data["complete_utc"], data["elapsed_including_load_sec"],
                    data["reported_peak_device_mib_sample"], 0, path.name, data["complete_receipt_sha256"])


def bounds(rows):
    start_stop = sorted((timestamp(row.start_utc), timestamp(row.end_utc)) for row in rows)
    windows = []
    for start, stop in start_stop:
        if windows and start <= windows[-1][1]:
            windows[-1] = (windows[-1][0], max(windows[-1][1], stop))
        else:
            windows.append((start, stop))
    return sum((stop - start).total_seconds() for start, stop in windows)


def validate(entries):
    formal_successes = set()
    for item in entries:
        if item.gpu not in HOST_CARDS[item.host]:
            raise ValueError(f"Unexpected device placement for {item.job}")
        if (timestamp(item.end_utc) < timestamp(item.start_utc) or item.measured_seconds < 0
                or (item.exit_code == 0 and not DIGEST.fullmatch(item.receipt_sha256))):
            raise ValueError(f"Invalid timing or receipt checksum for {item.job}")
        if item.kind == "dispatcher" and item.exit_code == 0:
            if item.job in formal_successes:
                raise ValueError(f"Multiple successful executions for one frozen job: {item.job}")
            formal_successes.add(item.job)


def summarize(rows):
    windows = defaultdict(list)
    for row in rows:
        windows[row.gpu].append(row)
    return {
        "attempts": len(rows),
        "failures": sum(row.exit_code != 0 for row in rows),
        "known_union_device_hours": sum(bounds(items) for items in windows.values()) / 3600,
        "sum_observed_job_hours": sum(row.measured_seconds for row in rows) / 3600,
        "peak_gpu_mib_sampled": max((row.peak_mib for row in rows if row.peak_mib is not None), default=None),
        "attempts_with_memory_samples": sum(row.peak_mib is not None for row in rows),
        "per_gpu": {
            gpu: {"attempts": len(items), "known_union_seconds": bounds(items)}
            for gpu, items in sorted(windows.items())
        }
    }


def atomic(path, write):
    with NamedTemporaryFile(mode="w", encoding="utf-8", newline="", dir=path.parent,
                            delete=False) as temp:
        write(temp)
        staged=Path(temp.name)
    try:
        staged.replace(path)
    finally:
        staged.unlink(missing_ok=True)


def build(args):
    inputs = [args.old, args.dual, args.spectral, args.transient, args.rayleigh_prefix, args.rayleigh_tail]
    identity = {name: sha(path) for name, path in zip(
        ("dispatcher_old", "dispatcher_dual", "d2_spectral", "d2_physical",
         "d2_rayleigh_prefix", "d2_rayleigh_tail"), inputs, strict=True
    )}
    rows = sorted(set(read_dispatch("old", args.old) + read_dispatch("dual", args.dual)
                      + read_spectral(args.spectral) + [physical(args.transient)]),
                  key=lambda item: (timestamp(item.start_utc), item.gpu, item.job))
    validate(rows)
    before = json.loads(args.rayleigh_prefix.read_text(encoding="utf-8"))
    tail = json.loads(args.rayleigh_tail.read_text(encoding="utf-8"))
    if (before["rows_saved"] + tail["remaining_rows_measured"] != tail["total_rows"]
            or before["protocol_sha256"] != tail["lock_sha256"]):
        raise ValueError("The manual held-out Rayleigh prefetch does not match the resumed shard")
    args.out.mkdir(parents=True, exist_ok=True)
    output = args.out / "GPU_LEDGER.tsv"

    def write(output_file):
        table = csv.DictWriter(output_file, fieldnames=list(Interval.__dataclass_fields__), delimiter="\t")
        table.writeheader()
        table.writerows(asdict(row) for row in rows)

    atomic(output, write)
    manifest = {
        "inputs_sha256": identity,
        "gpu_ledger_sha256": sha(output),
        "all_known_intervals": summarize(rows),
        "per_stage": {
            stage: summarize([row for row in rows if row.stage == stage])
            for stage in sorted({row.stage for row in rows})
        },
        "d2_additional_prefetch_without_absolute_window": {
            "host": "old", "gpu": "0",
            "rayleigh_prefix_elapsed_seconds": before["wall_before_original_service_resumed_seconds"],
            "rayleigh_tail_elapsed_seconds": tail["finish_elapsed_including_gpu_load_sec"],
            "included_in_window_union": False
        },
        "scope": "Reserved device windows measured by the dispatcher, sampled spectral request envelopes and documented prefetch. Spectral response intervals may contain dispatch time. GPU occupancy and kernel time are separate measures.",
    }
    atomic(args.out / "GPU_COST_SUMMARY.json",
           lambda out: out.write(json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n"))
    print("V3_GPU_LEDGER_VERIFIED", len(rows), manifest["gpu_ledger_sha256"], flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    for field in ("old", "dual", "spectral", "transient", "rayleigh-prefix", "rayleigh-tail", "out"):
        p.add_argument(f"--{field}", type=Path, required=True)
    build(p.parse_args())
