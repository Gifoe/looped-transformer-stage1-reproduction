"""Package immutable completed stages of the Ouro v3 research for GitHub."""
import argparse
from datetime import datetime, timezone
import gzip
from hashlib import file_digest
import json
from pathlib import Path
import re
import shutil
import tarfile


STAGES = {
    "stage0_env": ("ENV_MANIFEST.json", "PREFLIGHT_REPORT.md", "AUDIT_DEV_LEAKAGE.json",
                   "DATA_POSTVERIFY.json", "DATA_INPUTS.json", "data_draft/DATA_DRAFT_MANIFEST.json"),
    "stage1_e0": ("E0_REPORT.md", "E0_VERDICT.json", "E0_OUTPUT_SHA256.json", "E0_ANOVA_TABLE.json",
                  "E0_EXTERNAL_PAIRED_RECHECK.json", "E0_FACTORIAL_PAIRED_DIAGNOSTIC.json",
                  "E0_CONFIG.json", "E0_RAW_RESULTS.json", "GPU_LEDGER.tsv"),
    "stage2_d2": ("D2_REPORT.md", "D2_VERDICT.json", "D2_HELDOUT_RAYLEIGH.json", "D2_SAMPLE_EFFICIENCY.json",
                  "D2_ZERO_LABEL_EVAL.json", "D2_ZERO_LABEL_PAIRED.json", "D2_SUBSPACE_LOCK.json",
                  "D2_PMI_DECOMPOSITION.json", "D2_NONNORMALITY_AUDIT.json", "D2_MATCHED_WRITE_DIRECTION.json",
                  "D2_PHYSICAL_TRANSIENT_PAIRED_AUDIT.json", "D2_SPECTRAL_COST_SUMMARY.json",
                  "D2_SPECTRAL_GPU_LEDGER.tsv", "spectral/D2_SPECTRAL_AUDIT.json"),
    "stage3_d1": ("D1_REPORT.md", "D1_PROTOCOL_VERDICT.json", "D1A_PROTOCOL_FACTORIAL.json",
                  "D1B_MECHANISM_ARMS.json", "D1C_DOSE_RESPONSE.json", "D1_DISPATCH.prefrozen.json"),
    "stage4_d3": ("D3_FEATURES_VERIFIED.json", "D3_FEATURE_ROUTING_AMENDMENT.json",
                  "D3_FEATURES_EXECUTION.json", "FORECAST_INPUTS.json", "FOURTEEN_SOURCE_POOL_AUDIT.json"),
}
DEV_SUFFIX = {".py", ".sh"}
RESULT_SUFFIX = {".json", ".jsonl", ".tsv", ".md", ".pt", ".log", ".sha256"}
SECRET = re.compile(rb"(?:gh[pousr]_[0-9A-Za-z]{30,}|github_pat_[0-9A-Za-z_]{20,}|"
                    rb"-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----|"
                    rb"[a-z]+://[^\s/@:]+:[^\s/@]+@)", re.I)


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def validate(path):
    if not path.is_file() or path.is_symlink():
        raise ValueError(f"The publication requires a regular file: {path}")
    if path.suffix in (RESULT_SUFFIX | DEV_SUFFIX) - {".pt"} and SECRET.search(path.read_bytes()):
        raise ValueError(f"Credential-shaped data in {path}; review before publishing")


def glob_sets(root, rules):
    return {path for pattern in rules for path in root.glob(pattern) if path.is_file()}


def archives(root, destination, group, files, index):
    chunks = [[]]
    size = 0
    for path in sorted(files):
        validate(path)
        n = path.stat().st_size
        if n > 60 * 2**20:
            raise ValueError(f"Archive member exceeds the declared snapshot limit: {path}")
        if size + n > 46 * 2**20 and chunks[-1]:
            chunks.append([])
            size = 0
        chunks[-1].append(path)
        size += n
    for number, paths in enumerate(chunks, 1):
        if not paths:
            raise ValueError(f"Empty archive group {group}")
        target = destination / "artifacts" / f"{group}-{number:02d}.tar.gz"
        target.parent.mkdir(exist_ok=True)
        with target.open("wb") as packed, gzip.GzipFile(filename="", mode="wb", fileobj=packed,
                                                      compresslevel=4, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as tar:
                for path in paths:
                    name = path.relative_to(root).as_posix()
                    info = tar.gettarinfo(str(path), arcname=name)
                    info.mtime = info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    with path.open("rb") as source:
                        tar.addfile(info, source)
                    index[name] = {"archive": target.relative_to(destination).as_posix(),
                                  "bytes": info.size, "sha256": sha(path)}
        print("PACKED", group, number, len(paths), target.stat().st_size, flush=True)


def copy(root, destination, path):
    validate(path)
    relative = path.relative_to(root)
    output = destination / relative
    output.parent.mkdir(exist_ok=True, parents=True)
    shutil.copyfile(path, output)
    if sha(path) != sha(output):
        raise ValueError(f"A direct release artifact changed: {relative}")


def run(root, destination):
    if destination.exists():
        raise ValueError("Use a new isolated snapshot directory")
    env = read(root / "stage0_env/ENV_MANIFEST.json")
    e0 = read(root / "stage1_e0/E0_VERDICT.json")
    main_d2 = root / "stage2_d2/D2_VERDICT.json"
    d2 = read(main_d2)
    protocol = read(root / "stage3_d1/D1_PROTOCOL_VERDICT.json")
    acquired = read(root / "stage4_d3/D3_FEATURES_VERIFIED.json")
    if env["status"] != "PREFLIGHT_OK" or protocol["test_accessed"] or acquired["n_folds"] != 56:
        raise ValueError("Only verified, development-only stage closures can be packaged")
    if len(list((root/"stage3_d1/receipts").glob("*.json"))) != 32:
        raise ValueError("D1 does not contain the complete 32 scoring arms")
    d2_dispatch = read(root/"stage2_d2/DOWNSTREAM_FROZEN_EVALUATION.json")
    if len(d2_dispatch["jobs"]) != 116 or any(not Path(job["done_marker"]).is_file() for job in d2_dispatch["jobs"]):
        raise ValueError("D2 does not contain the full 116-run follow-up")
    destination.mkdir(parents=True)
    for stage, names in STAGES.items():
        for name in names:
            copy(root, destination, root / stage / name)
    for path in glob_sets(root, ("figures/FIG_D[12]_*.pdf", "figures/FIG_D[12]_*.png",
                                "figures/FIG_D[12]_*.svg", "figures/FIG_D[12]_*.json",
                                "reports/STAGES_0_TO_3_ZH.md")):
        copy(root, destination, path)
    python = set()
    for stage in (*STAGES, "stage5_d6", "tools", "figures"):
        python |= {path for path in (root/stage).glob("*") if path.suffix in DEV_SUFFIX and path.is_file()}
    python |= glob_sets(root, ("stage1_e0/code/*.py", "stage0_env/code/*.py"))
    python = {path for path in python if not re.search(r"\.(?:before|pre_|preattempt|raw_fold_worker)", path.name)}
    python = {path for path in python if not re.match(r"plot_d3\.|^audit_raw_p4\.|^d6_", path.name)}
    groups = {
        "source": python,
        "stage0-audit": glob_sets(root, ("stage0_env/*EXCLUSIONS.jsonl",)),
        "e0": glob_sets(root, ("stage1_e0/fits/**/*", "stage1_e0/e0_external_dev/**/*",
                              "stage1_e0/dispatcher_receipts/*.json", "stage1_e0/*DISPATCH.json")),
        "d2-core": glob_sets(root, ("stage2_d2/D2_REF_OPERATOR.pt", "stage2_d2/spectral/**/*",
                                   "stage2_d2/transients/**/*", "stage2_d2/heldout_rayleigh/**/*",
                                   "stage2_d2/orientation/**/*", "stage2_d2/downstream_receipts/*")),
        "d2-eval": glob_sets(root, ("stage2_d2/no_label_dev/**/*", "stage2_d2/sample_efficiency/**/*")),
        "d1": glob_sets(root, ("stage3_d1/A/**/*", "stage3_d1/B/**/*", "stage3_d1/C/**/*",
                              "stage3_d1/protocol/**/*", "stage3_d1/protocol_cloze/**/*",
                              "stage3_d1/cohorts/**/*", "stage3_d1/receipts/*", "stage3_d1/requests/**/*")),
        "d3-feature-snapshot": glob_sets(root, ("stage4_d3/sample_scores/*/fold_*/SCORES.jsonl",
                               "stage4_d3/sample_scores/*/fold_*/SOURCE_FEATURES.json",
                               "stage4_d3/sample_scores/*/fold_*/COLLECT_LOCK.json",
                               "stage4_d3/receipts/d3.features.*.json")),
        "d6-finished-subtasks": glob_sets(root, ("stage5_d6/fits/huginn/horizon_*/*",
                                       "stage5_d6/development/huginn/fixed_8/**/*",
                                       "stage5_d6/development/ouro26/native/**/*",
                                       "stage5_d6/development/ouro26/transfer/**/*",
                                       "stage5_d6/receipts/huginn.fit.*.json",
                                       "stage5_d6/receipts/huginn.dev.fixed_8.json",
                                       "stage5_d6/receipts/ouro26.dev.*.json")),
    }
    for key, items in groups.items():
        groups[key] = {path for path in items if path.suffix in RESULT_SUFFIX | DEV_SUFFIX
                       and "RESUME" not in path.name.upper() and path.stat().st_size > 0}
    if len(glob_sets(root, ("stage4_d3/sample_scores/*/fold_*/SCORES.jsonl",))) != 56:
        raise ValueError("The released D3 per-question inputs do not match the verified fold count")
    if len(glob_sets(root, ("stage5_d6/fits/huginn/horizon_*/FIT.json",))) != 6:
        raise ValueError("The D6 snapshot must contain the six closed Huginn fits only")
    shutil.copyfile(root/"reports/SNAPSHOT_README_ZH.md", destination/"README.md")
    indexes = {}
    for group, files in groups.items():
        archives(root, destination, group, files, indexes)
    index = destination/"ARTIFACT_INDEX.json"
    index.write_text(json.dumps(indexes, indent=2, sort_keys=True)+"\n",encoding="utf-8")
    files = []
    for path in sorted(destination.rglob("*")):
        if path.is_file():
            files.append(dict(path=path.relative_to(destination).as_posix(),
                              bytes=path.stat().st_size,sha256=sha(path)))
    manifest = dict(
        status="INTERIM_RELEASE", released_utc=datetime.now(timezone.utc).isoformat(), official_v3_benchmarks=0,
        completed_stages=["Stage 0", "E0", "D2", "D1"],
        completed_subtasks={"D3":"56 feature folds and 69,573 feature rows",
                            "D6":"six Huginn fits, one Huginn fixed-weight development arm and two Ouro-2.6B Base development arms"},
        omitted_large_replay_artifacts=["upstream dataset snapshots and model checkpoints",
                                         "multi-gigabyte raw Fisher operator exchange and D3 moment tensors"],
        frozen_identifiers={name:sha(root/name) for name in (
            "stage0_env/ENV_MANIFEST.json","stage1_e0/E0_VERDICT.json","stage2_d2/D2_VERDICT.json",
            "stage3_d1/D1_PROTOCOL_VERDICT.json","stage4_d3/D3_FEATURES_VERIFIED.json")},
        stage_counts=dict(e0_training_arms=26,e0_paired_dev_arms=30,d2_followup_arms=116,
                          d1_scoring_arms=32,d1_prediction_rows=152590,d3_feature_folds=56,d3_feature_rows=69573),
        files=files
    )
    (destination/"RELEASE_MANIFEST.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False)+"\n",encoding="utf-8")
    print("V3_SNAPSHOT_PACKED",len(files),len(indexes),sum(item["bytes"] for item in files),flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    run(args.study.resolve(), args.out.resolve())
