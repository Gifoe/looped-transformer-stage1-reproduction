"""Evaluate one frozen Base controller on the exact, common v3 development panel."""

import argparse
import json
from pathlib import Path
import sys
import time

from e0_external_dev import candidate_rows, letter_rows, prediction_checkpoint, pro_items


TASKS = {"sciq_val":("acc","acc_norm"),"arc_easy_val":("acc","acc_norm"),"cosmosqa_val":("acc","acc_norm"),
         "mmlu_val":("acc",),"mmlu_pro_val":("correct","parseable","strict_format","strict")}


def run(args):
    from d2_worker import digest, save_json
    import torch
    import minimal

    config=json.loads(args.config.read_text())
    env=Path(config["approved_env_manifest"])
    if digest(env)!=config["approved_env_sha256"]:
        raise ValueError("The external panel changed after Stage 0")
    datas=json.loads(env.read_text())["frozen_data"]
    if digest(args.weight)!=args.weight_sha256:
        raise ValueError("Controller differs from its closed training receipt")
    base=Path(config["model"])
    if digest(base/"model.safetensors")!="58872a72616c736595b8b7662079c5b12c5a162ec16eae94f21c348dfa9885af":
        raise ValueError("The frozen Base asset changed")

    sys.path[:0]=[config[key] for key in ("dev_stage2_code","unified","followup")]
    from controller_io import controller
    from evaluate_benchmarks import candidate_row, mmlu_metrics
    import evaluate_generation
    import generation_followup_run as decoder
    import seven_unified
    import stage2_score

    archive,model,tokenizer,runtime=minimal.runtime(Path(config["archive"]),Path(config["previous"]),base)
    settings=Path(config["mmlu_scoring_settings"])
    if digest(settings)!=config["mmlu_scoring_settings_sha256"] or digest(Path(decoder.__file__))!=config["mmlu_pro_decoder_sha256"]:
        raise ValueError("Archived external development evaluator changed")
    options=json.loads(settings.read_text())
    encoder=stage2_score.HarnessEncoder(tokenizer,options["max_length"])
    net=controller(args.weight,model.device).requires_grad_(False).eval()
    args.out.mkdir(parents=True,exist_ok=True)
    lock=dict(arm=args.arm,config_sha256=digest(args.config),weight_sha256=args.weight_sha256,
              runner_sha256=digest(Path(__file__)),panel_sha256=digest(env),depth=4)
    report=dict(lock,metrics={},predictions={},runtime={})
    for task,keys in TASKS.items():
        rel=f"UNIFIED_EXT_DEV/{task}.jsonl"
        requests=env.parent/rel
        identity=datas[rel]
        if identity["sha256"]!=digest(requests):
            raise ValueError("The external requests no longer match their immutable manifest")
        rows=minimal.load_jsonl(requests)
        ids=[row["sample_id"] for row in rows]
        if len(ids)!=identity["rows"] or len(set(ids))!=len(ids):
            raise ValueError("A development population was incomplete")
        @torch.inference_mode()
        def score():
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
            started=time.perf_counter()
            if task=="mmlu_val":
                current,cost=seven_unified.shard_score(stage2_score,minimal,model,encoder,net,letter_rows(rows),options,model.device)
                predictions=[candidate_row(row,seven_unified.UNIFIED) for row in current]
            elif task=="mmlu_pro_val":
                model.model.total_ut_steps=4
                mx,batch=decoder.TASKS["mmlu_pro"]
                blocks=decoder.batches(pro_items(rows,tokenizer,decoder),mx,batch,14500)
                predictions=[]
                cost={}
                for block in blocks:
                    raw,_=decoder.greedy("mmlu_pro",model,tokenizer,block,"feedback",net,1.,mx,decoder.cache_type(model))
                    predictions += mmlu_metrics(raw,block,decoder)
            else:
                predictions,cost=evaluate_generation.candidates(archive,model,tokenizer,net,candidate_rows(rows),4,12)
            torch.cuda.synchronize()
            cost=dict(cost)
            cost.update(complete_wall_seconds=time.perf_counter()-started,
                        peak_allocated_bytes=torch.cuda.max_memory_allocated(),
                        peak_reserved_bytes=torch.cuda.max_memory_reserved())
            return predictions,cost
        predictions,cost,details=prediction_checkpoint(args.out/f"{task}.jsonl",
                         dict(lock,cohort_sha256=identity["sha256"]),ids,score)
        report["metrics"][task]={key:sum(row["metrics"][key] for row in predictions)/len(ids) for key in keys}
        report["predictions"][task]=details
        report["runtime"][task]=cost
        print("SHARED_DEV_SCORED",args.arm,task,len(ids),flush=True)
    save_json(args.out/"DEVELOPMENT.json",report)
    print("SHARED_DEV_COMPLETE",args.arm,digest(args.out/"DEVELOPMENT.json"),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("config","weight","out"):
        parser.add_argument(f"--{name}",required=True,type=Path)
    parser.add_argument("--weight-sha256",required=True)
    parser.add_argument("--arm",required=True)
    run(parser.parse_args())


if __name__=="__main__":
    main()

