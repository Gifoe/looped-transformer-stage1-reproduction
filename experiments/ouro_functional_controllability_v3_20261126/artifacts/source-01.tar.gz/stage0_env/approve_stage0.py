"""Verify the data and host receipts before opening the Ouro v3 training queue."""

import argparse
from datetime import datetime, timezone
from hashlib import file_digest
import json
from pathlib import Path
import shutil


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def json_write(path, payload):
    temporary = path.with_suffix(".partial")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def hashed_record(path):
    return dict(sha256=digest(path), bytes=path.stat().st_size)


def classify_hosts(stage):
    hardware = {}
    records = {}
    anchors = None
    for host, expected in (("old", 1), ("dual", 2)):
        source = stage / f"HOST_{host}.json"
        result = read(source)
        if result["host"] != host or len(result["devices"]) != expected:
            raise ValueError(f"Invalid physical GPU receipt for {host}")
        identities = {name: value["sha256"] for name, value in result["anchors"].items()}
        if anchors is not None and identities != anchors:
            raise ValueError("The two hosts do not share the same Ouro Base and controller hashes")
        anchors = identities
        records[host] = dict(receipt=source.name, **hashed_record(source))
        for gpu in result["devices"]:
            if gpu["bf16_matmul"] != "pass" or gpu["total_bytes"] < 23 * 2**30:
                raise ValueError(f"Device on {host} did not pass the BF16 and capacity probes")
            idx = str(len(hardware))
            hardware[idx] = {"host": host, "local_index": gpu["local_index"], "name": gpu["name"],
                             "total_bytes": gpu["total_bytes"], "capability": gpu["capability"]}
    return hardware, records


def promote(args):
    stage = args.stage.resolve()
    draft = args.draft.resolve()
    record = read(draft / "DATA_DRAFT_MANIFEST.json")
    if record["status"] != "DATA_DRAFT_ONLY" or record["legacy_official_n"] != 43769 or record["boolq_supplement_n"] != 3270:
        raise ValueError("The data audit does not match the retained historical evaluation population")
    hardware, receipts = classify_hosts(stage)
    required = {
        "UNIFIED_EXT_DEV/sciq_val.jsonl": 500,
        "UNIFIED_EXT_DEV/cosmosqa_val.jsonl": 500,
        "UNIFIED_EXT_DEV/mmlu_validation.jsonl": 500,
        "UNLABELED_CORPUS/fit_unlabeled.jsonl": 1024,
        "UNLABELED_CORPUS/audit_unlabeled.jsonl": 512,
    }
    for name, count in required.items():
        if record["files"][name]["rows"] != count:
            raise ValueError(f"Incorrect locked development population at {name}")
    easy = record["files"]["UNIFIED_EXT_DEV/arc_easy_val.jsonl"]["rows"]
    if not 0 < easy <= 570:
        raise ValueError("ARC-Easy outer validation did not use the official eligible rows")
    mmlu_dev = record["files"]["UNIFIED_EXT_DEV/mmlu_dev.jsonl"]["rows"]
    mmlu_pro = record["files"]["UNIFIED_EXT_DEV/mmlu_pro_val.jsonl"]["rows"]
    mmlu_total = record["files"]["UNIFIED_EXT_DEV/mmlu_val.jsonl"]["rows"]
    if not (0 < mmlu_dev <= 285 and 0 < mmlu_pro <= 70 and mmlu_total == 500 + mmlu_dev):
        raise ValueError("The two audited MMLU development populations were inconsistent")
    for name, stamped in record["files"].items():
        origin = (draft / name).resolve()
        target = (stage / name).resolve()
        if not origin.is_relative_to(draft) or not target.is_relative_to(stage):
            raise ValueError("A panel file was outside the new study")
        if digest(origin) != stamped["sha256"]:
            raise ValueError(f"Draft artifact differs from the audited data: {name}")
        with origin.open("rb") as stream:
            n = sum(bool(line.strip()) for line in stream)
        if n != stamped["rows"]:
            raise ValueError(f"Draft artifact lost rows: {name}")
        target.parent.mkdir(exist_ok=True, parents=True)
        if origin == target:
            continue
        if target.exists():
            if digest(target) != stamped["sha256"]:
                raise ValueError(f"An immutable data artifact already differs: {name}")
        else:
            tmp = target.with_suffix(target.suffix+".partial")
            shutil.copyfile(origin, tmp)
            tmp.replace(target)
    companions = {
        "stage0_env": str(stage), "legacy_benchmark_questions": 43769,
        "boolq_additional_questions": 3270, "gpu_devices": hardware,
        "hosts": receipts, "data_draft_manifest_sha256": digest(draft/"DATA_DRAFT_MANIFEST.json"),
        "input_inventory": record["input_inventory"], "frozen_data": record["files"],
        "fit_audit_split": "disjoint source documents, excludes exact and eight-word overlaps per data audit",
        "official_test_use": "text-only overlap audit; official evaluation gated by frozen model selection",
        "retained_development": dict(arc_easy=easy, mmlu_validation=500, mmlu_auxiliary=mmlu_dev,
                                     mmlu=mmlu_total, mmlu_pro=mmlu_pro),
    }
    env = stage / "ENV_MANIFEST.json"
    if env.exists():
        existing = read(env)
        if any(existing.get(k) != v for k,v in companions.items()) or existing["status"] != "PREFLIGHT_OK":
            raise ValueError("A completed preflight already sealed another configuration")
    else:
        json_write(env, dict(status="PREFLIGHT_OK", timestamp_utc=datetime.now(timezone.utc).isoformat(), **companions))
    lines = ["# Ouro v3 preflight", "",
             "Three logical GPUs passed the BF16 checks across two hosts.",
             "The official suite preserves the 43,769-question historical protocol.",
             "BoolQ validation contributes 3,270 additional questions with its own metric.",
             f"The retained ARC-Easy development cohort has {easy} questions after isolation.",
             f"MMLU retains 500 validation questions and {mmlu_dev} auxiliary questions.",
             f"MMLU-Pro retains {mmlu_pro} generation questions after isolation.",
             "The frozen text sets include 1,024 fit passages and 512 audit passages from disjoint documents.",
             "The blind overlap audit used official evaluation text before model selection.",
             "", "Environment manifest SHA-256", "", digest(env)]
    (stage/"PREFLIGHT_REPORT.md").write_text("\n".join(lines)+"\n", encoding="utf-8")
    print("PREFLIGHT_OK", digest(env))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", required=True, type=Path)
    parser.add_argument("--draft", required=True, type=Path)
    promote(parser.parse_args())


if __name__ == "__main__":
    main()

