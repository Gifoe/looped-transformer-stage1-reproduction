"""Build auditable v3 development and unlabeled data drafts from pinned local inputs."""

import argparse
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
import re
import tempfile
import unicodedata


TRAIN = {"arc_challenge", "csqa", "obqa", "qasc", "scienceqa", "boolq", "social_iqa", "race",
         "squad", "gsm8k", "piqa", "hellaswag", "winogrande", "medmcqa"}
LEGACY = {"arc_challenge": 1172, "arc_easy": 2376, "sciq": 1000, "mmlu": 14042,
          "hellaswag": 10042, "winogrande": 1267, "piqa": 1838, "mmlu_pro": 12032}
EXTRA = {"csqa": 1221, "obqa": 500, "squad": 10570, "gsm8k": 1319}
SUPPLEMENT = {"boolq": 3270}
RESERVATIONS = LEGACY | EXTRA | SUPPLEMENT
PROSPECTIVE = {"piqa", "hellaswag", "winogrande", "medmcqa"}
DEVELOPMENT = {"sciq_val": ("sciq", "validation", 500), "arc_easy_val": ("arc_easy", "validation", 570),
               "cosmosqa_val": ("cosmosqa", "validation", 500), "mmlu_validation": ("mmlu", "validation", 500),
               "mmlu_dev": ("mmlu", "dev", 285), "mmlu_pro_val": ("mmlu_pro", "validation", 70)}
COMPLETE_DEV_SPLITS = {"arc_easy_val", "mmlu_dev", "mmlu_pro_val"}
MIN_WORDS = 8
FIT_N, AUDIT_N = 1024, 512
MEDMCQA_N = 20000
QA_TEMPLATE = re.compile(r"(?im)^\s*(?:(?:question|answer|options)\s*:|[A-D][.)]\s+)")


def digest(path):
    result = sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(2**20), b""):
            result.update(block)
    return result.hexdigest()


def normalize(text):
    return tuple(re.findall(r"[^\W_]+", unicodedata.normalize("NFKC", text).casefold()))


def items(path):
    if path.suffix == ".parquet":
        import pyarrow.parquet as pq
        for batch in pq.ParquetFile(path).iter_batches(batch_size=1024):
            yield from batch.to_pylist()
    else:
        with path.open(encoding="utf-8") as stream:
            for line in stream:
                yield json.loads(line)


def text_fields(row):
    """Extract text available before scoring. The target, answer key and rationales are ignored."""
    candidate = row.get("candidate") or row
    fragments = [row.get(key) for key in ("source_question", "context", "article", "passage", "support")]
    fragments += [candidate.get(key) for key in ("question", "stem", "text", "ctx", "goal", "sentence", "query")]
    choices = candidate.get("choices", row.get("options", row.get("endings", [])))
    fragments.extend(row.get(key) for key in ("sol1", "sol2", "option1", "option2", "opa", "opb", "opc", "opd"))
    fragments.extend(row.get(f"answer{i}") for i in range(4))
    if isinstance(choices, dict):
        choices = choices["text"]
    if isinstance(choices, list):
        fragments.extend(choices)
    for request in row.get("requests", []):
        args = request["args"]
        if args:
            fragments.extend(value for value in args if isinstance(value, str) and len(normalize(value)) > 1)
    return {words for value in fragments if isinstance(value, str) for words in (normalize(value),) if words}


def question_fields(row):
    primary = row.get("candidate") or row
    candidates = [primary.get(key) for key in ("question", "stem", "goal", "sentence", "ctx", "text", "query")]
    candidates += [row.get("source_question")]
    for request in row.get("requests", []):
        if request.get("args"):
            prompt = request["args"][0]
            match = re.search(r"(?is)(?:^|\n)Question:\s*(.+?)(?:\n(?:A\.|Answer:)|$)", prompt)
            if match:
                candidates.append(match[1])
            elif prompt.startswith("The following are multiple choice questions") and "\n\n" in prompt:
                candidates.append(prompt.split("\n\n", 1)[1].split("\nA.", 1)[0])
            else:
                candidates.append(prompt)
    return {normalize(field) for field in candidates if isinstance(field, str) and normalize(field)}


def gram_keys(words):
    return (words[i:i + MIN_WORDS] for i in range(len(words) - MIN_WORDS + 1))


def read_spec(path):
    config = json.loads(path.read_text(encoding="utf-8"))
    inputs = config["inputs"]
    seen = set()
    for item in inputs:
        key = (item["role"], item["name"])
        if item["role"] not in {"train", "blind_test", "development", "unlabeled"}:
            raise ValueError(f"Unexpected input role: {item['role']}")
        if (not isinstance(item.get("path"), str) or not isinstance(item.get("sha256"), str)
                or not re.fullmatch(r"[0-9a-f]{64}", item["sha256"])):
            raise ValueError(f"Unresolved local path or SHA-256 for {key}")
        if key in seen:
            raise ValueError(f"Duplicate logical input {key}")
        seen.add(key)
        item["path"] = str((path.parent / item["path"]).resolve())
        if digest(Path(item["path"])) != item["sha256"]:
            raise ValueError(f"Input content changed for {key}")
        if not item["revision"]:
            raise ValueError(f"Input revision or provenance missing for {key}")
    by_role = {role: {i["name"]: i for i in inputs if i["role"] == role}
               for role in ("train", "blind_test", "development", "unlabeled")}
    if set(by_role["train"]) != TRAIN or set(by_role["blind_test"]) != set(RESERVATIONS):
        raise ValueError("The 14 training sources and all blind reservations must be explicitly supplied")
    if set(by_role["development"]) != set(DEVELOPMENT) or set(by_role["unlabeled"]) != {"corpus_candidates"}:
        raise ValueError("Development and unlabeled roster incomplete")
    if any(i["split"] != "train" or i["family"] != name for name, i in by_role["train"].items()):
        raise ValueError("Training must use the designated official train split")
    for name, i in by_role["blind_test"].items():
        expected_split = "validation" if name in {"csqa", "squad", "boolq", "piqa", "winogrande", "hellaswag"} else "test"
        if i["split"] != expected_split or i["family"] != name or i.get("rows") != RESERVATIONS[name]:
            raise ValueError(f"Blind reservation differs from official population: {name}")
    for name, (family, split, n) in DEVELOPMENT.items():
        record = by_role["development"][name]
        allowed = {family, "logiqa"} if name == "cosmosqa_val" else {family}
        if (record["family"] not in allowed or record["family"] in TRAIN
                or record["split"] != split or record.get("limit") != n):
            raise ValueError(f"Ineligible development population {name}")
    if not isinstance(config.get("sampling_seed"), int):
        raise ValueError("Define the authorized sampling seed before building any draft")
    config["by_role"] = by_role
    return config


def order_key(seed, identifier):
    return sha256(f"{seed}/{identifier}".encode()).hexdigest()


def assign_candidates(config, roles=("development", "unlabeled"), names=None):
    groups = {}
    for role in roles:
        for name, item in config["by_role"][role].items():
            if names is not None and name not in names:
                continue
            rows = []
            for row in items(Path(item["path"])):
                identifier = row.get("sample_id", row.get("id"))
                if identifier is None or not text_fields(row):
                    raise ValueError(f"Candidate without stable ID or text: {name}")
                rows.append((str(identifier), row, text_fields(row)))
            if len({i for i, _, _ in rows}) != len(rows):
                raise ValueError(f"Duplicated incoming IDs in {name}")
            groups[name] = rows
    return groups


def check_blind(row):
    forbidden = {"answer", "answers", "label", "target", "gold", "answerKey", "answer_index",
                 "correct_answer", "rationale", "cot_content", "solution"}
    if forbidden.intersection(row) or forbidden.intersection(row.get("candidate", {})):
        raise ValueError("Blind reference must be text-only. Export it with --blind first.")
    if any(set(request) - {"type", "args", "idx"} for request in row.get("requests", [])):
        raise ValueError("Unexpected fields in blind request")


def contaminated(groups, refs, extra_reference_rows=()):
    wanted_exact, wanted_grams = defaultdict(set), defaultdict(set)
    for name, rows in groups.items():
        for identifier, row, fields in rows:
            key = (name, identifier)
            for field in question_fields(row):
                wanted_exact[field].add(key)
            for field in fields:
                for gram in gram_keys(field):
                    wanted_grams[gram].add(key)
    blocked = defaultdict(set)

    def mark(row, source):
        fields = text_fields(row)
        if not fields:
            raise ValueError(f"Reservation row without input text in {source}")
        for field in question_fields(row):
            for key in wanted_exact.get(field, ()):
                blocked[key].add("exact/" + source)
        for field in fields:
            for gram in gram_keys(field):
                for key in wanted_grams.get(gram, ()):
                    blocked[key].add("8gram/" + source)

    for item in refs:
        count = 0
        for row in items(Path(item["path"])):
            if item["role"] == "blind_test":
                check_blind(row)
            mark(row, f"{item['role']}/{item['name']}")
            count += 1
        if item.get("rows") is not None and count != item["rows"]:
            raise ValueError(f"Row count differs from pinned source {item['name']}")
        print("OVERLAP_REFERENCE", item["role"], item["name"], count, len(blocked), flush=True)
    for row in extra_reference_rows:
        mark(row, "development/UNIFIED_EXT_DEV")

    return blocked


def sample_dev(group, rows, seed):
    family, split, required = DEVELOPMENT[group]
    pool = sorted(rows, key=lambda entry: order_key(seed, entry[0]))
    if group == "mmlu_validation":
        strata = defaultdict(list)
        for entry in pool:
            strata[entry[1]["subject"]].append(entry)
        pool = []
        while any(strata.values()):
            for name in sorted(strata):
                if strata[name]:
                    pool.append(strata[name].pop(0))
    selected = []
    used = set()
    for identifier, row, fields in pool:
        # Retain distinct official formulations, including MMLU and MMLU-Pro variants.
        identity = tuple(sorted(fields))
        if identity in used:
            continue
        used.add(identity)
        selected.append(dict(row, sample_id=identifier))
        if group not in COMPLETE_DEV_SPLITS and len(selected) == required:
            break
    if group in COMPLETE_DEV_SPLITS:
        if not 0 < len(selected) <= required:
            raise ValueError(f"{group}: {len(selected)} eligible rows outside the complete split of {required}")
    elif len(selected) != required:
        raise ValueError(f"{group}: only {len(selected)} eligible of {required} required")
    return selected


def sample_corpus(rows, tok, seed, dev_rows):
    dev_keys = {gram for row in dev_rows for field in text_fields(row) for gram in gram_keys(field)}
    used_docs, used_text, used_grams, chunks = set(), set(), set(), []
    for identifier, row, fields in sorted(rows, key=lambda item: order_key(seed, item[0])):
        doc = str(row["document_id"])
        text = row["text"]
        words = normalize(text)
        if doc in used_docs or words in used_text or QA_TEMPLATE.search(text):
            continue
        if any(gram in dev_keys or gram in used_grams for gram in gram_keys(words)):
            continue
        n = len(tok.encode(text, add_special_tokens=False))
        if not 256 <= n <= 384:
            continue
        used_docs.add(doc)
        used_text.add(words)
        used_grams.update(gram_keys(words))
        chunks.append({"sample_id": identifier, "document_id": doc, "text": text, "tokens": n})
        if len(chunks) == FIT_N + AUDIT_N:
            break
    if len(chunks) != FIT_N + AUDIT_N:
        raise ValueError(f"Only {len(chunks)} document-disjoint and uncontaminated text fragments")
    return chunks[:FIT_N], chunks[FIT_N:]


def d1_four_choice(rows):
    kept = []
    excluded = defaultdict(int)
    for row in rows:
        count = len(row["choices"]["text"])
        if count == 4:
            kept.append(row)
        else:
            excluded[count] += 1
    return kept, dict(excluded)


def write_rows(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
    return {"rows": len(rows), "sha256": digest(path)}


def build(config, output):
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(config["local_tokenizer"], local_files_only=True, trust_remote_code=False)
    groups = assign_candidates(config)
    refs = [*config["by_role"]["train"].values(), *config["by_role"]["blind_test"].values()]
    blocked = contaminated(groups, refs)
    eligible = {name: [entry for entry in rows if (name, entry[0]) not in blocked] for name, rows in groups.items()}
    eligibility = {name: {"input": len(rows), "eligible": len(eligible[name])} for name, rows in groups.items()}
    print("ELIGIBILITY", json.dumps(eligibility, sort_keys=True), flush=True)
    dev = {"mmlu_pro_val": sample_dev("mmlu_pro_val", eligible["mmlu_pro_val"], config["sampling_seed"])}
    mmlu_pro_stems = {field for row in dev["mmlu_pro_val"] for field in question_fields(row)}
    shared_stems = set()
    for group in DEVELOPMENT:
        if group == "mmlu_pro_val":
            continue
        rows = eligible[group]
        if group in {"mmlu_validation", "mmlu_dev"}:
            disjoint = []
            for entry in rows:
                matching = question_fields(entry[1]).intersection(mmlu_pro_stems)
                if matching:
                    blocked[(group, entry[0])].add("exact/development/mmlu_pro_val")
                    shared_stems.update(matching)
                else:
                    disjoint.append(entry)
            eligibility[group]["shared_with_mmlu_pro"] = len(rows) - len(disjoint)
            rows = disjoint
        dev[group] = sample_dev(group, rows, config["sampling_seed"])
    for name, rows in dev.items():
        eligibility[name].update(selected=len(rows), original_target=DEVELOPMENT[name][2])
    print("DEVELOPMENT_SELECTED", json.dumps({name: len(rows) for name, rows in dev.items()}), flush=True)
    selected_dev = [row for group in dev.values() for row in group]
    fit, audit = sample_corpus(eligible["corpus_candidates"], tokenizer, config["sampling_seed"], selected_dev)
    print("UNLABELED_SELECTED", len(fit), len(audit), flush=True)
    prospective = assign_candidates(config, ("train",), PROSPECTIVE)
    prospective_blocked = contaminated(prospective, config["by_role"]["blind_test"].values(), selected_dev)
    prospective_selected = {}
    for group, rows in prospective.items():
        kept = [dict(row, sample_id=identifier) for identifier, row, _ in rows
                if (group, identifier) not in prospective_blocked]
        if group == "medmcqa":
            if len(kept) < MEDMCQA_N:
                raise ValueError("MedMCQA has fewer than 20,000 eligible items")
            kept = sorted(kept, key=lambda row: order_key(config["sampling_seed"], row["sample_id"]))[:MEDMCQA_N]
        if not kept:
            raise ValueError(f"No eligible items in prospective pool {group}")
        prospective_selected[group] = kept
    output = output.resolve()
    if output.exists():
        raise FileExistsError(f"Draft output already exists: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent) as temp:
        stage = Path(temp) / "draft"
        files = {}
        for group, rows in dev.items():
            name = f"UNIFIED_EXT_DEV/{group}.jsonl"
            files[name] = write_rows(stage / name, rows)
        files["UNIFIED_EXT_DEV/mmlu_val.jsonl"] = write_rows(
            stage / "UNIFIED_EXT_DEV/mmlu_val.jsonl", dev["mmlu_validation"] + dev["mmlu_dev"])
        for name, rows in (("fit_unlabeled", fit), ("audit_unlabeled", audit)):
            file = f"UNLABELED_CORPUS/{name}.jsonl"
            files[file] = write_rows(stage / file, rows)
        for group, rows in prospective_selected.items():
            file = f"PROSPECTIVE_TRAIN_DRAFT/{group}.jsonl"
            files[file] = write_rows(stage / file, rows)
        prospective_exclusions = [{"source": group, "sample_id": identifier, "reasons": sorted(reasons)}
                                  for (group, identifier), reasons in sorted(prospective_blocked.items())]
        files["PROSPECTIVE_EXCLUSIONS.jsonl"] = write_rows(stage / "PROSPECTIVE_EXCLUSIONS.jsonl", prospective_exclusions)
        exclusions = [{"source": group, "sample_id": identifier, "reasons": sorted(reasons)}
                      for (group, identifier), reasons in sorted(blocked.items())]
        files["DECONTAMINATION_EXCLUSIONS.jsonl"] = write_rows(stage / "DECONTAMINATION_EXCLUSIONS.jsonl", exclusions)
        manifest = {"status": "DATA_DRAFT_ONLY", "seed": config["sampling_seed"],
                    "input_inventory": config["inputs"], "files": files,
                    "eligibility": eligibility, "source_file_sha256": config.get("source_file_sha256", {}),
                    "mmlu_mmlu_pro_excluded_shared_normalized_development_stems": len(shared_stems),
                    "legacy_official_n": sum(LEGACY.values()), "boolq_supplement_n": 3270}
        (stage / "DATA_DRAFT_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        stage.rename(output)
    print("DATA_DRAFT_READY", output, digest(output / "DATA_DRAFT_MANIFEST.json"), flush=True)


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--spec", type=Path, required=True)
    cli.add_argument("--draft-output", type=Path, help="Build CPU draft without generating any formal lock.")
    args = cli.parse_args()
    config = read_spec(args.spec)
    if args.draft_output:
        build(config, args.draft_output)
    else:
        print("Input hashes and roster verified. No data was built.")
