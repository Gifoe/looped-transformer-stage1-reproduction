"""Prepare a stable-ID local source export for the Stage 0 input roster."""

import argparse
from pathlib import Path

from stage0_data import digest, items, write_rows


VISIBLE = ("question", "source_question", "stem", "context", "passage", "article", "text", "ctx",
           "goal", "sentence", "query", "support", "options", "choices", "endings", "sol1", "sol2",
           "option1", "option2", "answer0", "answer1", "answer2", "answer3")
ID_COLUMNS = ("sample_id", "id", "question_id", "ind", "subject", "category")


def visible_rows(path, blind):
    if not blind or path.suffix != ".parquet":
        yield from items(path)
        return
    import pyarrow.parquet as pq
    file = pq.ParquetFile(path)
    available = set(file.schema_arrow.names)
    columns = [key for key in (*VISIBLE, *ID_COLUMNS) if key in available]
    if "candidate" in available:
        columns.extend(("candidate.question", "candidate.choices"))
    if "requests" in available:
        columns.extend(("requests.type", "requests.args", "requests.idx"))
    for batch in file.iter_batches(batch_size=1024, columns=columns):
        yield from batch.to_pylist()


def canonical_rows(path, family, split, blind):
    seen = set()
    for index, row in enumerate(visible_rows(path, blind)):
        name = row.get("sample_id", row.get("id", row.get("question_id", row.get("ind", index))))
        identifier = f"{family}/{split}/{row.get('subject', '')}/{name}"
        if identifier in seen:
            raise ValueError(f"Duplicate source ID {identifier}")
        seen.add(identifier)
        if blind:
            # Historical request arrays contain the visible, scored alternatives; never keep the gold target.
            transformed = {key: row[key] for key in VISIBLE if key in row}
            if "requests" in row:
                transformed["requests"] = [
                    {key: request[key] for key in ("type", "args", "idx") if key in request}
                    for request in row["requests"]]
            if "candidate" in row:
                inner = row["candidate"]
                transformed["candidate"] = {key: inner[key] for key in ("question", "choices") if key in inner}
        else:
            transformed = dict(row)
        transformed["sample_id"] = identifier
        yield transformed


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--input-sha256", required=True)
    parser.add_argument("--family", required=True)
    parser.add_argument("--split", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--blind", action="store_true")
    a = parser.parse_args()
    if digest(a.input) != a.input_sha256 or a.output.exists():
        raise ValueError("Source hash differs or destination already exists")
    print(write_rows(a.output, list(canonical_rows(a.input, a.family, a.split, a.blind))))
