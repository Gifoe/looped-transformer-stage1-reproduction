"""Recheck frozen development data and WikiText slices against pinned text-only reserves."""

import argparse
import json
from pathlib import Path

from stage0_data import contaminated, digest, gram_keys, items, normalize, question_fields, read_spec, text_fields


DEVELOPMENT = ("sciq_val", "arc_easy_val", "cosmosqa_val", "mmlu_val", "mmlu_pro_val")
CORPORA = ("fit_unlabeled", "audit_unlabeled")


def audit(stage):
    source = read_spec(stage / "DATA_INPUTS.json")
    env_path = stage / "ENV_MANIFEST.json"
    env = json.loads(env_path.read_text(encoding="utf-8"))
    if env["status"] != "PREFLIGHT_OK":
        raise ValueError("The frozen environment manifest is unavailable")
    dev_paths = {name: f"UNIFIED_EXT_DEV/{name}.jsonl" for name in DEVELOPMENT}
    corpus_paths = {name: f"UNLABELED_CORPUS/{name}.jsonl" for name in CORPORA}
    groups = {}
    for name in (*dev_paths.values(), *corpus_paths.values()):
        path = stage / name
        pin = env["frozen_data"][name]
        if digest(path) != pin["sha256"]:
            raise ValueError(f"Frozen artifact drifted: {name}")
        rows = [(row["sample_id"], row, text_fields(row)) for row in items(path)]
        if len(rows) != pin["rows"] or len({identifier for identifier, _, _ in rows}) != len(rows):
            raise ValueError(f"Frozen population or uniqueness changed: {name}")
        groups[name] = rows
    references = [*source["by_role"]["train"].values(), *source["by_role"]["blind_test"].values()]
    overlap = contaminated(groups, references)
    if overlap:
        exact = sum(any(reason.startswith("exact/") for reason in flags) for flags in overlap.values())
        eight = sum(any(reason.startswith("8gram/") for reason in flags) for flags in overlap.values())
        raise ValueError(f"Retained data overlaps references on {exact} exact rows and {eight} 8-gram rows")
    fit, validation = [groups[corpus_paths[key]] for key in CORPORA]
    mmlu, pro = [groups[dev_paths[key]] for key in ("mmlu_val", "mmlu_pro_val")]
    mmlu_stems, pro_stems = ({stem for _, row, _ in group for stem in question_fields(row)} for group in (mmlu, pro))
    fit_docs, audit_docs = ({row["document_id"] for _, row, _ in group} for group in (fit, validation))
    fit_grams, audit_grams = ({gram for _, row, _ in group for gram in gram_keys(normalize(row["text"]))}
                             for group in (fit, validation))
    tokens = [row["tokens"] for _, row, _ in fit + validation]
    if mmlu_stems & pro_stems or fit_docs & audit_docs or fit_grams & audit_grams or not 256 <= min(tokens) <= max(tokens) <= 384:
        raise ValueError("Cross-panel, corpus isolation, or token length postverification failed")
    return {"env_manifest_sha256": digest(env_path), "audited": {name: len(rows) for name, rows in groups.items()},
            "exact_overlap": 0, "eight_gram_overlap": 0, "reference_sources": len(references),
            "mmlu_mmlu_pro_shared_normalized_stems": 0, "fit_audit_shared_documents": 0,
            "fit_audit_shared_8grams": 0, "unlabeled_token_range": [min(tokens), max(tokens)]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", required=True, type=Path)
    args = parser.parse_args()
    content = audit(args.stage)
    path = args.stage / "AUDIT_DEV_LEAKAGE.json"
    partial = path.with_suffix(".partial")
    partial.write_text(json.dumps(content, indent=2) + "\n", encoding="utf-8")
    partial.replace(path)
    print("AUDIT_DEV_LEAKAGE_OK", digest(path), flush=True)
