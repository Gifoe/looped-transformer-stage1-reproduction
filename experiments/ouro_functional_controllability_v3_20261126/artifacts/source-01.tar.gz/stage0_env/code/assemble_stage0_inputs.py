"""Assemble the new study's pinned source JSONL files without changing historical assets."""

import argparse
from collections import Counter
import csv
import heapq
from io import TextIOWrapper
from itertools import chain
import json
from pathlib import Path
import re
import zipfile

from export_stage0_source import canonical_rows
from stage0_data import LEGACY, EXTRA, SUPPLEMENT, digest, items, normalize, order_key


DEV = {
    "sciq_val": ("sciq", "validation", 500, "allenai/sciq@2c94ad3e1aafab77146f384e23536f97a4849815"),
    "arc_easy_val": ("arc_easy", "validation", 570, "allenai/ai2_arc ARC-Easy historical validation asset"),
    "cosmosqa_val": ("cosmosqa", "validation", 500, "wilburOne/cosmosqa data/valid.csv"),
    "mmlu_validation": ("mmlu", "validation", 500, "cais/mmlu@c30699e8356da336a370243923dbaf21066bb9fe"),
    "mmlu_dev": ("mmlu", "dev", 285, "cais/mmlu@c30699e8356da336a370243923dbaf21066bb9fe"),
    "mmlu_pro_val": ("mmlu_pro", "validation", 70, "TIGER-Lab/MMLU-Pro@b189ec765aa7ed75c8acfea42df31fdae71f97be"),
}
PROSPECTIVE = {
    "piqa": "AI2 publisher physicaliqa-train-dev.zip",
    "hellaswag": "Rowan/hellaswag@218ec52e09a7e7462a5400043bb9a69a41d06b76",
    "winogrande": "allenai/winogrande@01e74176c63542e6b0bcb004dcdea22d94fb67b5/winogrande_xl",
    "medmcqa": "openlifescienceai/medmcqa@91c6572c454088bf71b679ad90aa8dffcd0d5868",
}
VALIDATION_RESERVATIONS = {"csqa", "squad", "boolq", "piqa", "winogrande", "hellaswag"}
TITLE = re.compile(r"^\s*=\s+([^=\n]+?)\s+=\s*$")
SEED = 26112601
TOKENIZER = "/root/autodl-tmp/ouro-cross-task-20261118/model"


def emit(path, rows):
    partial = path.with_suffix(".partial")
    count = 0
    with partial.open("w", encoding="utf-8", newline="\n") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
            count += 1
    partial.replace(path)
    return count, digest(path)


def wikitext_documents(files):
    title, accumulated, index = None, [], 0
    for row in chain.from_iterable(items(file) for file in files):
        text = row["text"]
        match = TITLE.fullmatch(text)
        if match:
            if title is not None:
                yield f"wiki103/{index}/{title}", "".join(accumulated)
            index += 1
            title, accumulated = match[1], []
        elif title is not None:
            accumulated.append(text)
    if title is not None:
        yield f"wiki103/{index}/{title}", "".join(accumulated)


def corpus_candidates(files, tokenizer):
    documents = heapq.nsmallest(6200, ((identifier, text) for identifier, text in wikitext_documents(files)
                                      if len(text) >= 1100),
                                 key=lambda pair: order_key(SEED, pair[0]))
    for identifier, article in documents:
        encoded = tokenizer.encode(article, add_special_tokens=False)
        if len(encoded) < 320:
            continue
        start = int(order_key(SEED, identifier + "/window")[:16], 16) % (len(encoded) - 320 + 1)
        text = tokenizer.decode(encoded[start:start + 320], clean_up_tokenization_spaces=False)
        yield {"sample_id": identifier + "/chunk", "document_id": identifier, "text": text}


def piqa_rows(archive):
    with zipfile.ZipFile(archive) as source:
        data, = [key for key in source.namelist() if key.endswith("/train.jsonl") or key == "train.jsonl"]
        labels, = [key for key in source.namelist() if key.endswith("/train-labels.lst") or key == "train-labels.lst"]
        with source.open(data) as rows, source.open(labels) as answers:
            for row, value in zip(rows, answers, strict=True):
                item = json.loads(row)
                item["label"] = int(value)
                yield item


def prospective_rows(name, source, tokenizer):
    from task_data import encode_target, multiple_choice
    stream = piqa_rows(source) if name == "piqa" else items(source)
    used = set()
    for index, row in enumerate(stream):
        if name == "piqa":
            question, options, gold = row["goal"], [row["sol1"], row["sol2"]], int(row["label"])
        elif name == "hellaswag":
            question, options, gold = row["ctx"], row["endings"], int(row["label"])
        elif name == "winogrande":
            question, options, gold = row["sentence"], [row["option1"], row["option2"]], int(row["answer"]) - 1
        else:
            question, options, gold = row["question"], [row[key] for key in ("opa", "opb", "opc", "opd")], int(row["cop"])
        if not 0 <= gold < len(options):
            raise ValueError(f"Unexpected training label index for {name}/{index}")
        if not all(isinstance(option, str) and normalize(option) for option in options):
            continue
        identity = (normalize(question), tuple(sorted(normalize(option) for option in options)))
        if identity in used or len(set(identity[1])) != len(options):
            continue
        used.add(identity)
        labels = [chr(65 + i) for i in range(len(options))]
        source_id = row.get("id", row.get("ind", index))
        if name == "hellaswag":
            source_id = f"{source_id}/{index}"
        identifier = f"{name}/train/{source_id}"
        candidate = {"id": identifier, "question": question, "choices": {"label": labels, "text": options},
                     "answerKey": labels[gold]}
        raw = multiple_choice(candidate, name, "content")
        try:
            _, tokens, _ = encode_target(tokenizer, raw)
        except (AssertionError, ValueError):
            continue
        if len(tokens) <= 1536:
            raw.update(source_question=question, fold_key=identifier, input_tokens=len(tokens) - 1)
            yield raw


def main(root, refresh_hellaswag=False):
    from transformers import AutoTokenizer

    stage = root / "stage0_env"
    raw = stage / "raw"
    prepared = stage / "prepared_sources"
    prepared.mkdir(exist_ok=True)
    tokenizer = AutoTokenizer.from_pretrained(TOKENIZER, local_files_only=True)
    tokenizer.model_max_length = 1000000
    target = stage / "DATA_INPUTS.json"
    if refresh_hellaswag:
        config = json.loads(target.read_text())
        entry, = [row for row in config["inputs"] if (row["role"], row["name"]) == ("train", "hellaswag")]
        source = raw / "train_hellaswag.parquet"
        if digest(source) != config["source_file_sha256"]["train/hellaswag"][str(source)]:
            raise ValueError("Pinned HellaSwag training source changed")
        count, sha = emit(Path(entry["path"]), prospective_rows("hellaswag", source, tokenizer))
        if count != entry["rows"]:
            raise ValueError("An ID-only refresh changed the HellaSwag population")
        entry["sha256"] = sha
        partial = target.with_suffix(".partial")
        partial.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
        partial.replace(target)
        print("HELLASWAG_IDS_READY", count, sha, digest(target), flush=True)
        return
    template_file = stage / "code/stage0_inputs.template.json"
    template = json.loads(template_file.read_text())
    config = dict(status="DATA_INPUTS_VERIFIED", local_tokenizer=TOKENIZER, sampling_seed=SEED, inputs=[])
    all_source_hashes = {}
    for record in template["inputs"]:
        entry = dict(record)
        role, name = entry["role"], entry["name"]
        out = prepared / f"{role}_{name}.jsonl"
        if role == "train" and name not in PROSPECTIVE:
            source = Path(entry["path"])
            if digest(source) != entry["sha256"]:
                raise ValueError(f"Historical pool changed {name}")
            config["inputs"].append(entry)
            print("REUSE", role, name, entry["rows"], flush=True)
            continue
        if role == "blind_test":
            source = Path(entry["upstream_path"]) if entry["upstream_path"] else Path(
                "/root/ouro-loop-aware-functional-identification-20261125/data/reading/boolq_validation_raw.parquet")
            if entry.get("upstream_sha256") and digest(source) != entry["upstream_sha256"]:
                raise ValueError(f"Historical reservation changed {name}")
            entry["split"] = "validation" if name in VALIDATION_RESERVATIONS else "test"
            rows = canonical_rows(source, name, entry["split"], blind=True)
            entry["revision"] = "hashed historical official evaluation input"
        elif role == "development":
            family, split, _, revision = DEV[name]
            if name == "cosmosqa_val":
                source = raw / "cosmosqa_val.csv"
                if digest(source) != "a6a94fc1463ca82bb10f98ef68ed535405e6f5c36e044ff8e136b5c19dea63f3":
                    raise ValueError("Official CosmosQA validation digest changed")
                def cosmos():
                    with source.open(newline="", encoding="utf-8") as stream:
                        for i, row in enumerate(csv.DictReader(stream)):
                            row["sample_id"] = str(row.get("id") or f"cosmosqa/validation/{i}")
                            row["label"] = int(row["label"])
                            yield row
                rows = cosmos()
            else:
                source = (Path("/root/ouro-functional-transferability-20261123/inputs/arc_easy_validation.parquet")
                          if name == "arc_easy_val" else raw / f"{name}.parquet")
                rows = canonical_rows(source, family, split, blind=False)
            entry["revision"] = revision
        elif role == "train":
            source = raw / ("piqa.zip" if name == "piqa" else f"train_{name}.parquet")
            rows = prospective_rows(name, source, tokenizer)
            entry["revision"] = PROSPECTIVE[name]
        else:
            source = (raw / "wiki_0.parquet", raw / "wiki_1.parquet")
            rows = corpus_candidates(source, tokenizer)
            entry.update(family="wikitext", split="train",
                         revision="Salesforce/wikitext@b08601e04326c79dfdd32d625aee71d232d685c3/wikitext-103-raw-v1")
        if isinstance(source, tuple):
            all_source_hashes[f"{role}/{name}"] = {str(p): digest(p) for p in source}
        else:
            all_source_hashes[f"{role}/{name}"] = {str(source): digest(source)}
        count, sha = emit(out, rows)
        if entry.get("rows") is not None and count != entry["rows"]:
            raise ValueError(f"{name}: expected {entry['rows']} rows, found {count}")
        entry.update(path=str(out), sha256=sha, rows=count)
        config["inputs"].append(entry)
        print("PREPARED", role, name, count, sha, flush=True)
    config["source_file_sha256"] = all_source_hashes
    partial = target.with_suffix(".partial")
    partial.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
    partial.replace(target)
    print("INPUTS_READY", digest(target), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--refresh-hellaswag", action="store_true")
    args = parser.parse_args()
    main(args.root.resolve(), args.refresh_hellaswag)
