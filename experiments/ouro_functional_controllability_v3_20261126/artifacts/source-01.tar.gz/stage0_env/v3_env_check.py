"""Collect one host's frozen model and BF16 hardware receipts for Ouro v3."""

import argparse
from hashlib import file_digest, sha1
import json
import os
from pathlib import Path
import socket
import subprocess
import sys

import torch
import transformers


ANCHORS = {
    "base": "58872a72616c736595b8b7662079c5b12c5a162ec16eae94f21c348dfa9885af",
    "t1": "91d4919308bf9060ce0c44e4046e4851e7e59f65b9692c77045535f96534efd2",
    "t2": "117f5f2fe9c5afe363ba8c032f42cd25155f7a88cb465e4e79bfb3bf496c8032",
    "mixed": "ec2e55a64564f608cfeb245da079015db4347a9391072cba7f2949db05185b87",
    "rank8": "513a964b07f6a70d79fdbf2a36effa85fc757194cb89fc84993a2323da2abeb8",
    "historical_t1_axis": "0bdb6a2e2e476671a95f98988e01064f9a988413c1b619cd2b76039b52712042",
    "huginn_rank1": "a902e673be2a8e28f0e18e488bcf5f33e2e9d5b5bea35d989e67d0ede0c87ee0",
}
HUGINN_REVISION = "bb6621b65e90b6a4b9b29ef88dc83866d450470c"


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def checked(path, expected):
    found = digest(path)
    if expected != found:
        raise ValueError(f"Unexpected SHA-256 for {path}: {found}")
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=found)


def verify_ouro_models(path, pins):
    result = {}
    for name, pin in read(pins).items():
        folder = path / name
        receipt = folder / "MODEL_LOCK.json"
        actual = read(receipt)
        if any(actual[key] != expected for key, expected in pin.items()):
            raise ValueError(f"Unexpected frozen checkpoint receipt for {name}")
        weight = checked(folder / "model.safetensors", pin["weight_sha256"])
        if weight["bytes"] != pin["weight_bytes"]:
            raise ValueError(f"Unexpected model size for {name}")
        config = read(folder / "config.json")
        if config["hidden_size"] != actual["hidden_size"] or config["num_hidden_layers"] != actual["layers"]:
            raise ValueError(f"Unexpected geometry for {name}")
        config_receipts = {}
        for filename, item in actual["files"].items():
            asset = folder / filename
            if filename == "model.safetensors":
                continue
            if item["bytes"] != asset.stat().st_size:
                raise ValueError(f"Unexpected model asset length for {asset}")
            data = asset.read_bytes()
            blob = sha1(f"blob {len(data)}\0".encode() + data).hexdigest()
            if blob != item["blob_id"]:
                raise ValueError(f"Unexpected git blob identity for {asset}")
            config_receipts[filename] = digest(asset)
        result[name] = dict(revision=actual["revision"], weights=weight, model_lock_sha256=digest(receipt),
                            asset_sha256=config_receipts, hidden_size=actual["hidden_size"], layers=actual["layers"])
    return result


def gpu_probe(expected_count):
    if torch.cuda.device_count() != expected_count:
        raise ValueError(f"Expected {expected_count} devices on this host, saw {torch.cuda.device_count()}")
    nv = subprocess.check_output(["nvidia-smi", "--query-gpu=index,uuid,name,driver_version,memory.total",
                                  "--format=csv,noheader,nounits"], text=True).strip().splitlines()
    result = []
    for index in range(expected_count):
        device = torch.device("cuda", index)
        with torch.cuda.device(device):
            if not torch.cuda.is_bf16_supported():
                raise ValueError(f"BF16 not supported on CUDA GPU {index}")
            mat = torch.full((64, 64), 1.5, device=device, dtype=torch.bfloat16)
            out = mat @ mat
            if out.dtype != torch.bfloat16 or not torch.eq(out, 144.0).all().item():
                raise ValueError(f"Incorrect BF16 product on CUDA GPU {index}")
            torch.cuda.synchronize(device)
        props = torch.cuda.get_device_properties(index)
        result.append(dict(local_index=index, name=props.name, total_bytes=props.total_memory,
                           capability=[props.major, props.minor], bf16_matmul="pass", nvidia_smi=nv[index]))
    return result


def huginn_assets(a):
    code = a.cross / "huginn_deps"
    version = subprocess.check_output([sys.executable, "-c", "import transformers; print(transformers.__version__)"],
                                      env=os.environ | {"PYTHONPATH": str(code)}, text=True).strip()
    if version != "4.49.0":
        raise ValueError(f"Unexpected isolated Huginn transformers version {version}")
    folder = a.models / "huginn-0125"
    receipt = folder / "MODEL_LOCK.json"
    locked = read(receipt)
    if locked["revision"] != HUGINN_REVISION:
        raise ValueError("Unexpected Huginn model revision")
    assets = {filename: checked(folder / filename, expected) for filename, expected in locked["files"].items()}
    ctrl = a.cross / "results" / "huginn-0125" / "fit" / "rank1_huginn.pt"
    return dict(revision=locked["revision"], assets=assets, isolated_transformers=version,
                transformers_directory=str(code), controller=checked(ctrl, ANCHORS["huginn_rank1"]),
                model_lock_sha256=digest(receipt))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", choices=("old", "dual"), required=True)
    for key in ("base", "cross", "models", "feedback", "controllability", "advantage", "identification", "out"):
        parser.add_argument(f"--{key}", type=Path, required=True)
    args = parser.parse_args()
    frozen = {
        "base": args.base / "model.safetensors",
        "t1": args.controllability / "results" / "weights" / "rank1_t1.pt",
        "t2": args.controllability / "results" / "weights" / "rank1_t2.pt",
        "mixed": args.advantage / "results" / "fits" / "mixed" / "controller.pt",
        "rank8": args.feedback / "results" / "linear8_t1.pt",
        "historical_t1_axis": args.feedback / "results" / "CAUSAL_ANALYSIS" / "mean_direction_rank1.pt",
    }
    paths = [args.identification / "data" / "pools_complete",
             *[args.identification / f for f in ("evaluate_development.py", "run_full.py", "aggregate_full.py")]]
    if any(not path.exists() for path in paths):
        raise ValueError(f"The historical data and evaluation assets are incomplete under {args.identification}")
    devices = gpu_probe(1 if args.host == "old" else 2)
    anchors = {name: checked(path, ANCHORS[name]) for name, path in frozen.items()}
    models = verify_ouro_models(args.models, args.cross / "MODELS.json")
    if args.host == "old":
        models["huginn-0125"] = huginn_assets(args)
    output = dict(host=args.host, hostname=socket.gethostname(), python=sys.executable,
                  torch=torch.__version__, cuda=torch.version.cuda, transformers=transformers.__version__,
                  devices=devices, anchors=anchors, models=models, identification=str(args.identification))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.out.with_suffix(".partial")
    temporary.write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(args.out)
    print("HOST_PREFLIGHT_OK", args.host, len(devices), digest(args.out))


if __name__ == "__main__":
    main()
