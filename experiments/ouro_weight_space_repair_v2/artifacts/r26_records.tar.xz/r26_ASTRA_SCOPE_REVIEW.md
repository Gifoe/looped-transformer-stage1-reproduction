# R26 Astra scope review：菜单可表示性与 prefix 因果验收

仅理论、源码与已有收据审查；没有模型/GPU、heldout、外部benchmark或旧文件改动。R25 NoNewMechanism及关闭决定保持。14 ledger余额2780.9483967456035/21600秒不变。本文不提出部署公式，不授权模型验收。

## 1. 菜单依赖：一个精确必要条件，不是新实验

已核 `slcd_r6_scores.py`：在固定prompt和候选文本下，R6分数为 S_C(a)=A(a)−alpha_C E(a)，alpha_C由当前候选菜单C上的中心化G/E投影、截断到[0,1]产生。原字符归一和late项已包含于A、E定义中。

理想prefix-only全V decoder给每个候选a的分数 T(a)=sum_t log P(a_t|prompt,a_<t)/charlen(a)+原late(a)。如果prompt不含被修改的菜单、tokenization/prefix一致、同一已消费prefix的forward具有数学因果性，则T(a)不因外部候选集合C而改变。候选原长度可以影响自身字符分母，但不能使用“菜单里有谁”选择系数。

对于任意两个菜单C,D和共同候选a,b：

    [S_C(a)−S_C(b)]−[S_D(a)−S_D(b)]
      = −(alpha_C−alpha_D)[E(a)−E(b)].

因此，若要求所有菜单上**共同候选的相对分数**由同一个prefix-only T恢复（允许每菜单整体加常数），必要条件是 (alpha_C−alpha_D)(E(a)−E(b))=0。若要求绝对分数逐项恢复，则更强地要求 (alpha_C−alpha_D)E(a)=0。菜单内E常数或alpha恰好不变是例外，不能说“R6所有输入都不兼容”。

量化证书：设同一对候选在两菜单上的gap差绝对值为 delta。任何菜单无关gap估计至少在一个菜单有误差>=delta/2；若允许每菜单任意共同offset，而要求每候选分数误差<=epsilon，则必有 epsilon>=delta/4。这给出表示误差下界，不需要gold、模型或拟合。若只关心ranking，gap有差异还不够；必须有严格符号翻转（或一个明确tie-breaking约束）才能证明不能同时保持两菜单的相对排序。

一个仅用于证明的解析例子：菜单C有两项，A=(-1,-0.5)、G=(0,0)、E=(0,1)，alpha_C=0，第二项胜。加入第三项A=-10、G=2、E=2，中心化投影分子分母均为2，alpha_D=1；共同两项分数变为(-1,-1.5)，第一项胜，新增项本身仍败。无菜单依赖的T不能同时恢复这个严格翻转。此为R6代数输入上的反例，不声称这些数值是实际模型输出。

已有 `r7_diagnostics.py` 和 `r7_choice_perturbations.csv` 已做全开发固定prompt的permutation/duplicate/delete，并保存shared centered差、shared winner变化及alpha。**本轮不重算这些表，不把旧菜单敏感性当新发现。** 若论文需要可核验证书，最小工作只是从旧文件中事前指定第一条严格shared ranking翻转，绑定文件hash/row、原公共候选和已有alpha，再核其gap；不用gold、不重新遍历模型或宣布新性能结果。上述必要条件本身已经足够说明设计限制，没必要为它再开诊断实验。

限制尤其重要：不能在不同菜单上exact恢复R6，不等于固定ARC菜单无法保持其旧正确答案、获得新纠错，或prefix方法无法优于R6。原目标是后者，并不要求整个R6分数函数在所有可能菜单上复现。这个表示性结果也不能解释R25具体哪题失败，更不能成为放宽原旧收益要求的理由。

另外，菜单无关只是一项必要条件；任意菜单无关sequence score未必能写成共享、逐token归一的全V条件概率。本文件不声称已经证明充分条件，也不把有限固定题上可以记忆某个评分函数当无标签可部署算法。

## 2. 原路径的数学因果性：源码支持，但不能把标志当端到端证明

本地 `sources/pinned_model/modeling_ouro.py` 中，OuroAttention设置is_causal=True；OuroModel内部调用create_causal_mask，逐layer及每个recurrent loop传入mask。embedding、线性层、MLP、RMSNorm是逐位置计算，RoPE的位置来自同一cache_position；normalized state进入下一loop。若实际attention只读j<=i，则按层、再按loop归纳，位置i仅依赖0..i，teacher forcing一次输入完整候选本身不造成未来泄漏。

已核官方 [Transformers v4.55.4 SDPA接口](https://raw.githubusercontent.com/huggingface/transformers/v4.55.4/src/transformers/integrations/sdpa_attention.py)：在没有显式mask、query length>1且module causal标志为真时，接口向PyTorch传is_causal=True；有mask则依赖传入mask。q_len=1、无cache时只有一个key位置，不能把这时is_causal=False误判为泄漏。GQA dispatch也受mask是否None影响，因此添加全ones外部mask不等于数值上原路径不变。

官方 [mask factory源码](https://raw.githubusercontent.com/huggingface/transformers/v4.55.0/src/transformers/masking_utils.py) 展示了None mask可表示交由SDPA causal flag处理的分支；这里读取的是4.55.0版本作解释，**不冒充已核服务器4.55.4安装文件**。当前实际HF模块文件、dynamic module加载路径、mask factory/hash与torch/kernel版本仍由Sol只读取证确认。源码行号、注释或网页长度不同不是代码漂移证据，须比较实际字节及相关逻辑。

这套源码链支持“原实现按设计是causal”，没有证据指控未来泄漏。但仅看到self.is_causal=True，不证明运行时选择了预期interface、mask正确、无wrapper覆盖或硬件实现问题。需要把实际加载模块/hash、config、调用参数与已有测试覆盖连起来。不要为了补证据而先改mask、backend、dtype或KV；那样测到的是另一路径。

## 3. 三种不同性质，不能混成一次 exact 检查

**数学prefix因果性**：固定参数、prefix及位置，改变未来token内容/是否存在，不应改变当前位置的数学函数值。

**同shape内容独立性**：固定总长度、batch、layout、position IDs和kernel路径，仅改变cut之后token IDs，cut及之前的输出应不变。在重复原输入本身逐bit可重现的前提下，这比比较不同长度更直接隔离未来内容。若失败，先报告“实际同shape prefix不变性失败”，不是直接宣称有语义未来泄漏。

**跨长度位级独立性**：完整teacher-forced输入与截到cut的prefix输入，在对应位置是否bit-exact。即使数学函数causal，不同sequence长度可改变GEMM/SDPA调度与浮点累加方式；严格不相等可能是数值长度敏感。PyTorch明确指出不同SDPA backend可给不同浮点结果；这不能用来断言任意实际差异都是舍入，也不能直接抹掉差异。[PyTorch 2.11 SDPA文档](https://docs.pytorch.org/docs/2.11/generated/torch.nn.functional.scaled_dot_product_attention.html)

在本项目严格prefix系数合同下，长度敏感仍须明确记录：未来内容未泄漏，不等于部署系数已经位级仅依赖prefix。尤其单邻居argmin可能把很小的数值差变为离散差。不能事后放公差、挑后端或选有利tie恢复旧方法；若要求严格字节级独立，跨长度exact失败即该强要求未满足，但原因类别应保持诚实。

## 4. 已有证据覆盖到哪里

R22明确检验全部576题的候选首预测prefix token一致，以及cached native1..6首位置states跨候选exact。它对实际候选后缀改变给出了**首位置的实证支持**，部分包含不同长度；不能忽略这个已有正面证据。但它没覆盖任意已消费prefix，也没系统分开内容变化与长度变化。

R19独立depth读出、R23 Q/N多深度fullV parity证明对应原forward读出一致，不是suffix干预。R25 selected/full-range key capture在同一完整输入上exact，证明位置选择/读出管线一致，不证明key前驱位置不受其后value影响。R25 Q/N重新原样forward exact也是重复性/缓存读出检查，不能升级为截断因果验收。

在目前查到的源码和收据中，未见一个完整覆盖“同shape suffix变化 + 原输入重复 + 真prefix截断”的端到端隔离实验。此结论待Sol对服务器实际source/旧收据清单确认；如找到覆盖等价的既有证据，应引用后停止，不重复模型。

## 5. 若确实缺覆盖，下一安全行动是一个基础验收设计，而非修复算法

当前立即动作只有Sol完成实际source和旧receipt映射，Root决定是否存在剩余验收缺口。没有自动GPU授权。若缺口成立，再单独冻结一项有限验收（输入选择、全部比较、wallcap与ledger均先审），无需gold、正确率、heldout或其他benchmark。以下为必要结构，非已批准运行协议：

* 从原已授权24题按固定ID/候选顺序选满足至少有未消费suffix的第一条；token长度条件只保证可干预，不用正确性挑题。Q和N0/N1/N2各独立encode。固定first预测点与一个已消费token后的点；prefix不足则事前说明不可测，不能看到输出后换题。
* A是原完整input IDs；B保持同shape及cut以内IDs，cut之后使用事前确定、确实改变至少一个token的ID替换规则。它是测试输入干预，不用于评分方法；不能对prefix重分词。先运行A、B、A重复，原uncached/no explicit mask、same dtype/backend/depth不变，dropout关闭，no backward。所有判断同时记录输入hash、截断位置与实际内部mask/causal dispatch证据。
* 比较cut及以前选定位置的各实际所需depth normalized states；同shape的选中states经相同shape LM-head求全V。必须把state差与head计算shape差分开，不能只看一个target logit或最终argmax。Q需覆盖原native4/5读出，参考覆盖native4；若宣称native6缓存也因果，则另明确覆盖其深度，不能以4代6。
* C是真正截断到cut的input，比较相同位置state与全V；这一步与A/B结果分开记录。若需排除总长度，只比较同shape A/B；不能把C换成padding后仍称真prefix截断。所有depth/head调用预算事前确定，不因异常自动扩测或改算法。
* A重复不exact：归为重复性未建立，其他因果解释暂停。同shape A/B exact但A/C不exact：有限证据支持内容独立，跨长度位级独立不成立，不能据此称未来内容泄漏。同shape A/B在A可重复时不exact：实际不变性未通过，需要另行定位，不能在当前job换mask或重跑挑结果。全部exact：仅给所测配置/位置的强支持，不宣称穷举数学证明。

更改backend为eager/math、加mask或改FP64可用于以后隔离kernel问题，但属于另一个明确诊断分支，不能私自覆盖原benchmark实现。若原mask错误被实际证实，首先处理评估有效性与重算成本；它不是可以悄悄利用来提升accuracy的新方法。

## 决定

菜单依赖问题已有旧实验证据，本轮只给出更精确的表示必要条件与下界，不新开实验。prefix因果性有源码支持和R22首位置实证，目前没有未来泄漏证据；剩余可能缺口是任意prefix下将内容与长度敏感分开的验收。**先等Sol实际源/旧证据核验，再决定是否单独设计有限测试；当前零GPU，不扩大总cap。** 即使基础验收通过，也不会改变R25没有识别新纠错机制的结论，不会自动复活任何参数路线。

### 本轮源码补充收据

Root取回官方pinned revision的原始字节后，我本地独立比较 `transport/r26_OFFICIAL_MODEL_SOURCE_PRIVATE.py` 与 `sources/pinned_model/modeling_ouro.py`，两者SHA256均为 `c5c68fbb368ce2909c257ae2afc50719be8c91539333d3295e19312c4316f413`。据Root HTTP收据，其X-Repo-Commit为原574fa66cb8bf5abdc979642d01cf2b79b16bfab1；HTTP头本身不是我重新请求所得。故本地pinned与此次官方取回文件不存在字节漂移。网页解析行数不作为源码身份依据。服务器实际加载路径及安装HF接口仍由Sol只读核验；没有新模型调用。
